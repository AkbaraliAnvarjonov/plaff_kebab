import 'package:moscow_pizza_client_mobile/bindings/delivery_type_map_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/splash_binding.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/delivery_type_map_page/delivery_type_map_page.dart';
import 'package:moscow_pizza_client_mobile/ui/splash/splash_page.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/bindings/about_servise_bindings.dart';
import 'package:moscow_pizza_client_mobile/bindings/add_comment_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/address_detail_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/auth_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/checkout_order_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/condensation_policy_bindings.dart';
import 'package:moscow_pizza_client_mobile/bindings/current_order_detail_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/history_order_detail_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/main_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/map_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/my_address_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/product_detail_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/profile_branches_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/profile_edit_binding.dart';
import 'package:moscow_pizza_client_mobile/bindings/settings_binding.dart';
import 'package:moscow_pizza_client_mobile/ui/auth/confirm/auth_confirm_page.dart';
import 'package:moscow_pizza_client_mobile/ui/auth/auth_page.dart';
import 'package:moscow_pizza_client_mobile/ui/auth/register/register_page.dart';
import 'package:moscow_pizza_client_mobile/ui/internet_connection/internet_connection_page.dart';
import 'package:moscow_pizza_client_mobile/ui/intro/language_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/basket_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/banner_detail/banner_detail_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/checkout_order_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/map/address_detail/address_detail_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/map/map_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/favourite_detail_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/product_detail_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/main_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/history_orders/detail/history_orders_detail_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/add_comment/add_comment_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/current_orders/detail/current_orders_deatil_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/about_service/condensation_policy/profile_condensation_policy_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/about_service/profile_about_service_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/branch/detail/profile_branch_detail_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/branch/profile_branches_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/edit_profile/profile_edit_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/my_address/my_address_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/settings/settings_page.dart';

import '../bindings/expanded_map_binding.dart';
import '../bindings/favourite_detail_binding.dart';
import '../ui/main/basket/checkout_order/map/expanded_map/expanded_map_page.dart';

part './app_routes.dart';

class AppPages {
  static final pages = [
    GetPage(
      name: AppRoutes.initial,
      binding: SplashBinding(),
      page: () => const SplashPage(),
    ),
    GetPage(
      name: AppRoutes.main,
      page: () => const MainPage(),
      binding: MainBinding(),
    ),
    GetPage(
      name: AppRoutes.bannerDetail,
      page: () => const BannerDetailPage(),
    ),
    GetPage(
      name: AppRoutes.productDetail,
      page: () => const ProductDetailPage(),
      binding: ProductDetailBinding(),
    ),
    GetPage(
      name: AppRoutes.favouritesDetail,
      page: () => const FavouriteDetailPage(),
      binding: FavouriteDetailBinding(),
    ),
    GetPage(
      name: AppRoutes.basket,
      page: () => const BasketPage(),
    ),
    GetPage(
      name: AppRoutes.auth,
      page: () => const AuthPage(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRoutes.authConfirm,
      page: () => const AuthConfirmPage(),
    ),
    GetPage(
      name: AppRoutes.register,
      page: () => const RegisterPage(),
    ),
    GetPage(
      name: AppRoutes.checkoutOrder,
      page: () => const CheckoutOrderPage(),
      binding: CheckoutOrderBinding(),
    ),
    GetPage(
      name: AppRoutes.profileEdit,
      page: () => const ProfileEditPage(),
      binding: ProfileEditBinding(),
    ),
    GetPage(
      name: AppRoutes.profileAboutService,
      page: () => const ProfileAboutServicePage(),
      binding: ProfileAboutServiceBinding(),
    ),
    GetPage(
      name: AppRoutes.profileSettings,
      page: () => const SettingsPage(),
      binding: SettingsBinding(),
    ),
    GetPage(
      name: AppRoutes.profileCondensationPolicy,
      page: () => const ProfileCondensationPolicyPage(),
      binding: ProfileCondensationPolicyBinding(),
    ),
    GetPage(
      name: AppRoutes.profileBranches,
      page: () => const ProfileBranchesPage(),
      binding: ProfileBranchesBinding(),
    ),
    GetPage(
      name: AppRoutes.profileBranchDetail,
      page: () => const ProfileBranchDetailPage(),
      binding: ProfileBranchesBinding(),
    ),
    GetPage(
      name: AppRoutes.historyOrdersDetail,
      page: () => const HistoryOrdersDetailPage(),
      binding: HistoryOrderDetailBinding(),
    ),
    GetPage(
      name: AppRoutes.currentOrdersDetail,
      page: () => const CurrentOrdersDetailPage(),
      binding: CurrentOrderDetailBinding(),
    ),
    GetPage(
      name: AppRoutes.addComments,
      page: () => const AddCommentPage(),
      binding: AddCommentBinding(),
    ),
    GetPage(
      name: AppRoutes.historyOrdersDetail,
      page: () => const HistoryOrdersDetailPage(),
    ),
    GetPage(
      name: AppRoutes.map,
      page: () => const MapPage(),
      binding: MapBinding(),
    ),
    GetPage(
      name: AppRoutes.deliveryTypeMap,
      page: () => const DeliveryTypeMapPage(),
      binding: DeliveryTypeMapBinding(),
    ),
    GetPage(
      name: AppRoutes.expandedMap,
      page: () => const ExpandedMapPage(),
      binding: ExpandedMapBinding(),
    ),
    GetPage(
      name: AppRoutes.addressDetail,
      page: AddressDetailPage.new,
      binding: AddressDetailBinding(),
    ),
    GetPage(
      name: AppRoutes.myAddresses,
      page: () => const MyAddressPage(),
      binding: MyAddressBinding(),
    ),
    GetPage(
      name: AppRoutes.internetConnection,
      page: () => const InternetConnectionPage(),
    ),
    GetPage(
      name: AppRoutes.language,
      page: () => const LanguagePage(),
    )
  ];
}
