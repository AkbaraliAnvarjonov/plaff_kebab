import '../../data/models/branch/branches_response.dart';

class ProfileBranchDetailPageArguments{
  Branches branch;
  ProfileBranchDetailPageArguments({required this.branch});
}
