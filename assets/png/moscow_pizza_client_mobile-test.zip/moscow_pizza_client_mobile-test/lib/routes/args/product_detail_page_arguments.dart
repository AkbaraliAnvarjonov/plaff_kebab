import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';

class ProductDetailPageArguments {
  ProductByIdResponse? product;

  ProductDetailPageArguments({
    required this.product,
  });
}
