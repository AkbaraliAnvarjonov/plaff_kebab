import '../../data/models/orders_response.dart';

class AddCommentPageArguments {
  Orders order;
  String type;

  AddCommentPageArguments({
    required this.order,
    required this.type,
  });
}
