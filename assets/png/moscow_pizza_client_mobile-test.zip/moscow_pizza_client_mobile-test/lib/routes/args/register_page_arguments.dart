class RegisterPageArguments {
  final String phone;
  final String? name;
  final String? tag;
  final bool isLogin;
  final bool isProfile;

  RegisterPageArguments({
    required this.phone,
    required this.isProfile,
    this.isLogin = false,
    this.name,
    this.tag,
  });
}
