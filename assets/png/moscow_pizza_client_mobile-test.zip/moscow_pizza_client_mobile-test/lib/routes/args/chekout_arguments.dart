import '../../data/hive/products.dart';

class CheckoutArguments {
  final List<Products> products;
  final num allPrice;
  final String comment;

  CheckoutArguments(this.products, this.allPrice, this.comment);
}
