import '../../data/models/orders_response.dart';

class HistoryOrdersDetailPageArguments{
  Orders order;

  HistoryOrdersDetailPageArguments({required this.order});
}
