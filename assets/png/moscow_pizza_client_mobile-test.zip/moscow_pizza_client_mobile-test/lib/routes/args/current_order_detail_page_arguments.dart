class CurrentOrderDetailPageArguments{
  String id;
  CurrentOrderDetailPageArguments({required this.id});
}
