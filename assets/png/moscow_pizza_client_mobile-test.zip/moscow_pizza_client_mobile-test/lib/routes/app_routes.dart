part of './app_pages.dart';

final class AppRoutes {
  AppRoutes._();

  static const initial = '/';
  static const main = '/main';
  static const bannerDetail = '/banner_detail';
  static const productDetail = '/product_detail';
  static const favouritesDetail = '/favourites_detail';
  static const basket = '/basket';
  static const auth = '/auth';
  static const authConfirm = '/auth_confirm';
  static const register = '/register';
  static const checkoutOrder = '/checkout_order';
  static const profileEdit = '/profile_edit';
  static const profileAboutService = '/profile_about_service';
  static const profileSettings = '/profile_settings';
  static const profileCondensationPolicy = '/profile_condensation_policy';
  static const profileBranches = '/profile_branches';
  static const profileBranchDetail = '/profile_branch_detail';
  static const historyOrdersDetail = '/history_orders_detail';
  static const currentOrdersDetail = '/current_orders_detail';
  static const addComments = '/add_comments';
  static const map = '/map';
  static const deliveryTypeMap = '/delivery_type_map';
  static const expandedMap = '/expanded_map_page';
  static const addressDetail = '/address_detail';
  static const myAddresses = '/my_address';
  static const internetConnection = '/internet_connection';
  static const language = '/language';
}
