import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/address_detail_controller.dart';

class AddressDetailBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AddressDetailController>(AddressDetailController.new);
  }
}
