import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_branch_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_branches_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/profile_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';

class ProfileBranchesBinding implements Bindings {
  @override
  void dependencies() {
    var profileRepository = ProfileRepository(
      remoteSource: ProfileRemoteSource(apiClient: ApiClient.getInstance()),
    );
    Get..lazyPut<ProfileBranchesController>(
        () => ProfileBranchesController(profileRepository))
    ..lazyPut<ProfileBranchDetailController>(
        () => ProfileBranchDetailController(profileRepository));
  }
}
