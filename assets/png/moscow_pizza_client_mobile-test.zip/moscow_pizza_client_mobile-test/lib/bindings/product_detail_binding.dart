import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/product_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/product_detail_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/product_detail_repository.dart';

class ProductDetailBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ProductDetailController>(
      () => ProductDetailController(
        ProductDetailRepository(
          remoteSource:
              ProductDetailRemoteSource(apiClient: ApiClient.getInstance()),
        ),
      ),
    );
  }
}
