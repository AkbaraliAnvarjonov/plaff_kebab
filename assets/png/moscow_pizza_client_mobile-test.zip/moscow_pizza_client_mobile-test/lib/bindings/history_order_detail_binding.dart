import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/history_orders_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/orders_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';

class HistoryOrderDetailBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HistoryOrdersDetailController>(
      () => HistoryOrdersDetailController(
        OrdersRepository(
          remoteSource: OrdersRemoteSource(ApiClient.getInstance()),
        ),
      ),
    );
  }
}
