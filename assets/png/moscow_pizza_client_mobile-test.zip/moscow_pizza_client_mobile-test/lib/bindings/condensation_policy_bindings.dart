import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_condensation_policy_controller.dart';

class ProfileCondensationPolicyBinding implements Bindings {
  @override
  Future<void> dependencies() async {
    Get.lazyPut(ProfileCondensationPolicyController.new);
  }
}
