import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/add_comment_controller.dart';

class AddCommentBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AddCommentController>(
      AddCommentController.new,
    );
  }
}
