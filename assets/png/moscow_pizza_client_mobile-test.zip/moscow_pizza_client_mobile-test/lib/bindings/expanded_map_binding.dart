import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/expanded_map_controller.dart';

class ExpandedMapBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ExpandedMapController>(
      ExpandedMapController.new,
    );
  }
}
