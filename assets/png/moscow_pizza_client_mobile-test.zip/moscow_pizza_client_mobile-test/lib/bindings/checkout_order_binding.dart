import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/home_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';

class CheckoutOrderBinding extends Bindings {
  @override
  void dependencies() {
    var profileRepository = HomeRepository(
      remoteSource: HomeRemoteSource(
        apiClient: ApiClient.getInstance(),
      ),
    );
    Get.lazyPut<CheckoutOrderController>(
      () => CheckoutOrderController(profileRepository),
      fenix: true,
    );
  }
}
