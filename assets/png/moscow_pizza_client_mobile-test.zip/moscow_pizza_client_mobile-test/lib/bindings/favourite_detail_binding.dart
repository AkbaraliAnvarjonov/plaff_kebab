import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';

import '../controller/home/favourite_detail_controller.dart';
import '../data/data_sources/remote/favourite_detail_remote_source.dart';
import '../data/repository/favourite_detail_repository.dart';

class FavouriteDetailBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut<FavouriteDetailController>(
          () => FavouriteDetailController(
        FavouriteDetailRepository(
          remoteSource:
          FavouriteDetailRemoteSource(apiClient: ApiClient.getInstance()),
        ),
      ),
    );
  }
}
