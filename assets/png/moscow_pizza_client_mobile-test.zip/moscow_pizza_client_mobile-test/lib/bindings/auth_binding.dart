import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/auth/auth_confirm_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/auth/auth_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/auth/register_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/auth_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/auth_repository.dart';

class AuthBinding extends Bindings {

  @override
  void dependencies() {
    var repository = AuthRepository(AuthRemoteSource(ApiClient.getInstance()));
    Get..lazyPut<AuthController>(() => AuthController(repository), fenix: true)
    ..lazyPut<AuthConfirmController>(() => AuthConfirmController(repository),fenix: true)
    ..lazyPut<RegisterController>(() => RegisterController(repository),fenix: true);
  }
}
