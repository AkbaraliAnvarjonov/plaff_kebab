import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_about_service_controller.dart';

class ProfileAboutServiceBinding implements Bindings {
  @override
  Future<void> dependencies() async {
    Get.lazyPut(ProfileAboutServiceController.new);
  }
}
