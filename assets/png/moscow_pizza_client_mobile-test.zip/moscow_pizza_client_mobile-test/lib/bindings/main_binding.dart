import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/basket/basket_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/main/main_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/current_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/history_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/my_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/home_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/orders_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/profile_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/basket_repository.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';

import '../data/data_sources/remote/basket_remote_source.dart';

class MainBinding implements Bindings {
  @override
  void dependencies() {
    var profileRepository = ProfileRepository(
      remoteSource: ProfileRemoteSource(apiClient: ApiClient.getInstance()),
    );
    Get
      ..lazyPut<MainController>(
        () => MainController(profileRepository),
        fenix: true,
      )
      ..lazyPut<HomeController>(
        () => HomeController(
          repository: HomeRepository(
            remoteSource: HomeRemoteSource(apiClient: ApiClient.getInstance()),
          ),
          ordersRepository: OrdersRepository(
            remoteSource: OrdersRemoteSource(ApiClient.getInstance()),
          ),
        ),
        fenix: true,
      )
      ..lazyPut<MyOrdersController>(
        MyOrdersController.new,
        fenix: true,
      )
      ..lazyPut<BasketController>(
        () => BasketController(
          BasketRepository(
            remoteSource: BasketRemoteSource(
              apiClient: ApiClient.getInstance(),
            ),
          ),
        ),
        fenix: true,
      )
      ..lazyPut<ProfileController>(
        () => ProfileController(profileRepository),
        fenix: true,
      );
    var repository = OrdersRepository(
      remoteSource: OrdersRemoteSource(ApiClient.getInstance()),
    );
    Get
      ..lazyPut<HistoryOrdersController>(
        () => HistoryOrdersController(repository),
        fenix: true,
      )
      ..lazyPut<CurrentOrdersController>(
        () => CurrentOrdersController(repository),
        fenix: true,
      );
  }
}
