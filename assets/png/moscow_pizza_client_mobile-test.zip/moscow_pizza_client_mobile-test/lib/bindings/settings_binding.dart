import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_settings_controller.dart';
import 'package:moscow_pizza_client_mobile/data/repository/settings_repository.dart';

class SettingsBinding implements Bindings {
  @override
  Future<void> dependencies() async {
    var repository = SettingsRepository();
    Get.lazyPut(() => ProfileSettingsController(repository));
  }
}
