import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_edit_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_settings_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/profile_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';
import 'package:moscow_pizza_client_mobile/data/repository/settings_repository.dart';

class ProfileEditBinding implements Bindings {
  @override
  void dependencies() {
    var repository = ProfileRepository(
      remoteSource: ProfileRemoteSource(apiClient: ApiClient.getInstance()),
    );
    var repositorySetting = SettingsRepository();
    Get
      ..lazyPut<ProfileEditController>(() => ProfileEditController(repository))
      ..lazyPut<ProfileSettingsController>(
        () => ProfileSettingsController(repositorySetting),
      );
  }
}
