import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/splash/splash_controller.dart';

class SplashBinding implements Bindings {
  @override
  void dependencies() {
    Get.lazyPut(SplashController.new);
  }
}
