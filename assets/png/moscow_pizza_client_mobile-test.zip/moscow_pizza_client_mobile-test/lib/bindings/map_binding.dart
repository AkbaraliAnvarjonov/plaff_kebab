import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/map_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/home_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';

class MapBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MapController>(
      () => MapController(
        HomeRepository(
          remoteSource: HomeRemoteSource(apiClient: ApiClient.getInstance()),
        ),
      ),
    );
  }
}
