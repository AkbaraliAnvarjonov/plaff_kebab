import 'package:dio/dio.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

mixin YandexLocation {
  Future<Map<String, dynamic>?> getData(String url, Point value) async {
    late Dio dio = ApiClient.getDio;
    LocalSource localSource = LocalSource.instance;
    late final Response response;
    try {
      response = await dio.get(url);
    } on DioException catch (error) {
      response = Response(
        requestOptions: RequestOptions(),
        statusCode: error.response?.statusCode ?? 0,
      );
    } catch (e) {
      return null;
    }
    if (response.statusCode == 200) {
      if (localSource.getYandexKey() != AppConstants.yandexApiKey) {
        await localSource.setYandexKey(AppConstants.yandexApiKey);
      }
      Map<String, dynamic> decodeData = response.data;
      return decodeData;
    } else if (response.statusCode == 403) {
      if (localSource.getYandexKey() == AppConstants.yandexApiKey) {
        await localSource.setYandexKey(AppConstants.yandexApiKey1);
      } else if (localSource.getYandexKey() == AppConstants.yandexApiKey1) {
        await localSource.setYandexKey(AppConstants.yandexApiKey2);
      } else if (localSource.getYandexKey() == AppConstants.yandexApiKey2) {
        await localSource.setYandexKey(AppConstants.yandexApiKey3);
      } else {
        await localSource.setYandexKey(AppConstants.yandexApiKey);
        return null;
      }
      return getData(
        '${AppConstants.yandexUrl}?apikey=${LocalSource.instance.getYandexKey()}&format=json&geocode=${value.latitude},${value.longitude}&sco=latlong&results=1&lang=${BaseFunctions.getMapLocale()}',
        value,
      );
    } else {
      return null;
    }
  }
}
