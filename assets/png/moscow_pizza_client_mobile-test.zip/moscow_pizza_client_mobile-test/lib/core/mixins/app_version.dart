import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:launch_review/launch_review.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:moscow_pizza_client_mobile/core/extension/version_parsing.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';

import '../../data/data_sources/local/local_source.dart';
import '../../data/models/update_version_response.dart';
import '../../ui/main/widgets/do_not_ask_again_dialog.dart';
import '../constants/constants.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_style.dart';

mixin AppVersionMixin {
  Future<void> checkAppVersion(ProfileRepository? profileRepository) async {
    final updateVersion = await getAppVersion(profileRepository);
    if (updateVersion != null) {
      await checkLatestVersion(updateVersion);
    }
  }

  Future<UpdateVersionResponse?> getAppVersion(
    ProfileRepository? profileRepository,
  ) async {
    final accessToken = LocalSource.instance.getAccessToken();
    final result = await profileRepository?.getAppVersion(
      token: accessToken,
      appName: AppConstants.appName,
    );
    if (result is UpdateVersionResponse) {
      return result;
    } else {
      debugPrint('getAppVersion error: $result');
    }
    return null;
  }

  /// Checking for update
  Future<void> checkLatestVersion(UpdateVersionResponse updateVersion) async {
    try {
      // Using default duration to force fetching from remote server.
      PackageInfo packageInfo = await PackageInfo.fromPlatform();
      int currentVersion = packageInfo.version.toVersion();

      int androidVersion = (updateVersion.androidVersion ?? '').toVersion();
      int iosVersion = (updateVersion.iosVersion ?? '').toVersion();
      int appVersion = Platform.isIOS ? iosVersion : androidVersion;
      final required = updateVersion.isForce ?? false;
      if (appVersion > currentVersion) {
        if (required) {
          await _showCompulsoryUpdateDialog(
            'please_update'.tr,
          );
        } else {
          final sharedPreferences = LocalSource.instance;
          bool showUpdates = true;
          showUpdates = sharedPreferences.getUpdateDialog();
          if (showUpdates == false) {
            return;
          }
          await _showOptionalUpdateDialog('available'.tr);
        }
      } else {}
    } on Exception catch (exception) {
      debugPrint('$exception');
    } catch (exception) {
      debugPrint('$exception');
    }
  }

  Future<void> _showOptionalUpdateDialog(String message) async {
    await showDialog(
      context: AppConstants.navigatorKey.currentContext!,
      barrierDismissible: false,
      builder: (context) {
        String title = 'app_update_available'.tr;
        String btnLabel = 'update_now'.tr;
        String btnLabelCancel = 'later'.tr;
        String btnLabelDontAskAgain = 'do_not'.tr;
        return DoNotAskAgainDialog(
          'update_dialog'.tr,
          title,
          message,
          btnLabel,
          btnLabelCancel,
          _onUpdateNowClicked,
          doNotAskAgainText:
              Platform.isIOS ? btnLabelDontAskAgain : 'never_ask_again'.tr,
        );
      },
    );
  }

  void _onUpdateNowClicked() {
    LaunchReview.launch(
      androidAppId: 'uz.udevs.moscow_pizza_client_mobile',
      iOSAppId: '1565502018',
    );
  }

  Future<void> _showCompulsoryUpdateDialog(String message) async {
    await showDialog<String>(
      context: AppConstants.navigatorKey.currentContext!,
      barrierDismissible: false,
      builder: (context) {
        String title = 'app_update_available'.tr;
        String btnLabel = 'update_now'.tr;
        if (Platform.isIOS) {
          return CupertinoAlertDialog(
            title: Text(
              title,
              style: AppTextStyles.appBarTitle,
            ),
            content: Text(message, style: AppTextStyles.appBarTitle),
            actions: <Widget>[
              CupertinoDialogAction(
                isDefaultAction: true,
                onPressed: _onUpdateNowClicked,
                child: Text(
                  btnLabel,
                  style: styAppBarTitle.copyWith(
                    color: AppColors.assets,
                    fontSize: 17,
                  ),
                ),
              ),
            ],
          );
        } else {
          return AlertDialog(
            backgroundColor: AppColors.white,
            title: Text(
              '$title $message',
              style: styAppBarTitle.copyWith(
                color: AppColors.white,
                fontWeight: FontWeight.w600,
                fontSize: 17,
              ),
            ),
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(8)),
            ),
            actions: <Widget>[
              MaterialButton(
                onPressed: _onUpdateNowClicked,
                child: Text(
                  btnLabel,
                  style: styAppBarTitle.copyWith(
                    fontWeight: FontWeight.w500,
                    color: AppColors.assets,
                  ),
                ),
              )
            ],
          );
        }
      },
    );
  }
}
