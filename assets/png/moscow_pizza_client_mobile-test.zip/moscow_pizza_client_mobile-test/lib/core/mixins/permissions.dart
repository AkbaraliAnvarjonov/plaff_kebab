import 'package:geolocator/geolocator.dart';
// import 'package:location/location.dart';

mixin PermissionsMixin {
  Future<bool> hasPermission() async {
    // PermissionStatus permissionGranted;
    //
    // permissionGranted = await getPermissionStatus();
    // if (permissionGranted == PermissionStatus.denied) {
    //   permissionGranted = await requestPermission();
    //   if (permissionGranted != PermissionStatus.notDetermined) {
    //     return false;
    //   }
    // }

    bool serEnabled;
    LocationPermission permission;

    // Test if location services are enabled.
    serEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serEnabled) {
      return false;
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return false;
      }
    }
    return true;
  }
}
