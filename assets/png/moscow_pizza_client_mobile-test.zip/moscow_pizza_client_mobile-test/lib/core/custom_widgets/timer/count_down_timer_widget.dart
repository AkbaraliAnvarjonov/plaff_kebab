import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class CountDownTimerWidget extends StatelessWidget {
  final String? text;
  final bool isDone;
  final Function()? onTap;

  const CountDownTimerWidget({
    Key? key,
    this.text,
    this.isDone = false,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Visibility(
          visible: isDone,
          child: InkWell(
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'send_sms_code_again'.tr,
                style: const TextStyle(
                  color: AppColors.black,
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ),
          ),
        ),
        Visibility(
          visible: !isDone,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Text(
              text ?? '00:00',
              style: const TextStyle(
                color: AppColors.black,
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
