import 'dart:async';

import 'package:get/get.dart';

class CountDownTimerController extends GetxController {
  final RxString _timerText = ''.obs;

  RxString get timerText => _timerText;
  Timer? _timer;
  int _start = 60;
  final RxBool _isDone = false.obs;

  RxBool get isDone => _isDone;

  @override
  void onInit() {
    startTimer();
    super.onInit();
  }

  void startTimer() {
    _start = 60;
    _isDone.value = false;
    const oneSec = Duration(seconds: 1);
    _timer = Timer.periodic(
      oneSec,
      (timer) {
        if (_start < 1) {
          timer.cancel();
          _timerText.value = '00:00';
          _isDone.value = true;
          // Navigator.pop(context);
        } else {
          _start = _start - 1;
          _timerText.value = formatHHMMSS(_start);
        }
      },
    );
  }

  String formatHHMMSS(int value) {
    int second = value % 3600;
    int minutes = (second / 60).truncate();
    String minutesStr = (minutes).toString().padLeft(2, '0');
    String secondsStr = (second % 60).toString().padLeft(2, '0');
    return '$minutesStr:$secondsStr';
  }

  void disposeTimer() {
    _timer?.cancel();
  }
}
