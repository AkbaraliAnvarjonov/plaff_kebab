import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class CustomCircularProgressIndicator extends StatelessWidget {
  final bool isCalling;
  final bool isPagination;

  const CustomCircularProgressIndicator({
    Key? key,
    this.isCalling = false,
    this.isPagination = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (isPagination) {
      return AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: isCalling ? 80 : 0,
        child:Platform.isAndroid? Stack(
          alignment: Alignment.center,
          children: [
            const SizedBox(
              height: 36,
              width: 36,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(AppColors.assets),
              ),
            ),
            Container(
              width: 28,
              height: 28,
              decoration: const BoxDecoration(
                color: AppColors.assets,
                shape: BoxShape.circle,
              ),
            )
          ],
        ):const CupertinoActivityIndicator(radius: 16),
      );
    } else {
      return Platform.isAndroid
          ? const CircularProgressIndicator(color: AppColors.assets)
          : const CupertinoActivityIndicator(radius: 20);
    }
  }
}
