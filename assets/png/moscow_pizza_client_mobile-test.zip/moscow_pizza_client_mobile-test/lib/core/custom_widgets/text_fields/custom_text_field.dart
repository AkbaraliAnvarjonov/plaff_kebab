import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class CustomTextField extends StatelessWidget {
  final String labelText;
  final bool? showError;
  final Widget? suffixIcon;
  final TextEditingController? controller;
  final bool? autoFocus;
  final Function(String value)? onChanged;
  final TextInputType? keyboardType;
  final String? prefixText;
  final String? errorText;
  final TextInputAction? inputAction;
  final FocusNode? currentFocus;
  final FocusNode? nextFocus;
  final String? hintText;
  final TextStyle? hintTextStyle;
  final Color? fillColor;
  final Function()? onTap;
  final bool? readOnly;
  final double? labelPadding;
  final bool? isResizable;
  final TextStyle? labelStyle;
  final Color? borderColor;
  const CustomTextField({
    Key? key,
    this.labelText = '',
    this.borderColor,
    this.showError,
    this.controller,
    this.autoFocus,
    this.onChanged,
    this.keyboardType,
    this.prefixText,
    this.fillColor,
    this.isResizable = false,
    this.errorText,
    this.inputAction,
    this.currentFocus,
    this.nextFocus,
    this.hintText,
    this.onTap,
    this.labelPadding = 4,
    this.labelStyle,
    this.readOnly = false,
    this.suffixIcon,
    this.hintTextStyle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        RichText(
          text: TextSpan(
            text: labelText,
            style: const TextStyle(
              fontWeight: FontWeight.w400,
              fontSize: 15,
              color: AppColors.black,
            ),
          ),
        ),
        AppUtils.kBoxHeight4,
        TextFormField(
          readOnly: readOnly ?? false,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w400,
            color: AppColors.mainColor2,
          ),
          controller: controller,
          focusNode: currentFocus,
          onTap: onTap,
          maxLines: (isResizable ?? false) ? null : 1,
          autofocus: autoFocus ?? false,
          textCapitalization: TextCapitalization.sentences,
          onChanged: onChanged,
          onFieldSubmitted: (term) {},
          textInputAction: inputAction,
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(
              vertical: 14,
              horizontal: 12,
            ),
            filled: true,
            hintText: hintText,
            fillColor: fillColor ?? AppColors.background,
            hintStyle: hintTextStyle ??
                const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w400,
                  color: AppColors.black2,
                ),
            suffixIcon: suffixIcon,
            focusedBorder: const OutlineInputBorder(
              borderRadius: AppUtils.kBorderRadius8,
              borderSide: BorderSide(color: AppColors.assets),
            ),
            enabledBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xFFFFFFFF)),
              borderRadius: AppUtils.kBorderRadius8,
            ),
            errorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.red),
              borderRadius: AppUtils.kBorderRadius8,
            ),
            focusedErrorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.red),
              borderRadius: AppUtils.kBorderRadius8,
            ),
            errorText: showError ?? false ? errorText : null,
          ),
          cursorColor: AppColors.assets,
          keyboardType: keyboardType,
        ),
      ],
    );
  }
}
