import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class CustomMapTextField extends StatelessWidget {
  final String labelText;
  final bool? showError;
  final TextEditingController? controller;
  final bool? autoFocus;
  final int? maxLength;
  final Function(String value)? onChanged;
  final TextInputType? keyboardType;
  final String? prefixText;
  final String? errorText;
  final Color? backgroundColor;
  final TextInputAction? inputAction;
  final FocusNode? currentFocus;
  final FocusNode? nextFocus;
  final String? hintText;
  final Function()? onTap;
  final Widget? prefixIcon;
  final TextStyle? hintTextStyle;
  final Widget? suffixIcon;

  const CustomMapTextField({
    Key? key,
    this.labelText = '',
    this.showError,
    this.controller,
    this.autoFocus,
    this.hintTextStyle,
    this.onChanged,
    this.keyboardType,
    this.prefixText,
    this.errorText,
    this.inputAction,
    this.currentFocus,
    this.nextFocus,
    this.hintText,
    this.onTap,
    this.prefixIcon,
    this.backgroundColor = AppColors.textFieldColor,
    this.maxLength,
    this.suffixIcon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (labelText.isNotEmpty) ...[
          Text(
            labelText,
            style: const TextStyle(fontSize: 12),
          ),
        ],
        TextFormField(
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w400,
            color: AppColors.mainColor2,
          ),
          maxLength: maxLength,
          controller: controller,
          focusNode: currentFocus,
          onTap: onTap,
          autofocus: autoFocus ?? false,
          textCapitalization: TextCapitalization.sentences,
          onChanged: onChanged,
          onFieldSubmitted: (term) {},
          textInputAction: inputAction,
          minLines: 1,
          maxLines: 2,
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(
              vertical: 16,
              horizontal: 12,
            ),
            counterText: '',
            filled: true,
            hintText: hintText,
            fillColor: backgroundColor,
            hintStyle: hintTextStyle ??
                const TextStyle(
                  fontSize: 17,
                  fontWeight: FontWeight.w400,
                  color: AppColors.darkGrey,
                ),
            prefixIcon: prefixIcon,
            suffixIcon: suffixIcon,
            focusedBorder: const OutlineInputBorder(
              borderRadius: AppUtils.kBorderRadius12,
              borderSide: BorderSide(color: AppColors.assets),
            ),
            enabledBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xFFFFFFFF)),
              borderRadius: AppUtils.kBorderRadius12,
            ),
            errorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.red),
              borderRadius: AppUtils.kBorderRadius12,
            ),
            focusedErrorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.red),
              borderRadius: AppUtils.kBorderRadius12,
            ),
            errorText: showError ?? false ? errorText : null,
          ),
          cursorColor: AppColors.assets,
          keyboardType: keyboardType,
        ),
      ],
    );
  }
}
