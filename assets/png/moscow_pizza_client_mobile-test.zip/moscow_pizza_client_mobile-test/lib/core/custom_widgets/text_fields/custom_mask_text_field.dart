import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import 'masked_textinput_formatter.dart';

class CustomMaskTextField extends StatelessWidget {
  final String? labelText;
  final bool? showError;

  final TextEditingController? controller;
  final bool? autoFocus;
  final Function(String value)? onChanged;
  final TextInputType? keyboardType;
  final String? prefixText;
  final String? errorText;
  final TextInputAction? inputAction;
  final FocusNode? currentFocus;
  final FocusNode? nextFocus;
  final String? hintText;
  final Function()? onTap;

  const CustomMaskTextField({
    Key? key,
    this.labelText,
    this.showError = false,
    this.controller,
    this.autoFocus,
    this.onChanged,
    this.keyboardType,
    this.prefixText,
    this.errorText,
    this.inputAction,
    this.currentFocus,
    this.nextFocus,
    this.hintText,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        RichText(
          text: TextSpan(
            text: labelText ?? '',
            style: const TextStyle(
              fontWeight: FontWeight.w400,
              fontSize: 15,
              color: AppColors.black,
            ),
          ),
        ),
        AppUtils.kBoxHeight4,
        TextFormField(
          style: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.w400,
            color: Colors.black,
          ),
          focusNode: currentFocus,
          autofocus: autoFocus ?? false,
          textInputAction: inputAction,
          onFieldSubmitted: (term) {
            fieldFocusChange(context, currentFocus, nextFocus);
          },
          onChanged: onChanged,
          textAlignVertical: TextAlignVertical.center,
          controller: controller,
          inputFormatters: [
            MaskedTextInputFormatter(mask: '## ### ## ##', separator: ' '),
            FilteringTextInputFormatter.allow(
              RegExp('[0-9]'),
              replacementString: ' ',
            ),
          ],
          keyboardType: keyboardType,
          decoration: InputDecoration(
            contentPadding: const EdgeInsets.symmetric(
              vertical: 16,
              horizontal: 12,
            ),
            prefix: Text(
              prefixText ?? '',
              style: const TextStyle(
                fontSize: 17,
                color: Colors.black,
                fontWeight: FontWeight.w400,
              ),
            ),
            fillColor: Colors.white,
            filled: true,
            focusedBorder: const OutlineInputBorder(
              borderRadius: AppUtils.kBorderRadius12,
              borderSide: BorderSide(color: AppColors.assets),
            ),
            enabledBorder: const OutlineInputBorder(
              borderRadius: AppUtils.kBorderRadius12,
            ),
            errorBorder: const OutlineInputBorder(
              borderSide: BorderSide(color: AppColors.red),
              borderRadius: AppUtils.kBorderRadius12,
            ),
            border: const OutlineInputBorder(
              borderRadius: AppUtils.kBorderRadius12,
            ),
            errorText: (showError ?? false) ? errorText : null,
          ),
          cursorColor: AppColors.assets,
        ),
      ],
    );
  }

  void fieldFocusChange(
      BuildContext context, FocusNode? currentFocus, FocusNode? nextFocus) {
    if (currentFocus != null && nextFocus != null) {
      currentFocus.unfocus();
      FocusScope.of(context).requestFocus(nextFocus);
    }
  }
}
