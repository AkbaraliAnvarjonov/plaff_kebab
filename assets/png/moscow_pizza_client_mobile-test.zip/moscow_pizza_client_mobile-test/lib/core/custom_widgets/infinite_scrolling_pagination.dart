import 'package:flutter/material.dart';

class InfiniteScrollingPagination extends StatelessWidget {
  final Function() onPagination;
  final Widget child;
  final bool isCallLoading;

  const InfiniteScrollingPagination({
    Key? key,
    required this.onPagination,
    required this.child,
    this.isCallLoading = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return NotificationListener<ScrollNotification>(
      onNotification: (scrollInfo) {
        if (!isCallLoading &&
            scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent &&
            scrollInfo is ScrollUpdateNotification) {
          onPagination();
          return false;
        }
        return false;
      },
      child: child,
    );
  }
}
