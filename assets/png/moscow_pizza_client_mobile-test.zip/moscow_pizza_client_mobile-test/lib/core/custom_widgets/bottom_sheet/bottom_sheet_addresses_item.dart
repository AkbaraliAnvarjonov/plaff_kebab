import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';

class BottomSheetAddressesItem extends StatelessWidget {
  final CustomerAddresses customerAddresses;
  final Function()? onTap;
  const BottomSheetAddressesItem({
    Key? key,
    required this.customerAddresses,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Material(
        color: Colors.transparent,
        child: Padding(
          padding: AppUtils.kAllPadding16,
          child: Row(
            children: [
              customerAddresses.isChecked ? const Icon(Icons.radio_button_checked,size: 22,color: AppColors.assets):
              const Icon(Icons.radio_button_off,size: 22,color: AppColors.black2),
              AppUtils.kBoxWidth12,
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      customerAddresses.name ?? '',
                      style: styMyAddress,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 1,
                    ),
                    AppUtils.kBoxHeight4,
                    Text(
                      customerAddresses.address ?? '',
                      style: stySubMyAddress,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
