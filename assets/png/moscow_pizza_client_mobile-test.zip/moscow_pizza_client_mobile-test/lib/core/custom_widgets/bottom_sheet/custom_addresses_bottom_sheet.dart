import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';

import '../../theme/app_utils.dart';

class CustomAddressesBottomSheet extends StatelessWidget {
  final String? title;
  final String? buttonText;
  final String? cancelButtonText;
  final Widget child;
  final Function()? onTap;
  final Function()? onCancelTap;
  final EdgeInsets? contentPadding;

  const CustomAddressesBottomSheet({
    Key? key,
    this.title,
    this.buttonText,
    this.onTap,
    this.contentPadding,
    this.cancelButtonText,
    this.onCancelTap,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.8,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: AppUtils.kMarginVertical6,
              width: 40,
              height: 4,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: AppUtils.kBorderRadius8,
              ),
            ),
          ),
          Flexible(
            child: Material(
              color: Colors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: AppUtils.kBorderTopRadius16,
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: AppUtils.kAllPadding16,
                    child: Text(
                      'my_addresses'.tr,
                      style: AppTextStyles.blackBoldText17,
                    ),
                  ),
                  Flexible(child: child),
                  SafeArea(
                    minimum: AppUtils.kAllPadding16,
                    child: CustomButton(
                      onTap: onTap,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.add_rounded,
                            color: AppColors.white,
                          ),
                          AppUtils.kBoxWidth12,
                          Text(
                            'add_new_address'.tr,
                            style: AppTextStyles.blackBoldText15
                                .copyWith(color: AppColors.white),
                          )
                        ],
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
