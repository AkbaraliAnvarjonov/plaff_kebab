import 'package:flutter/material.dart';

import '../../theme/app_utils.dart';

class CustomBottomSheet extends StatelessWidget {
  final Widget child;
  final EdgeInsets? contentPadding;

  const CustomBottomSheet({
    Key? key,
    this.contentPadding,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.8,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Center(
            child: Container(
              margin: AppUtils.kMarginVertical8,
              width: 50,
              height: 5,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: AppUtils.kBorderRadius8,
              ),
            ),
          ),
          Flexible(
            child: ClipRRect(
              borderRadius: AppUtils.kBorderTopRadius8,
              child: Material(
                color: Colors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: AppUtils.kBorderTopRadius8,
                ),
                child: child,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
