import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_circular_progress_indicator.dart';

class CustomAndroidIosIndicator extends StatelessWidget {
  final Future<void> Function() onRefreshAndroid;
  final Future<void> Function() onRefreshIos;

  const CustomAndroidIosIndicator({
    Key? key,
    required this.onRefreshAndroid,
    required this.onRefreshIos,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Platform.isAndroid
        ? CupertinoSliverRefreshControl(
            builder:
                (_, mode, pulledExtent, refreshTriggerPullDistance, _____) {
              final double percentageComplete = clampDouble(
                  pulledExtent / refreshTriggerPullDistance, 0, 1);
              if (percentageComplete >= 0.25) {
                return const CustomCircularProgressIndicator(
                  isCalling: true,
                  isPagination: true,
                );
              }
              return const SizedBox();
            },
            onRefresh: onRefreshAndroid,
          )
        : CupertinoSliverRefreshControl(
            onRefresh: onRefreshIos,
          );
  }
}
