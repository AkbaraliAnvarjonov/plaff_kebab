import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_circular_progress_indicator.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class CustomImageNetwork extends StatelessWidget {
  final String url;
  final double height;
  final double width;
  final Color backgroundColor;
  final EdgeInsets padding;
  final BoxFit fit;
  final BorderRadius borderRadius;

  const CustomImageNetwork({
    Key? key,
    this.url = '',
    this.height = double.infinity,
    this.backgroundColor = AppColors.white,
    this.padding = EdgeInsets.zero,
    this.fit = BoxFit.fill,
    this.borderRadius = BorderRadius.zero,
    this.width = double.infinity,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadius,
      child: Ink(
        height: height,
        width: width,
        padding: padding,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: borderRadius,
        ),
        child: CachedNetworkImage(
          imageUrl: url,
          progressIndicatorBuilder: (_, url, __) => const Center(
            child: CustomCircularProgressIndicator(),
          ),
          errorWidget: (context, url, error) => Center(
            child: Image.asset(
              "assets/png/moscowskaya_pizza.png",
              height: 150,
              width: 150,
              fit: BoxFit.cover,
            ),
          ),
        ),
      ),
    );
  }
}
