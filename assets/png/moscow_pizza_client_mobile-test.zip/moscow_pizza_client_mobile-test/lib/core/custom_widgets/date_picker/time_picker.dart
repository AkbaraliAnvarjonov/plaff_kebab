import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/date_picker/date_time_widget.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/date_picker/time_widget.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class TimePicker {
  static Future<void> showDatePicker(
    BuildContext context, {
    required ValueChanged<DateTime> onDateTimeChanged,
    required String title,
    required bool isChooseTime,
    DateTime? dateTime,
        DateTime? initialDateTime,
  }) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.transparent,
      builder: (_) {
        return DateTimeWidget(
          onDateTimeChanged: onDateTimeChanged,
          title: title,
          isChooseTime: isChooseTime,
          dateTime: dateTime,
          initialDateTime: initialDateTime,
        );
      },
    );
  }

  static Future<void> showTimePicker(
    BuildContext context, {
    required ValueChanged<DateTime> onDateTimeChanged,
    String title = '',
    DateTime? currentTime,
    VoidCallback? onConfirm,
  }) async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.transparent,
      builder: (_) {
        return TimeWidget(
          onDateTimeChanged: onDateTimeChanged,
          title: title,
          currentTime: currentTime,
          onConfirm: onConfirm,
        );
      },
    );
  }
}
