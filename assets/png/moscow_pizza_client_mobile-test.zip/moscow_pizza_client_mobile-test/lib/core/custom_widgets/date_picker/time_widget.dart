import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/bottom_sheet/custom_bottom_sheet.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import '../buttons/custom_button.dart';

class TimeWidget extends StatelessWidget {
  final String title;
  final ValueChanged<DateTime> onDateTimeChanged;
  final DateTime? currentTime;
  final VoidCallback? onConfirm;
  const TimeWidget({
    Key? key,
    required this.onDateTimeChanged,
    required this.title,
    this.currentTime,
    this.onConfirm,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomBottomSheet(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Visibility(
            visible: title.isNotEmpty,
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.black,
                fontSize: 22,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Flexible(
            child: CupertinoDatePicker(
              use24hFormat: true,
              mode: CupertinoDatePickerMode.time,
              onDateTimeChanged: onDateTimeChanged,
              initialDateTime: currentTime ?? DateTime.now(),
              backgroundColor: Colors.white,
            ),
          ),
          SafeArea(
            minimum: AppUtils.kAllPadding16,
            child: CustomButton(
              onTap: () {
                onConfirm?.call();
              },
              text: 'confirm'.tr,
            ),
          )
        ],
      ),
    );
  }
}
