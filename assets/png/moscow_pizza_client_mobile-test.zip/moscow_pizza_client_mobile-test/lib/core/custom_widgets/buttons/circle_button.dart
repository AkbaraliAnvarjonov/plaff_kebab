import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class CircleButton extends StatelessWidget {
  final IconData icon;
  final Function()? onTap;

  const CircleButton({Key? key, required this.icon, this.onTap})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      width: 40,
      // decoration: BoxDecoration(
      //   shape: BoxShape.circle,
      //   color: AppColors.white.withOpacity(0.8),
      //   boxShadow: const [
      //     BoxShadow(
      //       color: AppColors.grey,
      //       offset: Offset(0.1, 0.1),
      //       blurRadius: 8,
      //       spreadRadius: 0.5,
      //     ),
      //   ],
      // ),
      child: Material(
        color: AppColors.white.withOpacity(0.8),
        shape: const CircleBorder(),
        child: IconButton(
          splashRadius: 20,
          onPressed: onTap,
          iconSize: 20,
          padding: EdgeInsets.zero,
          icon: Icon(
            icon,
            size: 20,
          ),
        ),
      ),
    );
  }
}
