import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class CustomButton extends StatelessWidget {
  final Color backgroundColor;
  final Color fontColor;
  final String text;
  final Function()? onTap;
  final double width;
  final double textSize;
  final double height;
  final Widget? child;
  final EdgeInsets padding;

  const CustomButton({
    Key? key,
    this.text = '',
    this.onTap,
    this.child,
    this.backgroundColor = AppColors.assets,
    this.fontColor = AppColors.white,
    this.width = double.infinity,
    this.textSize = 15,
    this.height = 52,
    this.padding = EdgeInsets.zero,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor,
        shape: const RoundedRectangleBorder(
          borderRadius: AppUtils.kBorderRadius8,
        ),
        padding: EdgeInsets.zero,
      ).copyWith(
        elevation: MaterialStateProperty.resolveWith<double>(
          (states) {
            if (states.contains(MaterialState.pressed)) return 0;
            return 0;
          },
        ),
        padding: MaterialStateProperty.all(padding),
        fixedSize: MaterialStateProperty.all(Size(width, height)),
      ),
      onPressed: onTap,
      child: child ??
          Center(
            child: Text(
              text,
              style: TextStyle(
                color: fontColor,
                fontSize: textSize,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
    );
  }
}
