import 'package:flutter/material.dart';

import 'app_colors.dart';

class AppTextStyles {
  AppTextStyles._();

  static const appBarTitle = TextStyle(
    color: AppColors.black,
    fontSize: 20,
    fontWeight: FontWeight.w600,
  );

  static const version = TextStyle(
    color: AppColors.black3,
    fontSize: 15,
    fontWeight: FontWeight.w400,
  );

  static const profileItemButtonText = TextStyle(
    color: AppColors.black,
    fontSize: 15,
    fontWeight: FontWeight.w600,
  );

  static const profileUserName = TextStyle(
    color: AppColors.black,
    fontSize: 20,
    fontWeight: FontWeight.w600,
  );
  static const profileUserPhone = TextStyle(
    color: AppColors.black2,
    fontSize: 15,
    fontWeight: FontWeight.w500,
  );

  static const badge = TextStyle(
    color: AppColors.white,
    fontSize: 10,
    fontWeight: FontWeight.w500,
  );

  static const blackText15 = TextStyle(
    color: AppColors.black,
    fontSize: 15,
    fontWeight: FontWeight.w400,
  );

  static const redText13 = TextStyle(
    color: AppColors.red,
    fontSize: 13,
    fontWeight: FontWeight.w400,
  );

  static const blackBoldText15 = TextStyle(
    color: AppColors.black,
    fontSize: 15,
    fontWeight: FontWeight.w600,
  );

  static const blackText17 = TextStyle(
    color: AppColors.black,
    fontSize: 17,
  );

  static const blackBoldText17 = TextStyle(
    color: AppColors.black,
    fontSize: 17,
    fontWeight: FontWeight.w600,
  );

  static const snackBarTitleText = TextStyle(
    color: AppColors.white,
    fontSize: 17,
    fontWeight: FontWeight.w600,
  );

  static const snackBarMessageText = TextStyle(
    color: AppColors.white,
    fontSize: 15,
    fontWeight: FontWeight.w400,
  );

  static const blackBoldText20 = TextStyle(
    color: AppColors.black,
    fontSize: 20,
    fontWeight: FontWeight.w600,
  );

  static const blueText15 = TextStyle(
    color: AppColors.blue,
    fontSize: 15,
    fontWeight: FontWeight.w400,
  );
  static const greyText15 = TextStyle(
    color: AppColors.black3,
    fontSize: 15,
    fontWeight: FontWeight.w400,
  );

  static const unAvailableText = TextStyle(
    color: AppColors.black,
    fontSize: 15,
    fontWeight: FontWeight.w600,
  );

  static const greyBoldText15 = TextStyle(
    color: AppColors.black3,
    fontSize: 15,
    fontWeight: FontWeight.w600,
  );

  static const productDetailButton = TextStyle(
    color: Colors.black,
    fontSize: 17,
    fontWeight: FontWeight.w600,
  );

  static const styTabBarItemTitle = TextStyle(
    color: AppColors.black,
    fontSize: 15,
    height: 22 / 15,
    fontWeight: FontWeight.w500,
  );

  static const styUnTabBarItemTitle = TextStyle(
    color: AppColors.black3,
    fontSize: 15,
    height: 22 / 15,
    fontWeight: FontWeight.w500,
  );

  static const styGroupModifierName = TextStyle(
    color: AppColors.black,
    fontSize: 20,
    fontWeight: FontWeight.w600,
  );
}

const styAppBarTitle = TextStyle(
  color: Colors.black,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);
const styBasketAppBarTitle = TextStyle(
  color: Colors.black,
  fontSize: 28,
  fontWeight: FontWeight.w700,
);
const styProductTitle = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);
const styProductDescription = TextStyle(
  color: Colors.black,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);
const styProductPrice = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);
const styBannerDetailTitle = TextStyle(
  color: Colors.black,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);

const styBannerDetailDescription = TextStyle(
  color: Colors.black12,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);
const styProductDetailTitle = TextStyle(
  color: Colors.black,
  fontSize: 18,
  fontWeight: FontWeight.w700,
);
const styProductDetailDescription = TextStyle(
  color: AppColors.baseText,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styProductDetailQuantity = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);

const styProductDetailButton = TextStyle(
  color: Colors.white,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);
const styProductDetailPrice = TextStyle(
  color: Colors.white,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const stySearchItemTitle = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);

const stySearchItemPrice = TextStyle(
  color: AppColors.black,
  fontSize: 13,
  fontWeight: FontWeight.w600,
);
const stySearchItem = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const stySearchNotFound = TextStyle(
  color: AppColors.baseText,
  fontSize: 14,
  fontWeight: FontWeight.w400,
);
const styBasketButtonQuantity = TextStyle(
  color: Colors.white,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);
const styBasketButtonTitle = TextStyle(
  color: Colors.white,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styBasketItemTitle = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styBasketOrderPrice = TextStyle(
  color: Colors.black,
  fontSize: 17,
  fontWeight: FontWeight.w500,
);
const styConfirmCodeErrorText = TextStyle(
  fontWeight: FontWeight.w600,
  fontSize: 13,
  color: AppColors.red,
);
const styAuthInfo = TextStyle(
  color: Colors.black87,
  fontWeight: FontWeight.w400,
  fontSize: 13.0,
);
const styProfileAppBarTitle = TextStyle(
  color: Colors.black,
  fontSize: 28,
  fontWeight: FontWeight.w700,
);
const styProfileAppBarSubTitle = TextStyle(
  color: AppColors.darkGrey,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styProfileItemButtonText = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styProfileAppBarTitles = TextStyle(
  color: Colors.black,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);
const styEditProfileButtonText = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styProfileAboutServiceText = TextStyle(
  color: AppColors.black6,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styProfileBottomSheetLang = TextStyle(
  color: AppColors.color1,
  fontSize: 22,
  fontWeight: FontWeight.w700,
);
const styProfileBottomSheetItemLang = TextStyle(
  color: AppColors.color1,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styProfileCondensationPolicySubText = TextStyle(
  color: AppColors.black,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);
const styProfileCondensationPolicyText = TextStyle(
  color: AppColors.black6,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);
const styProfileBranchesSubItemText = TextStyle(
  color: AppColors.assets,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);

const styProfileBranchesItemSubText = TextStyle(
  color: AppColors.black86,
  fontSize: 14,
  fontWeight: FontWeight.w400,
);
const styProfileBranchesItemText = TextStyle(
  color: AppColors.black16,
  fontSize: 20,
  fontWeight: FontWeight.w600,
);
const styTimePickerItem = TextStyle(
  color: AppColors.mainColor2,
  fontSize: 23,
  fontWeight: FontWeight.w400,
);

const styTabBarItemTitle = TextStyle(
  color: AppColors.black,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);

const styCategoryTitle = TextStyle(
  color: Colors.black,
  fontSize: 22,
  fontWeight: FontWeight.w700,
);
const styHistoryOrdersCategoryTitle = TextStyle(
  color: Colors.black,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);
const styHistoryOrdersCategoryItemOrder = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);
const styHistoryOrdersCategoryItemSum = TextStyle(
  color: Colors.black,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styHistoryOrdersCategoryItemDate = TextStyle(
  color: AppColors.darkGrey,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styHistoryOrdersDetailItemProductSum = TextStyle(
  color: Color(0xff616161),
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styHistoryOrdersDetailItemProductName = TextStyle(
  color: AppColors.black,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styCurrentOrdersStatusItemTitle = TextStyle(
  color: AppColors.black,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);
const styCurrentOrdersStatusItemSubTitle = TextStyle(
  color: AppColors.assets,
  fontSize: 17,
  fontWeight: FontWeight.w500,
);
const styCongratulationsDialogTitle = TextStyle(
  color: AppColors.black,
  fontSize: 20,
  fontWeight: FontWeight.w700,
);
const styCongratulationsDialogBodyText = TextStyle(
  color: AppColors.darkGrey,
  fontSize: 14,
  fontWeight: FontWeight.w400,
);
const styCongratulationsDialogNot = TextStyle(
  color: AppColors.darkGrey,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styCongratulationsDialogYes = TextStyle(
  color: AppColors.white,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styChooseReasonTitle = TextStyle(
  color: AppColors.black,
  fontSize: 22,
  fontWeight: FontWeight.w600,
);
const styChooseReasonItemText = TextStyle(
  color: AppColors.black,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styChooseReasonDoneText = TextStyle(
  color: AppColors.white,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);
const styChooseReasonAddCommentText = TextStyle(
  color: AppColors.darkGrey,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styCheckSaleTitle = TextStyle(
  color: Colors.black,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);

const styCheckSaleItemText = TextStyle(
  color: AppColors.black,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);
const styCheckoutOrderBranchesItemName = TextStyle(
  color: AppColors.black,
  fontSize: 16,
  fontWeight: FontWeight.w500,
);
const styCheckoutOrderBranchesItemAddress = TextStyle(
  color: AppColors.darkGrey,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);
const styCheckoutOrderBranchesItemDistance = TextStyle(
  color: AppColors.black,
  fontSize: 15,
  fontWeight: FontWeight.w400,
);
const styMapTitle = TextStyle(
  color: AppColors.black,
  fontSize: 22,
  fontWeight: FontWeight.w600,
);

const styProductItemQuantity = TextStyle(
  color: AppColors.white,
  fontSize: 20,
  fontWeight: FontWeight.w700,
);

const styNoInternetTitle = TextStyle(
  color: AppColors.black,
  fontSize: 20,
  fontWeight: FontWeight.w600,
);

const styNoInternetSubTitle = TextStyle(
  color: AppColors.black2,
  fontSize: 17,
  fontWeight: FontWeight.w400,
);

const styMyAddress = TextStyle(
  color: AppColors.baseText,
  fontSize: 13,
  fontWeight: FontWeight.w600,
);

const stySubMyAddress = TextStyle(
  color: AppColors.black,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);

const styAddress2 = TextStyle(
  color: Color(0xFF808080),
  fontSize: 12,
  fontWeight: FontWeight.w400,
);