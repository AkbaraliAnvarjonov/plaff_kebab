import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import 'app_colors.dart';

abstract class AppThemes {
  AppThemes._();

  static final ThemeData light = ThemeData(
    useMaterial3: true,
    brightness: Brightness.light,
    colorSchemeSeed: AppColors.assets,
    canvasColor: Colors.white,
    scaffoldBackgroundColor: AppColors.background,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        TargetPlatform.android: CupertinoPageTransitionsBuilder(),
      },
    ),
    buttonTheme: const ButtonThemeData(
      padding: EdgeInsets.all(4),
    ),
    dividerColor: AppColors.blackWithOpacity1,
    dividerTheme: const DividerThemeData(
      color: AppColors.blackWithOpacity1,
    ),
    tabBarTheme: TabBarTheme(
      labelColor: AppColors.black,
      overlayColor: MaterialStateProperty.all(Colors.white),
      unselectedLabelColor: AppColors.black3,
      labelStyle: AppTextStyles.styTabBarItemTitle,
      unselectedLabelStyle: AppTextStyles.styUnTabBarItemTitle,
      indicator: const BoxDecoration(
        color: Colors.white,
        borderRadius: AppUtils.kBorderRadius8,
      ),
    ),
    appBarTheme: const AppBarTheme(
      color: Colors.white,
      surfaceTintColor: Colors.white,
      shadowColor: AppColors.divider,
      iconTheme: IconThemeData(color: Colors.black),
      actionsIconTheme: IconThemeData(color: Colors.black),
      elevation: 0,
      scrolledUnderElevation: 1,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,

        /// ios
        statusBarBrightness: Brightness.light,

        /// android
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
      titleTextStyle: AppTextStyles.appBarTitle,
    ),
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontSize: 72.0, fontWeight: FontWeight.bold),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      unselectedItemColor: AppColors.black5,
      selectedItemColor: AppColors.assets,
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedLabelStyle: TextStyle(
        fontSize: 10,
        fontWeight: FontWeight.w500,
      ),
      unselectedLabelStyle: TextStyle(
        fontSize: 10,
        fontWeight: FontWeight.w500,
      ),
      selectedIconTheme: IconThemeData(
        size: 24,
        color: AppColors.assets,
      ),
      unselectedIconTheme: IconThemeData(
        size: 24,
        color: AppColors.black5,
      ),
      elevation: 5,
    ),
    elevatedButtonTheme: const ElevatedButtonThemeData(
      style: ButtonStyle(
        backgroundColor: MaterialStatePropertyAll(AppColors.assets),
        foregroundColor: MaterialStatePropertyAll(AppColors.white),
        shape: MaterialStatePropertyAll(
          RoundedRectangleBorder(
            borderRadius: AppUtils.kBorderRadius8,
          ),
        ),
        elevation: MaterialStatePropertyAll(0),
        fixedSize: MaterialStatePropertyAll(Size(double.infinity, 52)),
        textStyle: MaterialStatePropertyAll(
          TextStyle(
            color: AppColors.white,
            fontSize: 15,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      elevation: 0,
      modalElevation: 0,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: AppUtils.kBorderRadius8,
      ),
    ),
  );

  static final ThemeData dark = ThemeData(
    primaryColor: AppColors.assets,
    canvasColor: Colors.white,
    scaffoldBackgroundColor: AppColors.background,
    visualDensity: VisualDensity.adaptivePlatformDensity,
    colorScheme: const ColorScheme(
      primary: AppColors.assets,
      secondary: AppColors.assets,
      surface: Colors.transparent,
      background: AppColors.background,
      error: Colors.red,
      onPrimary: Colors.blue,
      onSecondary: Colors.blue,
      onSurface: Colors.blue,
      onBackground: Colors.transparent,
      onError: Colors.blue,
      brightness: Brightness.light,
    ),
    pageTransitionsTheme: const PageTransitionsTheme(
      builders: {
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
        TargetPlatform.android: CupertinoPageTransitionsBuilder(),
      },
    ),
    appBarTheme: const AppBarTheme(
      color: Colors.white,
      iconTheme: IconThemeData(color: Colors.black),
      elevation: 0,
      systemOverlayStyle: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,

        /// ios
        statusBarBrightness: Brightness.light,

        /// android
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
      titleTextStyle: styAppBarTitle,
    ),
    brightness: Brightness.light,
    textTheme: const TextTheme(
      headlineLarge: TextStyle(fontSize: 72.0, fontWeight: FontWeight.bold),
    ),
    bottomSheetTheme: const BottomSheetThemeData(
      elevation: 0,
      modalElevation: 0,
      backgroundColor: Colors.transparent,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: AppUtils.kBorderRadius8,
      ),
    ),
  );
}
