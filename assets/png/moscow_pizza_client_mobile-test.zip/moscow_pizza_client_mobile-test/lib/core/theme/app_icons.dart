// Place fonts/AppIcons.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: AppIcons
//      fonts:
//       - asset: fonts/AppIcons.ttf
import 'package:flutter/widgets.dart';

class AppIcons {
  AppIcons._();

  static const String _fontFamily = 'AppIcons';

  static const IconData expand_map = IconData(0xe901, fontFamily: _fontFamily);
  static const IconData home = IconData(0xe92d, fontFamily: _fontFamily);
  static const IconData shopping_bag = IconData(0xe92a, fontFamily: _fontFamily);
  static const IconData call = IconData(0xe900, fontFamily: _fontFamily);
  static const IconData check_circle = IconData(0xe90c, fontFamily: _fontFamily);
  static const IconData check = IconData(0xe90d, fontFamily: _fontFamily);
  static const IconData chef = IconData(0xe90e, fontFamily: _fontFamily);
  static const IconData credit_card = IconData(0xe90f, fontFamily: _fontFamily);
  static const IconData date = IconData(0xe910, fontFamily: _fontFamily);
  static const IconData edit = IconData(0xe911, fontFamily: _fontFamily);
  static const IconData exclamation_mark = IconData(0xe912, fontFamily: _fontFamily);
  static const IconData fast_delivery = IconData(0xe913, fontFamily: _fontFamily);
  static const IconData finish = IconData(0xe914, fontFamily: _fontFamily);
  static const IconData add = IconData(0xe915, fontFamily: _fontFamily);
  static const IconData circle = IconData(0xe916, fontFamily: _fontFamily);
  static const IconData ic_location = IconData(0xe917, fontFamily: _fontFamily);
  static const IconData map_pointer = IconData(0xe918, fontFamily: _fontFamily);
  static const IconData minus = IconData(0xe919, fontFamily: _fontFamily);
  static const IconData radio = IconData(0xe91a, fontFamily: _fontFamily);
  static const IconData recycle = IconData(0xe91c, fontFamily: _fontFamily);
  static const IconData search = IconData(0xe91d, fontFamily: _fontFamily);
  static const IconData share = IconData(0xe91e, fontFamily: _fontFamily);
  static const IconData shopping_cart = IconData(0xe91f, fontFamily: _fontFamily);
  static const IconData link = IconData(0xe920, fontFamily: _fontFamily);
  static const IconData location_pin = IconData(0xe921, fontFamily: _fontFamily);
  static const IconData location = IconData(0xe922, fontFamily: _fontFamily);
  static const IconData notification = IconData(0xe923, fontFamily: _fontFamily);
  static const IconData settings = IconData(0xe929, fontFamily: _fontFamily);
  static const IconData user = IconData(0xe92b, fontFamily: _fontFamily);
  static const IconData world = IconData(0xe92c, fontFamily: _fontFamily);
}
