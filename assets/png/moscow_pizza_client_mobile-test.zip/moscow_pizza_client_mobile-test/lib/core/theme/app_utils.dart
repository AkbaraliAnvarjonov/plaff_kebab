import 'package:flutter/material.dart';

class AppUtils {
  AppUtils._();

  /// margin
  static const kAllMargin16 = EdgeInsets.all(16);
  static const kMarginTop16Horizontal16Bottom0 =
      EdgeInsets.fromLTRB(16, 16, 16, 0);
  static const kMarginVertical6 = EdgeInsets.symmetric(vertical: 6);
  static const kMarginVertical8 = EdgeInsets.symmetric(vertical: 8);
  static const kTopMargin16 = EdgeInsets.only(bottom: 16);
  static const kBottomMargin16 = EdgeInsets.only(bottom: 16);
  static const kBottomMargin12 = EdgeInsets.only(bottom: 12);
  static const kBottomMargin4 = EdgeInsets.only(bottom: 4);
  static const kTopMargin12 = EdgeInsets.only(top: 12);
  static const kLeftMargin12 = EdgeInsets.only(left: 12);

  /// padding
  static const kAllPadding2 = EdgeInsets.all(2);
  static const kAllPadding0 = EdgeInsets.zero;
  static const kAllPadding4 = EdgeInsets.all(4);
  static const kAllPadding8 = EdgeInsets.all(8);
  static const kAllPadding10 = EdgeInsets.all(10);
  static const kAllPadding12 = EdgeInsets.all(12);
  static const kVertical12 = EdgeInsets.symmetric(vertical: 12);
  static const kHorizontal12 = EdgeInsets.symmetric(horizontal: 12);
  static const kAllPadding16 = EdgeInsets.all(16);
  static const kAllPadding20 = EdgeInsets.all(20);
  static const kAllPadding22 = EdgeInsets.all(22);
  static const kAllPadding24 = EdgeInsets.all(24);
  static const kAllPadding32 = EdgeInsets.all(32);
  static const kAllPadding100 = EdgeInsets.all(100);
  static const kLeftPadding8 = EdgeInsets.only(left: 8);
  static const kTopPadding8 = EdgeInsets.only(top: 8);
  static const kBottomPadding6 = EdgeInsets.only(bottom: 6);
  static const kBottomPadding12 = EdgeInsets.only(bottom: 12);
  static const kPaddingTop16 = EdgeInsets.only(top: 16);
  static const kPaddingTop4 = EdgeInsets.only(top: 4);
  static const kPaddingTop8 = EdgeInsets.only(top: 8);
  static const kPaddingLeft16 = EdgeInsets.only(left: 16);
  static const kPaddingHorizontal16 = EdgeInsets.symmetric(horizontal: 16);
  static const kPaddingVertical16 = EdgeInsets.symmetric(vertical: 16);
  static const kPaddingHorizontal16Vertical5 =
      EdgeInsets.symmetric(horizontal: 16, vertical: 5);
  static const kPaddingHorizontal16Vertical12 =
      EdgeInsets.symmetric(horizontal: 16, vertical: 12);

  ///
  static const kLeft16Top16Bottom16 =
      EdgeInsets.only(left: 16, top: 10, bottom: 10);
  static const kLeft16Top14Bottom14 =
      EdgeInsets.only(left: 16, top: 14, bottom: 14);

  ///
  static const kHorizontalPadding8 = EdgeInsets.symmetric(horizontal: 8);
  static const kHorizontalPadding10 = EdgeInsets.symmetric(horizontal: 10);
  static const kHorizontalPadding12 = EdgeInsets.symmetric(horizontal: 12);
  static const kHorizontalPadding16 = EdgeInsets.symmetric(horizontal: 16);
  static const kHorizontalPadding45 = EdgeInsets.symmetric(horizontal: 45);

  ///
  static const kVerticalPadding2 = EdgeInsets.symmetric(vertical: 2);
  static const kVerticalPadding8 = EdgeInsets.symmetric(vertical: 8);
  static const kVerticalPadding4 = EdgeInsets.symmetric(vertical: 4);
  static const kVerticalPadding12 = EdgeInsets.symmetric(vertical: 12);
  static const kVerticalPadding14 = EdgeInsets.symmetric(vertical: 14);
  static const kVerticalPadding16 = EdgeInsets.symmetric(vertical: 16);

  ///
  static const kHorizontal25Vertical4Padding =
      EdgeInsets.symmetric(horizontal: 25, vertical: 4);
  static const kHorizontal45Vertical8Padding =
      EdgeInsets.symmetric(horizontal: 45, vertical: 4);
  static const kHorizontal45Vertical4Padding =
      EdgeInsets.symmetric(horizontal: 45, vertical: 4);
  static const kHorizontal16Vertical24Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 24);
  static const kHorizontal10Vertical6Padding =
      EdgeInsets.symmetric(horizontal: 10, vertical: 6);
  static const kHorizontal16Vertical4Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 4);

  static const kHorizontal16Vertical12Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 12);
  static const kHorizontal16Vertical8Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 8);
  static const kHorizontal16Vertical14Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 14);
  static const kHorizontal14Vertical16Padding =
      EdgeInsets.symmetric(horizontal: 14, vertical: 16);
  static const kHorizontal16Vertical10Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 10);
  static const kHorizontal16Vertical20Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 20);
  static const kHorizontal12Vertical16Padding =
      EdgeInsets.symmetric(horizontal: 12, vertical: 16);
  static const kHorizontal12Vertical14Padding =
  EdgeInsets.symmetric(horizontal: 12, vertical: 14);
  static const kHorizontal4Vertical16Padding =
      EdgeInsets.symmetric(horizontal: 4, vertical: 16);
  static const kHorizontal16Vertical16Padding =
      EdgeInsets.symmetric(horizontal: 16, vertical: 16);
  static const kHorizontal8Vertical6Padding =
      EdgeInsets.symmetric(horizontal: 8, vertical: 6);
  static const kHorizontal0Vertical12Padding =
      EdgeInsets.symmetric(horizontal: 0, vertical: 12);
  static const kHorizontalPadding80 = EdgeInsets.symmetric(horizontal: 80);

  static const kRightPadding44 = EdgeInsets.only(right: 44);

  /// divider
  static const kDivider1 = Divider(
    height: 1,
  );
  static const kDividerPadding16 = Padding(
    padding: EdgeInsets.symmetric(
      horizontal: 16,
    ),
    child: Divider(height: 1),
  );
  static const kVerticalDivider1 = VerticalDivider(width: 1);

  /// sized box
  static const kBox = SizedBox.shrink();
  static const kBoxHeight2 = SizedBox(height: 2);
  static const kBoxHeight4 = SizedBox(height: 4);
  static const kBoxHeight6 = SizedBox(height: 6);
  static const kBoxHeight8 = SizedBox(height: 8);
  static const kBoxHeight10 = SizedBox(height: 10);
  static const kBoxHeight12 = SizedBox(height: 12);
  static const kBoxHeight14 = SizedBox(height: 14);
  static const kBoxHeight16 = SizedBox(height: 16);
  static const kBoxHeight18 = SizedBox(height: 18);
  static const kBoxHeight20 = SizedBox(height: 20);
  static const kBoxHeight24 = SizedBox(height: 24);
  static const kBoxHeight45 = SizedBox(height: 45);
  static const kBoxHeight48 = SizedBox(height: 48);
  static const kBoxHeight58 = SizedBox(height: 58);

  static const kBoxHeight30 = SizedBox(height: 30);
  static const kBoxHeight32 = SizedBox(height: 32);
  static const kBoxHeight64 = SizedBox(height: 64);
  static const kBoxWidth2 = SizedBox(width: 2);
  static const kBoxWidth8 = SizedBox(width: 8);
  static const kBoxWidth6 = SizedBox(width: 6);
  static const kBoxWidth4 = SizedBox(width: 4);
  static const kBoxWidth10 = SizedBox(width: 10);
  static const kBoxWidth12 = SizedBox(width: 12);
  static const kBoxWidth20 = SizedBox(width: 20);
  static const kBoxWidth16 = SizedBox(width: 16);
  static const kBoxWidth24 = SizedBox(width: 24);
  static const kBoxWidth30 = SizedBox(width: 30);

  /// border radius
  static const kBorderRadius0 = BorderRadius.all(Radius.zero);
  static const kBorderRadius4 = BorderRadius.all(Radius.circular(4));
  static const kBorderRadius6 = BorderRadius.all(Radius.circular(6));
  static const kBorderRadius8 = BorderRadius.all(Radius.circular(8));
  static const kBorderRadius10 = BorderRadius.all(Radius.circular(10));
  static const kBorderRadius12 = BorderRadius.all(Radius.circular(12));
  static const kBorderRadius16 = BorderRadius.all(Radius.circular(16));
  static const kBorderRadius48 = BorderRadius.all(Radius.circular(48));

  ///
  static const kSpacer = Spacer();
  static const kBorderTopRadius16 = BorderRadius.only(
    topLeft: Radius.circular(16),
    topRight: Radius.circular(16),
  );
  static const kBorderTopRadius12 = BorderRadius.only(
    topLeft: Radius.circular(12),
    topRight: Radius.circular(12),
  );
  static const kBorderBottomRadius12 = BorderRadius.only(
    bottomLeft: Radius.circular(12),
    bottomRight: Radius.circular(12),
  );
  static const kBorderTopRadius8 = BorderRadius.only(
    topLeft: Radius.circular(8),
    topRight: Radius.circular(8),
  );

  /// radius
  static const kRadius6 = Radius.circular(6);
  static const kRadius12 = Radius.circular(12);
  static const kRadius16 = Radius.circular(16);
}
