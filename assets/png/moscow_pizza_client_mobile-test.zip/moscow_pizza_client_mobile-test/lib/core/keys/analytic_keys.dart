class AnalyticKeys {
  AnalyticKeys._();

  static const userRegistered = 'user_registered';
  static const basketPressed = 'basket_pressed';
  static const checkoutOrder = 'checkout_order';
  static const languagePressed = 'language_pressed';
}
