import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

final class AppConstants {
  AppConstants._();

  static const Size designSize = Size(400, 600);

  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
  static GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  /// test
  // static const shipperId = 'd4b1658f-3271-4973-8591-98a82939a664';
  // static const baseUrl = 'https://test.customer.api.delever.uz/';
  // static const imageUrl = 'https://test.cdn.delever.uz/delever/';

  /// prod
  static const shipperId = '164e2974-44e4-4afd-a868-4e2f97879d15';
  static const baseUrl = 'https://customer.api.delever.uz/';
  static const imageUrl = 'https://cdn.delever.uz/delever/';

  static const androidPlatformID = '6bd7c2e3-d35e-47df-93ce-ed54ed53f95f';
  static const iosPlatformID = 'f6631db7-09d0-4cd9-a03a-b7a590abb8c1';

  static const yandexApiKey = '31f1de67-b97e-4d0b-88df-10e8862dd331';
  static const yandexApiKey1 = 'fd8dd043-5ad9-472e-89ef-46290ec8442c';
  static const yandexApiKey2 = '404852a9-99e2-460d-a85c-8ffd8a1c773a';
  static const yandexApiKey3 = '402a7d79-b669-44ff-ad64-160e14581e9a';

  static const yandexUrl = 'https://geocode-maps.yandex.ru/1.x/';

  static String shareLink = Platform.isIOS
      ? 'https://apps.apple.com/us/app/moscow-pizza/id6450378740'
      : 'https://play.google.com/store/apps/details?id=uz.udevs.moscow_pizza_client_mobile';

  static const Point point = Point(latitude: 41.311081, longitude: 69.240562);

  static const currentOrders = [
    '986a0d09-7b4d-4ca9-8567-aa1c6d770505',
    'ccb62ffb-f0e1-472e-bf32-d130bea90617',
    '1b6dc9a3-64aa-4f68-b54f-71ffe8164cd3',
    'b0cb7c69-5e3d-47c7-9813-b0a7cc3d81fd',
    '8781af8e-f74d-4fb6-ae23-fd997f4a2ee0',
    '84be5a2f-3a92-4469-8283-220ca34a0de4',
    'bf9cc968-367d-4391-93fa-f77eda2a7a99'
  ];

  static const cancelOrders = [
    'd39cb255-6cf5-4602-896d-9c559d40cbbe',
    'b5d1aa93-bccd-40bb-ae29-ea5a85a2b1d1',
    'c4227d1b-c317-46f8-b1e3-a48c2496206f',
    '6ba783a3-1c2e-479c-9626-25526b3d9d36',
  ];

  static const String newId = '986a0d09-7b4d-4ca9-8567-aa1c6d770505';
  static const String courierAccepted = '8781af8e-f74d-4fb6-ae23-fd997f4a2ee0';
  static const String operatorAccepted = 'ccb62ffb-f0e1-472e-bf32-d130bea90617';
  static const String vendorAccepted = '1b6dc9a3-64aa-4f68-b54f-71ffe8164cd3';
  static const String vendorReady = 'b0cb7c69-5e3d-47c7-9813-b0a7cc3d81fd';
  static const String courierPickedUp = '84be5a2f-3a92-4469-8283-220ca34a0de4';
  static const String serverCancelled = 'd39cb255-6cf5-4602-896d-9c559d40cbbe';
  static const String operatorCancelled =
      'b5d1aa93-bccd-40bb-ae29-ea5a85a2b1d1';
  static const String delivered = '79413606-a56f-45ed-97c3-f3f18e645972';
  static const String finished = 'e665273d-5415-4243-a329-aee410e39465';
  static const String futureTime = 'bf9cc968-367d-4391-93fa-f77eda2a7a99';

  static const AndroidNotificationChannel channel = AndroidNotificationChannel(
    'new orders', // id
    'new orders', // title
    description: 'new orders description', // description
    importance: Importance.high,
  );
  static const int deliveryPrice = 0;
  static const String appName = 'MoscowPizzaClientApp';
}

/// test shipperId => d4b1658f-3271-4973-8591-98a82939a664

/*
*
* 'courier_accepted': '8781af8e-f74d-4fb6-ae23-fd997f4a2ee0',
  'courier_picked_up': '84be5a2f-3a92-4469-8283-220ca34a0de4',
  'delivered': '79413606-a56f-45ed-97c3-f3f18e645972',
  'finished': 'e665273d-5415-4243-a329-aee410e39465',
  'new': '986a0d09-7b4d-4ca9-8567-aa1c6d770505',
  'operator_accepted': 'ccb62ffb-f0e1-472e-bf32-d130bea90617',
  'operator_cancelled': 'b5d1aa93-bccd-40bb-ae29-ea5a85a2b1d1',
  'server_cancelled': 'd39cb255-6cf5-4602-896d-9c559d40cbbe',
  'vendor_accepted': '1b6dc9a3-64aa-4f68-b54f-71ffe8164cd3',
  'vendor_ready': 'b0cb7c69-5e3d-47c7-9813-b0a7cc3d81fd',
  'future_time':'bf9cc968-367d-4391-93fa-f77eda2a7a99'
* */
