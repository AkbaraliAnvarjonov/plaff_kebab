extension VersionParsing on String {
  int toVersion() {
    return int.tryParse(replaceAll(".", "")) ?? 0;
  }
}
