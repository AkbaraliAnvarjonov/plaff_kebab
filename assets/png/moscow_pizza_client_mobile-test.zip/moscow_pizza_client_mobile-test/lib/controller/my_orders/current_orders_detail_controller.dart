import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';

class CurrentOrdersDetailController extends BaseController {
  final LocalSource _localSource = LocalSource.instance;

  final OrdersRepository _repository;

  CurrentOrdersDetailController(this._repository);

  Orders? _orders;
  final RxBool _ordersShow = false.obs;

  void setOrders(Orders list) {
    _orders = list;
    update();
  }

  Future<void> getCurrentItemOrder(String id) async {
    setLoading(true);
    String token = _localSource.getAccessToken();

    final result = await _repository.getOrdersDetail(
      token: token,
      orderId: id,
    );
    setLoading(false);
    if (result is Orders) {
      _ordersShow.value = true;
      setOrders(result);
    } else {
      showErrorMessage(result.toString());
    }
  }

  num get getAllPrice {
    num price = 0;
    for (int i = 0; i < (_orders?.steps ?? []).length; i++) {
      for (final OrdersProducts product in _orders?.steps[i].products ?? []) {
        price += product.price * product.quantity;
        for (final Modifiers modifier in product.modifiers ?? []) {
          price += (double.tryParse(modifier.modifiersPrice ?? '') ?? 0) *
              (double.tryParse(modifier.modifierQuantity ?? '') ?? 0);
        }
      }
    }
    return price;
  }

  num get totalDiscountSum {
    num totalDiscountSum = 0;
    for (int i = 0; i < (_orders?.steps ?? []).length; i++) {
      totalDiscountSum += _orders?.steps[i].stepAmount ?? 0;
    }
    return (totalDiscountSum + (_orders?.totalDiscountPrice ?? 0)) +
        (_orders?.deliveryPrice ?? 0);
  }

  List<String> get discountName {
    List<String> discountNames = [];
    for (int i = 0; i < (_orders?.discountsModel ?? []).length; i++) {
      var locale = _localSource.locale;
      var discountName = locale == 'en'
          ? _orders?.discountsModel[i].name?.en
          : locale == 'ru'
              ? _orders?.discountsModel[i].name?.ru
              : _orders?.discountsModel[i].name?.uz;
      discountNames.add(discountName ?? 'Null');
    }
    return discountNames;
  }

  Orders? get orders => _orders;

  RxBool get ordersShow => _ordersShow;
}
