import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';

class MyOrdersController extends BaseController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 2, vsync: this);
  }
}
