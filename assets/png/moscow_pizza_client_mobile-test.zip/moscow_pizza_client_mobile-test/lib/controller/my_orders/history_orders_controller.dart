import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';

class HistoryOrdersController extends BaseController {
  final LocalSource _localSource = LocalSource.instance;

  final OrdersRepository _repository;
  int _page = 1;
  final RxBool _isPaginationLoading = false.obs;

  HistoryOrdersController(this._repository);

  List<Orders> _orders = [];

  void setOrders(List<Orders> list) {
    _orders = list;
    update();
  }

  void setPaginationLoading(bool value) {
    _isPaginationLoading.value = value;
  }

  Future<void> getOrdersHistory() async {
    String token = _localSource.getAccessToken();
    _page = 1;
    if (token.isNotEmpty) {
      setLoading(true);
      final result = await _repository.getOrders(
        token: token,
        statusIds: [
          AppConstants.finished,
          ...AppConstants.cancelOrders,
        ],
        page: _page,
      );
      setLoading(false);
      if (result is OrdersResponse) {
        setOrders(result.orders);
      } else {
        showErrorMessage(result.toString());
      }
    }
  }

  Future<void> refreshOrdersHistory() async {
    String token = _localSource.getAccessToken();
    _page = 1;
    final result = await _repository.getOrders(
      token: token,
      statusIds: [
        AppConstants.finished,
        ...AppConstants.cancelOrders,
      ],
    );
    setLoading(false);
    if (result is OrdersResponse) {
      setOrders(result.orders);
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> pagination() async {
    String token = _localSource.getAccessToken();
    _page += 1;
    setPaginationLoading(true);
    final result = await _repository.getOrders(
      token: token,
      statusIds: [
        AppConstants.finished,
        ...AppConstants.cancelOrders,
      ],
      page: _page,
    );
    await Future.delayed(const Duration(milliseconds: 1000));
    setPaginationLoading(false);
    if (result is OrdersResponse) {
      _orders.addAll(result.orders);
      update();
    } else {
      showErrorMessage(result.toString());
    }
  }

  List<Orders> get orders => _orders;

  int get page => _page;

  RxBool get isPaginationLoading => _isPaginationLoading;
}
