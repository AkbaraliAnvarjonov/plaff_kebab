import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';

class CurrentOrdersController extends BaseController {
  final LocalSource _localSource = LocalSource.instance;

  final OrdersRepository _repository;

  CurrentOrdersController(this._repository);

  List<Orders> _orders = [];

  void setOrders(List<Orders> list) {
    _orders = list;
    update();
  }

  Future<void> getCurrentOrders() async {
    String token = _localSource.getAccessToken();
    if (token.isNotEmpty) {
      setLoading(true);
      final result = await _repository.getOrders(
        token: token,
        statusIds: AppConstants.currentOrders,
        limit: 100,
      );
      setLoading(false);
      if (result is OrdersResponse) {
        setOrders(result.orders);
      } else {
        showErrorMessage(result.toString());
      }
    }
  }

  Future<void> refreshCurrentOrders() async {
    String token = _localSource.getAccessToken();
    final result = await _repository.getOrders(
      token: token,
      statusIds: AppConstants.currentOrders,
      limit: 100,
    );
    setLoading(false);
    if (result is OrdersResponse) {
      setOrders(result.orders);
    } else {
      showErrorMessage(result.toString());
    }
  }

  List<Orders> get orders => _orders;
}
