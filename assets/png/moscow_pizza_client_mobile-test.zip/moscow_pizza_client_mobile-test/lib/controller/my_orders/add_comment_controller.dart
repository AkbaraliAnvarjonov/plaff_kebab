import 'package:flutter/cupertino.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';

class AddCommentController extends BaseController {
  late TextEditingController commentController;
  bool _isLoading = false;
  bool _isError = false;

  @override
  void onInit() {
    super.onInit();
    commentController = TextEditingController();
  }

  void setLoading1(bool value) {
    _isLoading = value;
    update();
  }

  void setError(bool value) {
    _isError = value;
    update();
  }

  bool get isLoading1 => _isLoading;

  bool get isError => _isError;

  @override
  void onClose() {
    commentController.dispose();
    super.onClose();
  }
}
