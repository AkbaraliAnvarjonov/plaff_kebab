import 'dart:io';

import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';

class HistoryOrdersDetailController extends BaseController {
  final LocalSource _localSource = LocalSource.instance;

  final OrdersRepository _repository;

  HistoryOrdersDetailController(this._repository);

  Orders? _orders;
  final RxBool _ordersShow = false.obs;

  void setOrders(Orders list) {
    _orders = list;
    update();
  }

  Future<void> getHistoryItemOrder(String id) async {
    setLoading(true);
    String token = _localSource.getAccessToken();

    final result = await _repository.getOrdersDetail(
      token: token,
      orderId: id,
    );
    setLoading(false);
    if (result is Orders) {
      _ordersShow.value = true;
      setOrders(result);
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<bool> addOnDemandOrder() async {
    setLoading(true);
    OnDemandOrderRequest request = OnDemandOrderRequest(
      apartment: '',
      building: '',
      clientId: _localSource.getCustomer().id,
      coDeliveryPrice: _orders?.coDeliveryPrice,
      deliveryType: _orders?.deliveryType,
      deliveryTime: _orders?.deliveryTime,
      description: _orders?.description ?? '',
      floor: _orders?.floor ?? '1',
      paid: _orders?.paid ?? false,
      paymentType: _orders?.paymentType ?? 'cash',
      source: Platform.isAndroid ? 'android' : 'ios',
      statusId: _orders?.statusId,
      extraPhoneNumber: _localSource.getCustomer().phone,
      steps: _orders?.steps ?? [],
      toAddress: _orders?.toAddress,
      toLocation: _orders?.toLocation,
    );
    String token = _localSource.getAccessToken();

    final result = await _repository.addOnDemandOrder(
      token: token,
      request: request,
    );
    setLoading(false);
    if (result is OndemandOrderResponse) {
      debugPrint(result.toString());
      return true;
    } else {
      showErrorMessage(result.toString());
    }
    return false;
  }

  num get getAllPrice {
    num price = 0;
    for (int i = 0; i < (_orders?.steps ?? []).length; i++) {
      for (final OrdersProducts product in _orders?.steps[i].products ?? []) {
        price += product.price * product.quantity;
        for (final Modifiers modifier in product.modifiers ?? []) {
          price += (double.tryParse(modifier.modifiersPrice ?? '') ?? 0) *
              (double.tryParse(modifier.modifierQuantity ?? '') ?? 0);
        }
      }
    }
    return price;
  }

  num get totalDiscountSum {
    num totalDiscountSum = 0;
    for (int i = 0; i < (_orders?.steps ?? []).length; i++) {
      totalDiscountSum += _orders?.steps[i].stepAmount ?? 0;
    }
    return (totalDiscountSum + (_orders?.totalDiscountPrice ?? 0)) +
        (_orders?.deliveryPrice ?? 0);
  }

  List<String> get discountName{
    List<String> discountNames = [];
    for(int i = 0; i < (_orders?.discountsModel ?? []).length; i ++){
      var locale = _localSource.locale;
      var discountName = locale == 'en'
          ? _orders?.discountsModel[i].name?.en
          : locale == 'ru'
          ? _orders?.discountsModel[i].name?.ru
          : _orders?.discountsModel[i].name?.uz;
      discountNames.add(discountName ?? 'Null');
    }
    return discountNames;
  }

  Orders? get orders => _orders;

  RxBool get ordersShow => _ordersShow;
}
