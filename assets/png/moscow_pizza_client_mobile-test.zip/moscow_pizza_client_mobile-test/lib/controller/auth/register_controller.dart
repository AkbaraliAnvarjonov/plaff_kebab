import 'package:flutter/foundation.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/auth_repository.dart';
import 'package:sms_autofill/sms_autofill.dart';

class RegisterController extends BaseController {
  late final AuthRepository _repository;

  RegisterController(this._repository);

  final RxBool _nameError = false.obs;
  String _name = '';
  late String _appSignature;
  late SmsAutoFill _smsAutoFill;

  @override
  void onInit() {
    _initSms();
    super.onInit();
  }

  Future<void> _initSms() async {
    _smsAutoFill = SmsAutoFill();
    _appSignature = await _smsAutoFill.getAppSignature;
  }

  void changeName(String value) {
    _name = value;
    debugPrint(value);
    _nameError.value = false;
  }

  Future<bool> register(String phone) async {
    if (_name.replaceAll(' ', '').isEmpty) {
      _nameError.value = true;
      return false;
    }
    var request = RegisterRequest(
      phone: phone,
      name: _name,
      tag: _appSignature,
      registrationSource: 'app',
    );
    setLoading(true);
    final result = await _repository.register(
      shipperId: AppConstants.shipperId,
      request: request,
    );
    setLoading(false);
    if (result is BaseResponse) {
      return true;
    } else {
      return false;
    }
  }

  RxBool get nameError => _nameError;

  String get name => _name;

  String get tag => _appSignature;
}
