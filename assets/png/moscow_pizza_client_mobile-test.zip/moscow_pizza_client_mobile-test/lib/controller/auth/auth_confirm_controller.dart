import 'dart:io';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/keys/analytic_keys.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/confirm_login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/confirm_register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';
import 'package:moscow_pizza_client_mobile/data/repository/auth_repository.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../routes/args/auth_confirm_page_arguments.dart';

class AuthConfirmController extends BaseController {
  late final AuthRepository _repository;

  AuthConfirmController(this._repository);
  final textEditingController = TextEditingController();

  String _currentCode = '';
  final RxBool _showErrorCode = false.obs;
  late String _appSignature;
  late SmsAutoFill _smsAutoFill;

  @override
  void onInit() {
    _initSms();
    super.onInit();
  }

  Future<bool> changeCode(String value, bool isLogin, String phone) async {
    _showErrorCode.value = false;
    _currentCode = value;
    if (value.length == 6) {
      final result = await checkCode(value, isLogin, phone, false);
      return result;
    }
    return false;
  }

  Future<void> _initSms() async {
    _smsAutoFill = SmsAutoFill();
    _appSignature = await _smsAutoFill.getAppSignature;
  }

  Future<bool> checkCode(
      String code, bool isLogin, String phone, bool isCheck) async {
    if (isCheck && code.length != 6) {
      _showErrorCode.value = true;
      return false;
    }
    var fcmToken = await FirebaseMessaging.instance.getToken();

    if (isLogin) {
      return checkCodeWithLogin(code, phone, fcmToken);
    } else {
      return checkCodeWithoutLogin(code, phone, fcmToken);
    }
  }

  Future<bool> checkCodeWithoutLogin(
      String code, String phone, String? fcmToken) async {
    var request =
        ConfirmRegisterRequest(code: code, phone: phone, fcmToken: fcmToken);
    var platformId = Platform.isAndroid
        ? AppConstants.androidPlatformID
        : AppConstants.iosPlatformID;
    setLoading(true);
    final result = await _repository.confirmRegister(
      shipperId: AppConstants.shipperId,
      platform: platformId,
      request: request,
    );
    setLoading(false);
    if (result is Customer) {
      /// Set customer info to local storage
      await _repository.setCustomer(result);

      /// Auto fill dispose
      await SmsAutoFill().unregisterListener();
      return true;
    } else {
      _showErrorCode.value = true;
      return false;
    }
  }

  Future<bool> checkCodeWithLogin(
      String code, String phone, String? fcmToken) async {
    var request =
        ConfirmLoginRequest(code: code, phone: phone, fcmToken: fcmToken);
    var platformId = Platform.isAndroid
        ? AppConstants.androidPlatformID
        : AppConstants.iosPlatformID;
    setLoading(true);
    final result = await _repository.confirmLogin(
        shipperId: AppConstants.shipperId,
        platform: platformId,
        request: request);
    setLoading(false);
    if (result is Customer) {
      await _repository.setCustomer(result);
      await BaseFunctions.logEvent(
        eventName: AnalyticKeys.userRegistered,
        parameters: {'name': result.name ?? '', 'phone': result.phone ?? ''},
      );
      return true;
    } else {
      _showErrorCode.value = true;
      return false;
    }
  }

  Future<bool> resetCode(AuthConfirmPageArguments arguments) async {
    if (arguments.isLogin) {
      return resetCodeWhenLogin(arguments);
    } else {
      return resetCodeWhenNotLogin(arguments);
    }
  }

  Future<bool> resetCodeWhenNotLogin(AuthConfirmPageArguments arguments) async {
    var request = RegisterRequest(
      phone: arguments.phone,
      name: arguments.name,
      tag: _appSignature,
      registrationSource: 'app',
    );

    setLoading(true);
    final result = await _repository.register(
      shipperId: AppConstants.shipperId,
      request: request,
    );
    setLoading(false);
    if (result is BaseResponse) {
      return true;
    } else {
      showErrorMessage(result.toString());
      return false;
    }
  }

  Future<bool> resetCodeWhenLogin(AuthConfirmPageArguments arguments) async {
    var loginRequest = LoginRequest(phone: arguments.phone, tag: _appSignature);
    setLoading(true);
    final result = await _repository.login(
      shipperId: AppConstants.shipperId,
      request: loginRequest,
    );
    setLoading(false);
    if (result is BaseResponse) {
      // ignore: unnecessary_statements
      SmsAutoFill().listenForCode;
      return true;
    } else {
      showErrorMessage(result.toString());
      return false;
    }
  }

  String get currentCode => _currentCode;

  RxBool get showErrorCode => _showErrorCode;
}
