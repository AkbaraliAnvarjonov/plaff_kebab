import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/check_custome_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/check_customer_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/auth_repository.dart';
import 'package:sms_autofill/sms_autofill.dart';

class AuthController extends BaseController {
  String _phone = '';
  final RxBool _phoneError = false.obs;
  late final AuthRepository? _repository;
  late String _appSignature;
  late SmsAutoFill _smsAutoFill;
  final TextEditingController phoneController = TextEditingController();

  AuthController(this._repository);

  @override
  void onInit() {
    _initSms();
    super.onInit();
  }

  Future<void> _initSms() async {
    _smsAutoFill = SmsAutoFill();
    _appSignature = await _smsAutoFill.getAppSignature;
  }

  void changePhoneNumber(String value) {
    var phone = value.replaceAll(' ', '');
    if (phone.length == 9) {
      _phoneError.value = false;
    }
    _phone = '+998$phone';
  }

  Future<bool?> checkCustomer() async {
    _phoneError.value = false;
    // if (_phone.length != 12) {
    //   _phoneError.value = true;
    //   return null;
    // }
    if (phoneController.text.length != 12) {
      _phoneError.value = true;
      return null;
    }
    var request = CheckCustomerRequest(phone: _phone);
    setLoading(true);
    final result = await _repository?.checkCustomerExits(
      shipperId: AppConstants.shipperId,
      request: request,
    );
    setLoading(false);
    if (result is CheckCustomerResponse) {
      var loginRequest = LoginRequest(phone: _phone, tag: _appSignature);
      final result = await _repository?.login(
        shipperId: AppConstants.shipperId,
        request: loginRequest,
      );
      if (result is BaseResponse) {
        // ignore: unnecessary_statements
        SmsAutoFill().listenForCode;
        return true;
      } else {
        showErrorMessage(result.toString());
        return false;
      }
    } else {
      return false;
    }
  }

  RxBool get phoneError => _phoneError;

  String get phone => _phone;
}
