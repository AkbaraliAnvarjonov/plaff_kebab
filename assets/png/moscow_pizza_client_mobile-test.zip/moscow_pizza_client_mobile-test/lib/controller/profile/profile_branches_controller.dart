import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';

class ProfileBranchesController extends BaseController {
  final ProfileRepository _repository;

  ProfileBranchesController(this._repository);

  List<Branches> _branches = [];

  @override
  void onInit() {
    getBranches();
    super.onInit();
  }

  Future<void> getBranches() async {
    setLoading(true);
    final result = await _repository.getBranches(
      token: LocalSource.instance.getAccessToken(),
      shipperId: AppConstants.shipperId,
    );
    setLoading(false);
    if (result is BranchesResponse) {
      _branches = result.branches;
      update();
    } else {
      showErrorMessage(result.toString());
    }
  }

  List<Branches> get branches => _branches;

  @override
  void onClose() {
    _branches = [];
    super.onClose();
  }
}
