import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/text_fields/always_disabled_focus_node.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';
import 'package:moscow_pizza_client_mobile/data/models/delete_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';

class ProfileEditController extends BaseController {
  final ProfileRepository _repository;

  final LocalSource _localSource = LocalSource.instance;

  ProfileEditController(this._repository);
  final FocusNode nameFocus = FocusNode();
  final FocusNode phoneNumberFocus = AlwaysDisabledFocusNode();
  final FocusNode dateOfBirthFocus = AlwaysDisabledFocusNode();
  late TextEditingController nameController;
  late TextEditingController phoneNumberController;
  late TextEditingController dateController;
  final RxBool _errorName = false.obs;
  final RxBool _errorSurname = false.obs;

  @override
  void onInit() {
    var profile = _localSource.getCustomer();
    nameController = TextEditingController(text: profile.name ?? '');
    phoneNumberController = TextEditingController(
        text: BaseFunctions.phoneFormat(profile.phone ?? ''));
    List<String> ls = (profile.dateOfBirth ?? '').isNotEmpty
        ? (profile.dateOfBirth ?? '').split('-')
        : [];
    dateController = TextEditingController(
        text: ls.isNotEmpty
            ? '${ls.last.padLeft(2, '0')}.${ls[ls.length ~/ 2]}.${ls.first.padLeft(2, '0')}'
            : '');
    super.onInit();
  }

  void setName(String value) {
    if (_errorName.value) {
      _errorName.value = false;
    }
  }

  void setSurname(String value) {
    _errorSurname.value = false;
  }

  void setErrorName(bool value) {
    _errorName.value = value;
  }

  void setErrorSurname(bool value) {
    _errorSurname.value = value;
  }

  Future<bool> updateCustomer() async {
    if (nameController.text.trim().isEmpty) {
      setErrorName(true);
      return false;
    }
    var profile = _localSource.getCustomer();
    var token = _localSource.getAccessToken();
    setLoading(true);
    var ls = dateController.text.trim().split('.');
    var request = Customer(
      name: nameController.text.trim(),
      phone: phoneNumberController.text.trim().replaceAll(' ', ''),
      dateOfBirth: dateController.text.trim().isNotEmpty
          ? ('${ls.last}-${ls[ls.length ~/ 2]}-${ls.first}')
          : null,
    );
    final result = await _repository.getUpdateCustomer(
      token: token,
      customerId: profile.id ?? '',
      customer: request,
    );
    setLoading(false);
    if (result is BaseResponse) {
      profile..name = nameController.text.trim()
      ..dateOfBirth = request.dateOfBirth;
      await _localSource.setCustomer(profile);
      return true;
    } else {
      showErrorMessage(result.toString());
    }
    return false;
  }

  Future<bool> deleteCustomerAccount() async {
    var profile = _localSource.getCustomer();
    var token = _localSource.getAccessToken();
    final result = await _repository.deleteCustomerAccount(
      token: token,
      customerId: profile.id ?? '',
    );
    setLoading(false);
    if (result is DeleteAddressResponse) {
      return true;
    } else {
      showErrorMessage(result.toString());
    }
    return false;
  }


  @override
  void onClose() {
    nameController.dispose();
    phoneNumberController.dispose();
    dateController.dispose();
    super.onClose();
  }

  RxBool get errorName => _errorName;

  RxBool get errorSurname => _errorSurname;
}
