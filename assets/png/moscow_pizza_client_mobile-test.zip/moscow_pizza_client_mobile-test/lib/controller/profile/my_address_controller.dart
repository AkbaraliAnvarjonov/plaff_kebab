import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/create_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/delete_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';
import 'package:flutter/cupertino.dart';

import '../home/home_controller.dart';

class MyAddressController extends BaseController {
  final HomeRepository _repository;
  final LocalSource _localSource = LocalSource.instance;

  MyAddressController(this._repository);

  @override
  void onInit() {
    super.onInit();
    getMyAddress();
  }

  void setData(Map<String, dynamic> value) {
    _data = value;
    update();
  }

  Future<void> getMyAddress() async {
    setLoading(true);
    final result = await _repository.getMyAddress(
        token: _localSource.getAccessToken(),
        shipperId: AppConstants.shipperId,
        customerId: _localSource.getCustomer().id ?? '',
        page: 1,
        limit: 15);
    setLoading(false);
    if (result is MyAddressResponse) {
      _customerAddresses = result.customerAddresses ?? [];
      update();
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> postMyAddress(MyAddressRequest request) async {
    setLoading(true);
    final result = await _repository.postMyAddress(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      request: request,
    );
    setLoading(false);
    if (result is CreateAddressResponse) {
      debugPrint('response:  ${result.id}');
      update();
      debugPrint('my address: ${_customerAddresses.join(' || ')}');
      await getMyAddress();
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> deleteAddress(CustomerAddresses addresses) async {
    setLoading(true);
    final result = await _repository.deleteMyAddress(
      token: _localSource.getAccessToken(),
      customerAddressId: addresses.id ?? '',
    );
    await Get.find<HomeController>()
        .getMyAddress();
    // await Get.find<CheckoutOrderController>().getMyAddress();
    // await Get.find<HomeController>()
    setLoading(false);
    if (result is DeleteAddressResponse) {
      _customerAddresses.remove(addresses);
      update();
    } else {
      showErrorMessage(result.toString());
    }
    setLoading(false);
  }

  Map<String, dynamic> _data = {};

  Map<String, dynamic> get data => _data;

  LocalSource get localSource => _localSource;

  List<CustomerAddresses> _customerAddresses = [];

  List<CustomerAddresses> get customerAddresses => _customerAddresses;
}
