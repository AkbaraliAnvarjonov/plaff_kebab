import 'package:moscow_pizza_client_mobile/base/base_controller.dart';

class ProfileCondensationPolicyController extends BaseController {}
