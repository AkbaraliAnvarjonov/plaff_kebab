import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/mixins/app_version.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';
import 'package:package_info_plus/package_info_plus.dart';

class ProfileController extends BaseController with AppVersionMixin {
  final ProfileRepository _repository;

  ProfileController(this._repository);

  final LocalSource _localSource = LocalSource.instance;

  final RxString _name = ''.obs;
  final RxString _phone = ''.obs;
  String _appVersion = '1.0.0';

  @override
  void onInit() {
    super.onInit();
    setName(_localSource.getCustomer().name ?? '');
    setPhone(_localSource.getCustomer().phone ?? '');
    if (_localSource.hasProfile) {
      getCustomers();
    }
    getVersion();
    update();
  }

  Future<void> getVersion() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    _appVersion = '${packageInfo.version} (${packageInfo.buildNumber})';
    update();
  }

  void setName(String value) {
    _name.value = value;
  }

  void setPhone(String value) {
    _phone.value = value;
    update();
  }

  void getUpdate(String name) {
    setName(name);
  }

  Future<void> getCustomers() async {
    String accessToken = _localSource.getAccessToken();
    String refreshToken = _localSource.getRefreshToken();
    setLoading(true);
    final result = await _repository.getCustomer(
      token: accessToken,
      customerId: _localSource.getCustomer().id ?? '',
    );
    setLoading(false);
    if (result is Customer) {
      result
        ..accessToken = accessToken
        ..refreshToken = refreshToken;
      await _localSource.setCustomer(result);
      setName(result.name ?? '');
      setPhone(result.phone ?? '');
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> removeProfile() async {
    await _repository.removeProfile();
  }

  RxString get name => _name;

  RxString get phone => _phone;

  String get appVersion => _appVersion;
}
