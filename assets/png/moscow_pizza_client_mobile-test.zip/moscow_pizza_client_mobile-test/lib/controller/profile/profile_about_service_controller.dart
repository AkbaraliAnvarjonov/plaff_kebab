import 'package:moscow_pizza_client_mobile/base/base_controller.dart';

class ProfileAboutServiceController extends BaseController{

}
