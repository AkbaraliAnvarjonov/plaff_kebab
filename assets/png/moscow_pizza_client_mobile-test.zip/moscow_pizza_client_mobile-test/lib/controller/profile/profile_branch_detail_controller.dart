import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/profile_repository.dart';

class ProfileBranchDetailController extends BaseController {
  late final ProfileRepository _repository;
  Branches? _branch;

  ProfileBranchDetailController(this._repository);

  Future<void> getBranches(String id) async {
    setLoading(true);
    final result = await _repository.getBranchesId(
      token: LocalSource.instance.getAccessToken(),
      branchId: id,
    );
    setLoading(false);
    if (result is Branches) {
      _branch = result;
    } else {
      showErrorMessage(result.toString());
    }
  }

  Branches? get branch => _branch;
}
