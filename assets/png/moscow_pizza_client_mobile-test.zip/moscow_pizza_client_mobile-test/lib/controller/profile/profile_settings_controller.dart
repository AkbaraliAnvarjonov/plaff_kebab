import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/repository/settings_repository.dart';

class ProfileSettingsController extends BaseController {
  final RxBool _notification = false.obs;
  final RxBool _message = false.obs;
  final RxString _lang = Get.locale.toString().obs;
  final SettingsRepository _repository;

  ProfileSettingsController(this._repository);

  @override
  Future<void> onInit() async {
    _notification.value = LocalSource.instance.getNotification();
    super.onInit();
  }

  void setNotification(bool value) {
    _notification.value = value;
    LocalSource.instance.setNotification(value);
  }

  void setMessage(bool value) {
    _message.value = value;
  }

  void setLang(String value) {
    _lang.value = value;
    LocalSource.instance.setLocale(value);
  }

  String getLocale(String value) {
    if (value == 'ru') {
      return 'Русский';
    } else if (value == 'uz') {
      return 'O’zbekcha';
    } else {
      return 'English';
    }
  }

  Future<void> removeProfile() async {
    await _repository.removeProfile();
  }

  RxBool get message => _message;

  RxBool get notification => _notification;

  RxString get lang => _lang;
}
