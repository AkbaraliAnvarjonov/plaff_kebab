import 'package:flutter/animation.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';

import '../../base/base_functions.dart';
import '../../base/base_controller.dart';
import '../../core/mixins/app_version.dart';
import '../../core/mixins/permissions.dart';
import '../../data/repository/profile_repository.dart';
import '../../routes/app_pages.dart';
import '../home/basket/basket_controller.dart';

class MainController extends BaseController
    with PermissionsMixin, AppVersionMixin {
  BottomMenu _tabMenu = BottomMenu.home;
  late final ProfileRepository _profileRepository;

  MainController(this._profileRepository);

  @override
  void onReady() {
    super.onReady();
    checkAppVersion(_profileRepository);
  }

  Future<void> changeTabIndex(int index) async {
    if (!LocalSource.instance.hasProfile && (index == 2 || index == 3)) {
      BaseFunctions.setIsProfile(true);
      final result = await Get.toNamed(AppRoutes.auth);
      if (result != null && result) {
        _tabMenu = BottomMenu.values[index];
      }
    } else {
      if (index == 1) {
        await Get.find<BasketController>().changeTabIndexProductFavourites();
      }
      if (_tabMenu == BottomMenu.home &&
          BottomMenu.values[index] == BottomMenu.home) {
        await Get.find<HomeController>().scrollController.animateTo(
              0,
              duration: const Duration(milliseconds: 1000),
              curve: Curves.ease,
            );
      }
      _tabMenu = BottomMenu.values[index];
    }
    update();
  }

  void setDefaultTabIndex(int index) {
    _tabMenu = BottomMenu.values[index];
  }

  BottomMenu get tabMenu => _tabMenu;
}

enum BottomMenu { home, basket, myOrders, profile }
