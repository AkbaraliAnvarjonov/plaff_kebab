
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';

class SplashController extends BaseController {
  @override
  void onInit() {
    super.onInit();
    Future.delayed(
      const Duration(seconds: 1),
      () {
        if (LocalSource.instance.hasLocale) {
          Get.offAndToNamed(AppRoutes.language);
        } else {
          Get.offAndToNamed(AppRoutes.main);
        }
      },
    );
  }
}
