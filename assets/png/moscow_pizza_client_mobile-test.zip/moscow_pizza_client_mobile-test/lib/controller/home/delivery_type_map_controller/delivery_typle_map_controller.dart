import 'dart:async';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/core/mixins/yandex_location.dart';
import 'package:moscow_pizza_client_mobile/data/hive/delivery_address_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/hive/pick_up_branch_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/map/address_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';
import 'package:geolocator/geolocator.dart';

import '../../../core/mixins/permissions.dart';

class DeliveryTypeMapController extends BaseController
    with PermissionsMixin, YandexLocation, GetTickerProviderStateMixin {
  late final HomeRepository? _homeRepository;

  DeliveryTypeMapController(this._homeRepository);

  List<MapObject> _mapObjects = [];
  final MapObjectId targetMapObjectId = const MapObjectId('target_place_mark');
  final LocalSource _localSource = LocalSource.instance;
  late YandexMapController _mapController;

  final Point _point = const Point(latitude: 41.311081, longitude: 69.240562);
  Point _myPoint = const Point(latitude: 41.311081, longitude: 69.240562);
  Position? _locationData;
  final TextEditingController locationController = TextEditingController();
  late TabController tabController;
  DeliveryType _deliveryType = DeliveryType.delivery;
  List<Branches> _branches = [];
  bool? _showLocationError;
  Branches? _selectedBranch;
  AddressResponse? pointedAddress;

  final animation = const MapAnimation();

  void setDeliveryType(DeliveryType value) {
    _deliveryType = value;
    update();
  }

  void setController(YandexMapController controller) {
    _mapController = controller;
    update();
  }

  void _initTabController() {
    tabController = TabController(length: 2, vsync: this);
  }

  @override
  void onInit() {
    super.onInit();
    _initTabController();
  }

  @override
  Future<void> onReady() async {
    super.onReady();
    await hasPermission();
  }

  @override
  void onClose() {
    tabController.dispose();
    _mapController.dispose();
    super.onClose();
  }

  PickUpBranchHiveModel _getPickUpBranchData() {
    return PickUpBranchHiveModel(
      branchName: _selectedBranch?.name,
      latitude: _selectedBranch?.location?.lat,
      longitude: _selectedBranch?.location?.long,
      branchId: _selectedBranch?.id,
    );
  }

  DeliveryAddressHiveModel _getDeliveryAddressData() {
    return DeliveryAddressHiveModel(
      addressName: locationController.text,
      latitude: _myPoint.latitude,
      longitude: _myPoint.longitude,
      branchId: _branches.firstOrNull?.id,
    );
  }

  Future<void> onConfirmButtonPressed() async {
    if (_deliveryType == DeliveryType.delivery) {
      if (locationController.text.isEmpty) {
        _showLocationError = true;
        update();
        return;
      }
      await getTheNearestBranches();
      await Future.wait([
        _localSource.setMenuId(_branches.firstOrNull?.menuId ?? ''),
        _localSource.setDeliveryAddress(address: _getDeliveryAddressData()),
        _localSource.clearPickUpBranch(),
      ]);
      await _invokeHomeControllerFunctions();
      return;
    }

    if (_deliveryType == DeliveryType.selfPickup) {
      if (_selectedBranch == null) {
        showErrorMessage(
          'please_select_branch'.tr,
          duration: const Duration(seconds: 1),
        );
        return;
      }
      await Future.wait([
        _localSource.setMenuId(_selectedBranch?.menuId ?? ''),
        _localSource.setPickUpBranch(branch: _getPickUpBranchData()),
        _localSource.clearDeliveryAddress(),
      ]);
      await _invokeHomeControllerFunctions();
      return;
    }
  }

  Future<void> _invokeHomeControllerFunctions() async {
    await Get.find<HomeController>().getDeliveryType();
    await Get.find<HomeController>().getCategoryWithProductsV2();
    Get.back();
  }

  Future<void> getTheNearestBranches() async {
    final result = await _homeRepository?.getNearBranches(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      lat: (_myPoint.latitude).toString(),
      long: (_myPoint.longitude).toString(),
    );
    if (result is BranchesResponse) {
      if (result.branches.isNotEmpty) {
        _branches = result.branches;
        _selectedBranch = null;
      }
    }
  }

  Future<void> cameraPositionChanged(Point value) async {
    _myPoint = value;
    final response = await getData(
      '${AppConstants.yandexUrl}?apikey=${LocalSource.instance.getYandexKey()}&format=json&geocode=${value.latitude},${value.longitude}&sco=latlong&results=1&lang=${BaseFunctions.getMapLocale()}',
      value,
    );
    if (response != null && response.isNotEmpty) {
      AddressResponse address = AddressResponse.fromJson(response);
      pointedAddress = address;
      if ((address.response?.geoObjectCollection?.featureMember ?? [])
          .isNotEmpty) {
        String text = address.response?.geoObjectCollection?.featureMember![0]
            .geoObject?.metaDataProperty?.geocoderMetaData?.text ??
            '';
        locationController.text = BaseFunctions.addressFormatter(text);
        update();
      }
    } else {
      locationController.text = '';
      update();
    }
  }

  Future<void> setSelectedBranch(int branchIndex) async {
    _selectedBranch = _branches[branchIndex];
    _myPoint = Point(
      latitude: (_selectedBranch?.location?.lat ?? 0.0).toDouble(),
      longitude: (_selectedBranch?.location?.long ?? 0.0).toDouble(),
    );
    await _changePointerLocation();
    update();
  }

  void setMapController(YandexMapController ctr) {
    _mapController = ctr;
    update();
  }

  Future<void> _changePointerLocation() async {
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: _myPoint, zoom: 20),
      ),
      animation: animation,
    );
    await setMapObject(_myPoint);
  }

  Future<void> findMyLocation() async {
    if (await hasPermission()) {
      final pos = await Geolocator.getCurrentPosition();
      _myPoint = Point(latitude: pos.latitude, longitude: pos.longitude);
    }
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: _myPoint, zoom: 20),
      ),
      animation: animation,
    );
    await setMapObject(_myPoint);
    debugPrint('qewewqeqwqwe');
    await getTheNearestBranches();
  }

  Future<void> getCurrentLocation() async {
    if (await hasPermission()) {
      _locationData = await Geolocator.getCurrentPosition();
      _myPoint = Point(
        latitude: _locationData?.latitude ?? 0,
        longitude: _locationData?.longitude ?? 0,
      );
      await findMyLocation();
    }
  }

  void clearPointedLocation() {
    locationController.clear();
    _mapObjects = [];
    update();
  }

  Future<void> setMapObject(Point value) async {
    PlacemarkMapObject placeMark = PlacemarkMapObject(
      mapId: targetMapObjectId,
      point: value,
      zIndex: 20,
      opacity: 1,
      icon: PlacemarkIcon.single(
        PlacemarkIconStyle(
          image: BitmapDescriptor.fromAssetImage(
            'assets/png/location.png',
          ),
        ),
      ),
    );
    _showLocationError = false;
    _mapObjects = [placeMark];
    await cameraPositionChanged(value);
    update();
  }

  Future<void> move(Point value) async {
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: point, zoom: 20),
      ),
      animation: animation,
    );
  }

  YandexMapController get mapController => _mapController;

  Point get point => _point;

  List<MapObject> get mapObjects => _mapObjects;

  List<Branches> get branches => _branches;

  bool? get showLocationError => _showLocationError;

  Branches? get selectedBranch => _selectedBranch;

  DeliveryType get deliveryType => _deliveryType;
}
