import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/combo_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/combo_response.dart'
    as cr;

import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart'
    as pbi;
import 'package:moscow_pizza_client_mobile/routes/args/favourite_detail_page_arguments.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_style.dart';
import '../../core/theme/app_utils.dart';
import '../../data/hive/products.dart' as basket_products;
import '../../data/hive/products.dart';
import '../../data/repository/favourite_detail_repository.dart';

class FavouriteDetailController extends BaseController {
  final FavouriteDetailRepository _repository;

  FavouriteDetailController(this._repository);

  final LocalSource _localSource = LocalSource.instance;
  ProductByIdResponse? _productById;
  ProductModifiers? _productModifiers;
  List<String> selectedOptionName = [];
  num _quantity = 1;
  basket_products.Products? _basketProduct;
  bool _hasOptions = false;
  bool _hasModifier = false;
  bool optionAvailable = false;
  num price = 0;
  String productId = '';
  pbi.Title? productName;
  int singleModifiersLength = 0;
  int groupModifiersLength = 0;
  Map<String, String> fullAvailableItemsList = {};
  Map<String, String> firstOptionsList = {};
  Map<String, String> secondOptionsList = {};
  Map<String, String> thirdOptionsList = {};
  List<pbi.Properties>? sizeProperties;
  List<pbi.Properties>? optionsProperties;
  ProductModifiers? databaseModifier;
  List<Modifiers> modifiers = [];
  List<Combo> combo = [];
  double priceOfGroupModifier = 0;
  List<cr.Groups>? _products;
  String uniqueKey = '';
  String hiveUniqueKey = '';
  List<String> productInBasketIds = [];
  dynamic product;
  String? type;
  int favQuantity = 1;
  final arguments = Get.arguments as FavouriteDetailPageArguments;
  String? optionImage;
  double priceOfSingleModifier = 0;
  String _productType = '';

  @override
  void onInit() {
    super.onInit();
    product = arguments.product;
    getProductDetailV2(product?.id);
  }

  void refreshPage() {
    product = productById;
    update();
  }

  void changeSelected(int index, bool isSel) {
    productById?.favorites?[index].isSelected = isSel;
    update();
  }

  @override
  void showSuccessMessage(String message) {
    Get.snackbar(
      'add_accepted'.tr,
      message,
      titleText: Text(
        'add_accepted'.tr,
        style: AppTextStyles.snackBarTitleText,
      ),
      messageText: Text(message, style: AppTextStyles.snackBarMessageText),
      backgroundColor: AppColors.green,
      borderRadius: 8,
      padding: AppUtils.kAllPadding16,
      colorText: AppColors.white,
      maxWidth: Get.width,
      margin: AppUtils.kAllPadding16,
    );
  }

  void comboChoiceSelection(int productIndex, int optionIndex) {
    _products?[productIndex].selectedIndex = optionIndex;
    update();
  }

  void getFullList(int index) {
    ///getting lists of available products ids
    String firstPropertyId =
        _productById?.properties?[0].options?[index].id ?? '';
    _productById?.variantProducts?.forEach(
      (element) {
        if ((element.productProperty?.length ?? 0) > 0) {
          firstOptionsList[element.productProperty?[0].optionId ?? ''] =
              element.productProperty?[0].optionId ?? '';
          if (element.productProperty?[0].optionId == firstPropertyId) {
            if ((element.productProperty?.length ?? 0) > 1) {
              secondOptionsList[element.productProperty?[1].optionId ?? ''] =
                  element.productProperty?[1].optionId ?? '';
            }
          }
        }
      },
    );

    ///here we select product if it is not selected
    if ((_productById?.properties?.length ?? 0) > 1) {
      if (!secondOptionsList.containsKey(_productById?.properties?[1]
          .options?[_productById?.properties?[1].selectIndex ?? 0].id)) {
        for (int i = 0;
            i < (_productById?.properties?[1].options?.length ?? 0);
            i++) {
          if (secondOptionsList
              .containsKey(_productById?.properties?[1].options?[i].id)) {
            tabIndex(1, i);
            choosingProductWithOption(1, i);
            break;
          }
        }
      }
    }
  }

  int itemsCount(List<pbi.Options>? options) {
    int count = 0;
    options?.forEach((element) {
      if (fullAvailableItemsList.containsKey(element.id)) {
        count++;
      }
    });
    return count;
  }

  void getOptionsList() {
    clearAllList();
    if (_productById?.properties?.isEmpty ?? true) {
      return;
    }
    int selectedFirstIndex = _productById?.properties?[0].selectIndex ?? 0;
    getFullList(selectedFirstIndex);

    int selectedSecondIndex = (_productById?.properties?.length ?? 0) > 1
        ? (_productById?.properties?[1].selectIndex ?? 0)
        : 0;
    String secondPropertyId = (_productById?.properties?.length ?? 0) > 1
        ? (_productById?.properties?[1].options?[selectedSecondIndex].id ?? '')
        : '';
    String firstPropertyId =
        _productById?.properties?[0].options?[selectedFirstIndex].id ?? '';

    ///getting lists of available 3 tab products ids
    _productById?.variantProducts?.forEach(
      (element) {
        if ((element.productProperty?.length ?? 0) > 2) {
          fullAvailableItemsList[element.productProperty?[0].optionId ?? ''] =
              element.productProperty?[0].optionId ?? '';
          if (element.productProperty?[0].optionId == firstPropertyId &&
              element.productProperty?[1].optionId == secondPropertyId) {
            thirdOptionsList[element.productProperty?[2].optionId ?? ''] =
                element.productProperty?[1].optionId ?? '';
          }
        }
      },
    );

    ///here we select product if it is not selected
    if ((_productById?.properties?.length ?? 0) > 2) {
      if (!thirdOptionsList.containsKey(_productById?.properties?[2]
          .options?[_productById?.properties?[2].selectIndex ?? 0].id)) {
        for (int i = 0;
            i < (_productById?.properties?[2].options?.length ?? 0);
            i++) {
          if (thirdOptionsList
              .containsKey(_productById?.properties?[2].options?[i].id)) {
            tabIndex(2, i);
            choosingProductWithOption(2, i);
            break;
          }
        }
      }
    }
    addToFullList();
    update();
  }

  void addToFullList() {
    fullAvailableItemsList
      ..addAll(firstOptionsList)
      ..addAll(secondOptionsList)
      ..addAll(thirdOptionsList);
  }

  void clearAllList() {
    fullAvailableItemsList.clear();
    firstOptionsList.clear();
    secondOptionsList.clear();
    thirdOptionsList.clear();
  }

  Future<void> getProductQuantity() async {
    productInBasketIds = [];
    var ls = await _repository.getAllBasketProductsAsync();
    for (var element in ls) {
      if (_productById?.id == element.id) {
        _quantity = element.quantity;
        _basketProduct = element;
      }
      String uniqueId = BaseFunctions.stringLengthMax255(element.uniqueId);
      productInBasketIds.add(uniqueId);
    }
  }

  void choosingProductWithOption(int propertyIndex, int value) {
    price = 0;
    productId = '';
    productName = null;
    optionAvailable = false;
    if (productById?.type == 'origin') {
      int optionIndex = value;
      if (optionIndex == 0) {
        for (int i = 0;
            i < (_productById?.properties?[propertyIndex].options ?? []).length;
            i++) {
          if (fullAvailableItemsList.containsKey(
              _productById?.properties?[propertyIndex].options?[i].id)) {
            productById?.properties?[propertyIndex].selectIndex = i;
            optionIndex = i;
            break;
          }
        }
      }
      selectedOptionName[propertyIndex] =
          _productById?.properties?[propertyIndex].options?[optionIndex].id ??
              '';
      for (int i = 0; i < (productById?.variantProducts?.length ?? 0); i++) {
        List<String> productPropertyOptions = [];
        productById?.variantProducts?[i].productProperty?.forEach((element) {
          productPropertyOptions.add(element.optionId ?? '');
        });
        if (productPropertyOptions.join('') == selectedOptionName.join('')) {
          optionAvailable = true;
          optionImage = productById?.variantProducts?[i].image;
          productId = productById?.variantProducts?[i].id ?? '';
          price = productById?.variantProducts?[i].outPrice ?? 0;
          productName = productById?.variantProducts?[i].title;
          _hasModifier = _productById?.variantProducts?[i].hasModifier ?? false;
        }
      }
    } else {
      optionAvailable = true;
      productId = productById?.id ?? '';
      price = productById?.outPrice ?? 0;
      productName = productById?.title;
    }
    update();
  }

  void findModifier() {
    modifiers = [];
    combo = [];

    if (productModifiers != null) {
      if (productModifiers?.singleModifiers?.isNotEmpty ?? false) {
        for (int i = 0;
            i < (productModifiers?.singleModifiers?.length ?? 0);
            i++) {
          if (productModifiers?.singleModifiers?[i].isChecked ?? false) {
            modifiers.add(
              Modifiers(
                modifierName:
                    productModifiers?.singleModifiers?[i].name?.parseName(),
                modifierId: productModifiers?.singleModifiers?[i].id ?? '',
                modifierQuantity:
                    productModifiers?.singleModifiers?[i].count ?? 0,
                modifiersPrice: int.tryParse(
                        productModifiers?.singleModifiers?[i].price ?? '0') ??
                    0,
                parentId: '',
                addModifierPrice:
                    productModifiers?.singleModifiers?[i].addToPrice ?? true,
              ),
            );
          }
        }
      }
      if (productModifiers?.groupModifiers?.isNotEmpty ?? false) {
        for (int i = 0;
            i < (productModifiers?.groupModifiers?.length ?? 0);
            i++) {
          for (int j = 0;
              j < (productModifiers?.groupModifiers?[i].variants?.length ?? 0);
              j++) {
            if (productModifiers?.groupModifiers?[i].variants?[j].isChecked ??
                false) {
              modifiers.add(
                Modifiers(
                  modifierName: productModifiers
                      ?.groupModifiers?[i].variants?[j].title
                      ?.parseTitle(),
                  modifierId:
                      productModifiers?.groupModifiers?[i].variants?[j].id ??
                          '',
                  modifierQuantity: productModifiers
                          ?.groupModifiers?[i].variants?[j].quantity ??
                      0,
                  modifiersPrice: productModifiers
                          ?.groupModifiers?[i].variants?[j].outPrice ??
                      0,
                  parentId: productModifiers?.groupModifiers?[i].id ?? '',
                  addModifierPrice:
                      productModifiers?.groupModifiers?[i].addToPrice ?? true,
                ),
              );
            }
          }
        }
      }
    }

    _products?.forEach((element) {
      if (element.type == 'combo_basic') {
        combo.add(
          Combo(
            groupId: element.id ?? '',
            variantId: element.variants?.first.id ?? '',
            variantName: element.variants?.first.title?.parseTitle(),
            quantity: element.quantity ?? 1,
          ),
        );
      }
      if (element.type == 'combo_choose') {
        combo.add(Combo(
          groupId: element.id ?? '',
          variantId: element.variants?[element.selectedIndex ?? 0].id ?? '',
          variantName:
              element.variants?[element.selectedIndex ?? 0].title?.parseTitle(),
          quantity: element.quantity ?? 1,
        ));
      }
    });
    update();
    insertProduct();
  }

  void getHiveUniqueKey() {
    if (!_hasModifier) {
      productModifiers?.groupModifiers = null;
      productModifiers?.singleModifiers = null;
    }
    hiveUniqueKey = '';
    String productChoiceId = '';
    String productBasicId = '';
    if (productModifiers != null) {
      if (productModifiers?.singleModifiers?.isNotEmpty ?? false) {
        for (int i = 0;
            i < (productModifiers?.singleModifiers?.length ?? 0);
            i++) {
          if (productModifiers?.singleModifiers?[i].isChecked ?? false) {
            if (hiveUniqueKey.isEmpty) {
              hiveUniqueKey =
                  "${productModifiers?.singleModifiers?[i].id ?? " "}${productModifiers?.singleModifiers?[i].count ?? ''}";
            } else {
              hiveUniqueKey =
                  "$hiveUniqueKey,${productModifiers?.singleModifiers?[i].id ?? ''}${productModifiers?.singleModifiers?[i].count ?? ''}";
            }
          }
        }
      }
      if (productModifiers?.groupModifiers?.isNotEmpty ?? false) {
        for (int i = 0;
            i < (productModifiers?.groupModifiers?.length ?? 0);
            i++) {
          for (int j = 0;
              j < (productModifiers?.groupModifiers?[i].variants?.length ?? 0);
              j++) {
            if (productModifiers?.groupModifiers?[i].variants?[j].isChecked ??
                false) {
              if (hiveUniqueKey.isEmpty) {
                hiveUniqueKey =
                    "${productModifiers?.groupModifiers?[i].variants?[j].id ?? ''}${productModifiers?.groupModifiers?[i].variants?[j].quantity ?? ''}";
              } else {
                hiveUniqueKey =
                    "$hiveUniqueKey,${productModifiers?.groupModifiers?[i].variants?[j].id ?? ''}${productModifiers?.groupModifiers?[i].variants?[j].quantity ?? ''}";
              }
            }
          }
        }
      }
    }
    _products?.forEach((element) {
      if (element.type == 'combo_basic') {
        productBasicId = '$productBasicId,${element.id}';
      }
      if (element.type == 'combo_choose') {
        productChoiceId =
            '$productChoiceId,${element.variants?[element.selectedIndex ?? 0].id}';
      }
    });
    if (!(hasModifier && productType == 'combo' ||
        (hasModifier && productType == 'simple'))) {
      hiveUniqueKey = productId.replaceAll(',,', ',');
    } else {
      hiveUniqueKey =
          '$productId,$hiveUniqueKey,${quantity.toInt()}'.replaceAll(',,', ',');
    }
    if (productChoiceId.isNotEmpty) {
      hiveUniqueKey = '$hiveUniqueKey,$productChoiceId';
    }
    if (productBasicId.isNotEmpty) {
      hiveUniqueKey = '$hiveUniqueKey,$productBasicId';
    }
  }

  void incrementQuantity() {
    _quantity++;
    update();
  }

  void incrementSingleModifier(int index) {
    if ((productModifiers?.singleModifiers?[index].maxAmount ?? 0) >=
        (productModifiers?.singleModifiers?[index].count ?? 0)) {
      productModifiers?.singleModifiers?[index].count =
          (productModifiers?.singleModifiers?[index].count ?? 0) + 1;
    }
    update();
  }

  void decrementSingleModifier(int index) {
    if ((productModifiers?.singleModifiers?[index].count ?? 0) >
        (productModifiers?.singleModifiers?[index].minAmount ?? 1)) {
      productModifiers?.singleModifiers?[index].count =
          (productModifiers?.singleModifiers?[index].count ?? 0) - 1;
    } else {
      if ((productModifiers?.singleModifiers?[index].isCompulsory ?? false) ==
          false) {
        productModifiers?.singleModifiers?[index].isChecked = false;
      }
    }
    update();
  }

  void incrementGroupModifier(int parentIndex, int variantIndex) {
    if ((productModifiers?.groupModifiers?[parentIndex].maxAmount ?? 0) >=
        (productModifiers?.groupModifiers?[parentIndex].variants?[variantIndex]
                .quantity ??
            0)) {
      productModifiers?.groupModifiers?[parentIndex].variants?[variantIndex]
          .quantity = (productModifiers?.groupModifiers?[parentIndex]
                  .variants?[variantIndex].quantity ??
              0) +
          1;
    } else {
      priceOfGroupModifier = 0;
    }
    update();
  }

  void decrementGroupModifier(int parentIndex, int variantIndex) {
    if ((productModifiers?.groupModifiers?[parentIndex].variants?[variantIndex]
                .quantity ??
            0) >
        1) {
      productModifiers?.groupModifiers?[parentIndex].variants?[variantIndex]
          .quantity = (productModifiers?.groupModifiers?[parentIndex]
                  .variants?[variantIndex].quantity ??
              0) -
          1;
    } else {
      productModifiers?.groupModifiers?[parentIndex].variants?[variantIndex]
          .isChecked = false;
      priceOfGroupModifier = 0;
    }
    update();
  }

  void decrementQuantity() {
    if (_quantity > 1) {
      _quantity--;
      update();
    }
  }

  void incrementPriceOfSingleModifier(int index) {
    if (productModifiers?.singleModifiers?[index].isChecked ?? false) {
      priceOfSingleModifier = (double.tryParse(
                  (productModifiers?.singleModifiers?[index].price ?? 0)
                      .toString()) ??
              0) *
          (productModifiers?.singleModifiers?[index].count ?? 0);
    }
    calculateSingleModifier();
    update();
  }

  void incrementPriceOfGroupModifier(int parentIndex, int variantIndex) {
    priceOfGroupModifier = 0;
    productModifiers?.groupModifiers?.forEach((element) {
      element.variants?.forEach((innerElement) {
        if (innerElement.isChecked ?? false) {
          priceOfGroupModifier = priceOfGroupModifier +
              ((innerElement.quantity ?? 0) * (innerElement.outPrice ?? 0));
        }
      });
    });
    update();
  }

  void tabIndex(int propertyIndex, int optionIndex) {
    productById?.properties?[propertyIndex].selectIndex = optionIndex;
    update();
  }

  bool max(int index) {
    if ((productModifiers?.singleModifiers?[index].maxAmount ?? 0) > 1) {
      return true;
    }
    return false;
  }

  void checkedSingleModifier(int index) {
    if ((productModifiers?.singleModifiers?[index].isCompulsory ?? false) ==
        false) {
      productModifiers?.singleModifiers?[index].isChecked =
          !(productModifiers?.singleModifiers?[index].isChecked ?? true);
    }
    productModifiers?.singleModifiers?[index].count =
        (productModifiers?.singleModifiers?[index].minAmount ?? 0) == 0
            ? 1
            : productModifiers?.singleModifiers?[index].minAmount;
    calculateSingleModifier();
    update();
  }

  void calculateSingleModifier() {
    priceOfSingleModifier = 0;
    productModifiers?.singleModifiers?.forEach((element) {
      if (element.isChecked ?? false) {
        priceOfSingleModifier = priceOfSingleModifier +
            ((int.tryParse(element.price ?? '0') ?? 0) * (element.count ?? 0));
        uniqueKey = '${uniqueKey}_${element.id}';
      }
    });
    update();
  }

  void checkedGroupModifier(int parentIndex, int variantIndex) {
    productModifiers?.groupModifiers?[parentIndex].variants?[variantIndex]
        .isChecked = !(productModifiers
            ?.groupModifiers?[parentIndex].variants?[variantIndex].isChecked ??
        true);
    productModifiers
        ?.groupModifiers?[parentIndex].variants?[variantIndex].quantity = 1;
    update();
  }

  void limitedGroupModifiers(int parentIndex, int variantIndex) {
    int overallCount = 0;
    bool isCompulsory =
        productModifiers?.groupModifiers?[parentIndex].isCompulsory ?? false;
    int minAmount =
        productModifiers?.groupModifiers?[parentIndex].minAmount ?? 0;
    int maxAmount =
        productModifiers?.groupModifiers?[parentIndex].maxAmount ?? 0;
    productModifiers?.groupModifiers?[parentIndex].variants?.forEach((element) {
      if (element.isChecked ?? false) {
        overallCount = overallCount + (element.quantity ?? 0);
        uniqueKey = '${uniqueKey}_${element.id}';
      }
    });

    ///selecting minimum number of items in group modifier
    if (overallCount < minAmount && isCompulsory) {
      int count = minAmount - overallCount;
      for (int i = 0;
          i <
              (productModifiers
                      ?.groupModifiers?[parentIndex].variants?.length ??
                  0);
          i++) {
        if (count == 0) {
          break;
        }
        if (!(productModifiers
                ?.groupModifiers?[parentIndex].variants?[i].isChecked ??
            true)) {
          count--;
          checkedGroupModifier(parentIndex, i);
        }
      }
    }

    ///max items selection if selected one item it will remove selection on another item if max count reached
    if (overallCount > maxAmount) {
      int count = overallCount - maxAmount;
      for (int i = 0;
          i <
              (productModifiers
                      ?.groupModifiers?[parentIndex].variants?.length ??
                  0);
          i++) {
        if (count == 0) {
          break;
        }
        if ((productModifiers
                    ?.groupModifiers?[parentIndex].variants?[i].isChecked ??
                false) &&
            i != variantIndex) {
          count--;
          productModifiers?.groupModifiers?[parentIndex].variants?[i].quantity =
              (productModifiers?.groupModifiers?[parentIndex].variants?[i]
                          .quantity ??
                      0) -
                  1;
          if (productModifiers
                  ?.groupModifiers?[parentIndex].variants?[i].quantity ==
              0) {
            checkedGroupModifier(parentIndex, i);
          }
        } else if ((productModifiers
                    ?.groupModifiers?[parentIndex].variants?[i].isChecked ??
                false) &&
            i == variantIndex &&
            (productModifiers
                        ?.groupModifiers?[parentIndex].variants?[i].quantity ??
                    0) >
                maxAmount) {
          productModifiers?.groupModifiers?[parentIndex].variants?[i].quantity =
              maxAmount;
        }
      }
    }
    incrementPriceOfGroupModifier(parentIndex, variantIndex);
  }

  Future<void> getProductModifierV2(String productId) async {
    _productModifiers = null;
    uniqueKey = '';
    setLoading(true);
    final result = await _repository.getProductModifierV2(
      auth: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      productId: productId,
    );
    setLoading(false);
    if (result is ModifierResponse) {
      _productModifiers = result.productModifiers;
      singleModifiersLength =
          result.productModifiers?.singleModifiers?.length ?? 0;
      groupModifiersLength =
          result.productModifiers?.groupModifiers?.length ?? 0;
      for (int i = 0;
          i < (_productModifiers?.groupModifiers?.length ?? 0);
          i++) {
        if ((_productModifiers?.groupModifiers?[i].minAmount ?? 0) > 0 &&
            (_productModifiers?.groupModifiers?[i].isCompulsory ?? false)) {
          limitedGroupModifiers(i, 0);
        }
      }

      for (int i = 0;
          i < (_productModifiers?.singleModifiers?.length ?? 0);
          i++) {
        if (_productModifiers?.singleModifiers?[i].isCompulsory ?? false) {
          _productModifiers?.singleModifiers?[i].isChecked = true;
          checkedSingleModifier(i);
        }
      }
    } else {
      showErrorMessage(result.toString());
    }
    update();
  }

  Future<void> getProductDetailV2(String productId) async {
    setLoading(true);
    final result = await _repository.getProductDetailV2(
      shipperId: AppConstants.shipperId,
      productId: productId,
    );
    if (result is ProductByIdResponse) {
      _productById = result;
      _productById?.properties?.forEach((element) {
        selectedOptionName.add(element.options?[0].title?.ru ?? '');
      });
      if (_productById?.properties?.isNotEmpty ?? false) {
        _hasOptions = true;
      }

      if (_productById?.type == 'combo') {
        _productType = 'combo';
        await getComboV2(_productById?.id ?? '');
      } else {
        _productType = _productById?.type ?? '';
      }
      getOptionsList();
      choosingProductWithOption(0, 0);
      await getProductQuantity();
      if (_productById?.hasModifier ?? false) {
        _hasModifier = true;
        await getProductModifierV2(productId);
      } else if (_hasModifier) {
        await getProductModifierV2(this.productId);
      }
      update();
    } else {
      showErrorMessage(result.toString());
    }
    setLoading(false);
  }

  Future<void> getComboV2(String comboId) async {
    setLoading(true);
    final result = await _repository.getComboV2(
      auth: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      comboId: comboId,
    );

    if (result is ComboResponse) {
      _products = result.groups;
      update();
    } else {
      showErrorMessage(result.toString());
    }
    setLoading(false);
  }

  Future<void> insertProduct() async {
    getHiveUniqueKey();
    String uniqueId = BaseFunctions.stringLengthMax255(hiveUniqueKey);

    productInBasketIds.add(uniqueId);
    var product = basket_products.Products(
      id: productId,
      name: productName?.parseTitle(),
      image: _productById?.image ?? '',
      price: price.toDouble(),
      quantity: _quantity.toDouble(),
      modifiers: modifiers,
      uniqueId: hiveUniqueKey,
      combos: combo,
      type: _productById?.type,
    );
    await _repository.insertProduct(product);

    var ls = await _repository.getAllBasketProductsAsync();
    for (var element in ls) {
      if (element.id == productId) {
        _quantity = element.quantity;
        _basketProduct = element;
      }
    }
    update();
  }

  Future<void> removeProduct(basket_products.Products product) async {
    await _repository.removeProduct(product);
  }

  Future<void> updateQuantity(
      {bool isMinus = false, bool isDelete = false}) async {
    if (isMinus) {
      if ((_basketProduct?.quantity ?? 0) > 1) {
        _basketProduct?.quantity = (_basketProduct?.quantity ?? 0) - 1;
      } else if (isDelete) {
        await _repository.removeProduct(_basketProduct!);
      }
    } else {
      _basketProduct?.quantity = (_basketProduct?.quantity ?? 0) + 1;
    }
    await _repository.updateProduct(_basketProduct!);
    update();
  }

  Future<void> updateFav(
      {bool isMinus = false,
      required int index,
      required pbi.Favourites? favourites}) async {
    var ls = await _repository.getAllBasketProductsAsync();
    for (var element in ls) {
      if (element.uniqueId == (favourites?.id ?? '')) {
        if (isMinus) {
          if (element.quantity > 1) {
            element.quantity = element.quantity - 1;
            favQuantity = element.quantity.toInt();
          } else {
            favourites?.quantity = 0;
            var product = basket_products.Products(
              id: favourites?.id ?? '',
              image: favourites?.image ?? '',
              name: favourites?.title?.parseTitle(),
              price:
                  double.tryParse((favourites?.outPrice ?? 0.0).toString()) ??
                      0.0,
              quantity: 1,
              uniqueId: favourites?.id ?? '',
              modifiers: [],
            );
            await _repository.removeProduct(product);
          }
        } else {
          element.quantity = element.quantity + 1;
          favQuantity = element.quantity.toInt();
        }
        var product = basket_products.Products(
          id: favourites?.id ?? '',
          image: favourites?.image ?? '',
          name: favourites?.title?.parseTitle(),
          price:
              double.tryParse((favourites?.outPrice ?? 0.0).toString()) ?? 0.0,
          quantity: element.quantity,
          uniqueId: favourites?.id ?? '',
          modifiers: [],
        );
        await _repository.updateProduct(product);
      }
    }
    update();
  }

  ProductByIdResponse? get productById => _productById;

  ProductModifiers? get productModifiers => _productModifiers;

  basket_products.Products? get basketProduct => _basketProduct;

  num get quantity => _quantity;

  bool get hasOptions => _hasOptions;

  bool get hasModifier => _hasModifier;

  FavouriteDetailRepository? get repository => _repository;

  List<cr.Groups>? get products => _products;

  String get productType => _productType;
}
