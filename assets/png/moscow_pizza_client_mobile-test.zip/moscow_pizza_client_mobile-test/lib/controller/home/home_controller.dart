import 'dart:convert';

import 'package:moscow_pizza_client_mobile/data/hive/delivery_address_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/hive/pick_up_branch_hive_model.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/keys/app_keys.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/banners_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_id_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/products_v2_response.dart'
    as pv2;
import 'package:moscow_pizza_client_mobile/data/models/reviews_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/user_reviews_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/user_update_reviews_request.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';
import 'package:moscow_pizza_client_mobile/data/repository/orders_repository.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/routes/args/add_comment_page_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/widgets/choose_reason_bottom_sheet.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/widgets/congratulations_dialog.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/success_dialog.dart';

import '../../data/models/category_v2_response.dart' as cv2;
import '../../data/models/my_address_response.dart';

class HomeController extends BaseController {
  final HomeRepository repository;

  final OrdersRepository ordersRepository;
  final LocalSource _localSource = LocalSource.instance;

  HomeController({
    required this.repository,
    required this.ordersRepository,
  });

  List<Banners> _banners = [];
  List<cv2.Categories> _categoriesV2 = [];
  List<Reviews> _reviews = [];
  List<Orders> _orders = [];
  CustomerAddresses? _currentAddress;
  List<CustomerAddresses> _customerAddresses = [];
  int _index = 0;
  int _bannersIndex = 0;
  int _oldCheckedIndex = -1;
  String _menuId = '';
  String _branchId = '';

  DeliveryAddressHiveModel? _deliveryAddress;
  PickUpBranchHiveModel? _pickUpBranch;
  final scrollController = ScrollController();
  final PageController pageController = PageController(
    viewportFraction: 0.95,
  );

  @override
  Future<void> onInit() async {
    super.onInit();
    await Future.wait(
      [
        getDeliveryType(),
        getBanners(),
        getCategoryWithProductsV2(),
      ],
    );
    // if (LocalSource.instance.hasProfile()) {
    //   getMyAddress();
    // }
  }

  @override
  Future<void> onReady() async {
    super.onReady();
    await Future.wait(
      [
        _getMenuId(),
        orderDialog(),
      ],
    );
  }

  Future<void> _getMenuId() async {
    _menuId = await _localSource.getMenuId();
  }

  Future<void> orderDialog() async {
    final result = await orders();
    if (result) {
      final t = await Get.dialog(
        CongratulationsDialog(
          onDone: () async {
            await review('like');
            final r = await Get.bottomSheet(
              ChooseReasonBottomSheet(
                value: LocalSource.instance.locale == 'ru'
                    ? reviews[index].message?.ru
                    : reviews[index].message?.uz,
                list: reviews,
                onAddComment: () async {
                  final back = await Get.toNamed(AppRoutes.addComments,
                      arguments: AddCommentPageArguments(
                          order: order[0], type: 'like'));
                  if (back) Get.back(result: true);
                },
                onTap: (index) {},
                onDone: () async {
                  if (order.isNotEmpty) {
                    final result = await createUserReview(
                      order[0],
                      type: 'like',
                      reviewId: reviews[index].id,
                      message: LocalSource.instance.locale == 'ru'
                          ? reviews[index].message?.ru
                          : reviews[index].message?.uz,
                      relatedSubject: reviews[index].relatedSubject,
                    );
                    if (result) Get.back(result: true);
                  } else {
                    Get.back(result: true);
                  }
                },
              ),
              backgroundColor: AppColors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                  topLeft: AppUtils.kRadius16,
                  topRight: AppUtils.kRadius16,
                ),
              ),
              isScrollControlled: true,
            );
            if (r) Get.back(result: true);
          },
          onCancel: () async {
            await review('dislike');
            final r = await Get.bottomSheet(
              ChooseReasonBottomSheet(
                value: LocalSource.instance.locale == 'ru'
                    ? reviews[index].message?.ru
                    : reviews[index].message?.uz,
                list: reviews,
                onAddComment: () async {
                  final back = await Get.toNamed(
                    AppRoutes.addComments,
                    arguments: AddCommentPageArguments(
                        order: order[0], type: 'dislike'),
                  );
                  if (back) Get.back(result: true);
                },
                onTap: (index) {
                  setIndex(index);
                },
                onDone: () async {
                  final result = await createUserReview(
                    order[0],
                    type: 'dislike',
                    reviewId: reviews[index].id,
                    message: LocalSource.instance.locale == 'ru'
                        ? reviews[index].message?.ru
                        : reviews[index].message?.uz,
                    relatedSubject: reviews[index].relatedSubject,
                  );
                  if (result) Get.back(result: true);
                },
              ),
              backgroundColor: AppColors.white,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(16),
                  topRight: Radius.circular(16),
                ),
              ),
              isScrollControlled: true,
            );
            if (r != null) Get.back(result: true);
          },
        ),
      );
      if (t != null) await Get.dialog(const SuccessDialog());
    }
  }

  void setIndex(int i) {
    _index = i;
    update();
  }

  void setBannersIndex(int i) {
    _bannersIndex = i;
    update();
  }

  void customerClear() {
    _currentAddress = null;
    _customerAddresses = [];
    update();
  }

  void setAddressChecked(int index) {
    if (_oldCheckedIndex != -1) {
      _customerAddresses[_oldCheckedIndex].isChecked = false;
    }
    _customerAddresses[index].isChecked = true;
    _oldCheckedIndex = index;
    _currentAddress = _customerAddresses[index];
    update();
  }

  Future<void> getDeliveryType() async {
    await Future.wait([
      _getDeliveryAddress(),
      _getPickUpBranch(),
      _getMenuId(),
    ]);
  }

  Future<void> _getDeliveryAddress() async {
    DeliveryAddressHiveModel? address = await _localSource.getDeliveryAddress();
    if (address == null) return;
    _pickUpBranch = null;
    _deliveryAddress = address;
    _branchId = _deliveryAddress?.branchId ?? '';
    update();
  }

  Future<void> _getPickUpBranch() async {
    PickUpBranchHiveModel? branch = await _localSource.getPickUpBranch();
    if (branch == null) return;
    _deliveryAddress = null;
    _pickUpBranch = branch;
    _branchId = _pickUpBranch?.branchId ?? '';
    update();
  }

  Future<void> getBanners() async {
    String? value = _localSource.getKey(AppKeys.bannersCache);
    if (value != null && value.isNotEmpty) {
      _banners = [];
      for (final banner in jsonDecode(value) as Iterable) {
        _banners.add(Banners.fromJson(banner));
      }
      update();
    }
    final result = await repository.getBanners(
      shipperId: AppConstants.shipperId,
    );
    if (result is BannersResponse) {
      if (_banners == result.banners) return;
      _banners = result.banners;
      update();
      await LocalSource.instance.setKey(
        AppKeys.bannersCache,
        jsonEncode(_banners.map((v) => v.toJson()).toList()),
      );
    } else {
      // showErrorMessage(result.toString());
    }
  }

  Future<void> getCategoryWithProductsV2() async {
    setLoading(true);
    String? value = _localSource.getKey(AppKeys.productCache);
    if (value != null && value.isNotEmpty) {
      late List<cv2.Categories> list = [];
      for (final category in jsonDecode(value) as Iterable) {
        list.add(cv2.Categories.fromJson(category));
      }
      _categoriesV2 = list;
      update();
    }
    setLoading(_categoriesV2.isEmpty);
    final String menuId = await _localSource.getMenuId();
    final result = await repository.getCategoryWithProductsV2(
      shipperId: AppConstants.shipperId,
      menuId: menuId,
      clientId: _localSource.getCustomer().id ?? '',
      isOnlyDelivery: _deliveryAddress != null,
      isOnlySelfPickUp: _pickUpBranch != null,
      branchId: _branchId,
    );
    setLoading(false);
    if (result is cv2.CategoryV2Response) {
      final list = result.categories!.where((element) {
        if ((element.products.isNotEmpty) ||
            (element.childCategories.isNotEmpty)) {
          return true;
        } else {
          return false;
        }
      }).toList();
      // if (_categoriesV2 == list) return;
      _categoriesV2 = list;
      update();
      await LocalSource.instance.setKey(
        AppKeys.productCache,
        jsonEncode(_categoriesV2.map((v) => v.toJson()).toList()),
      );
    } else {
      // showErrorMessage(result.toString());
      setLoading(false);
    }
  }

  Future<void> refreshCategoryWithProductsV2() async {
    await getCategoryWithProductsV2();
    update();
  }

  void setCategories(List<cv2.Categories> categories) {
    _categoriesV2 = categories;
    update();
  }

  Future<List<pv2.Products>> searchProductV2(String? search) async {
    setLoading(true);
    final result = await repository.getSearchProductsV2(
      shipperId: AppConstants.shipperId,
      search: search ?? '',
    );
    setLoading(false);
    if (result is pv2.ProductsV2Response) {
      return result.products ?? [];
    } else {
      showErrorMessage(result.toString());
      return [];
    }
  }

  Future<bool> orders() async {
    String token = _localSource.getAccessToken();
    if (token.isNotEmpty) {
      final result = await ordersRepository.getOrdersReview(
        token: token,
        reviewSeen: false,
      );
      if (result is OrdersResponse) {
        _orders = result.orders;
        update();
        return result.orders.isNotEmpty;
      } else {
        // showErrorMessage(result.toString());
        return false;
      }
    } else {
      return false;
    }
  }

  Future<void> review(String type) async {
    setLoading(true);
    String token = _localSource.getAccessToken();

    final result = await repository.review(
      token: token,
      page: 1,
      limit: 10,
    );
    setLoading(false);
    if (result is ReviewsResponse) {
      _reviews = [];
      for (var element in result.reviews) {
        if (element.type == type) _reviews.add(element);
      }
      update();
    } else {
      showErrorMessage(result.toString());
      return;
    }
  }

  Future<bool> createUserReview(
    Orders orders, {
    String? type,
    String? message,
    String? relatedSubject,
    String? reviewId,
  }) async {
    setLoading(true);
    String token = _localSource.getAccessToken();
    UserReviewsRequest request = UserReviewsRequest(
      branchId: orders.steps[0].branchId,
      branchName: orders.steps[0].branchName,
      clientId: orders.clientId,
      clientName: orders.clientName,
      courierId: orders.courierId,
      clientPhone: orders.clientPhoneNumber,
      courierName:
          "${orders.courier?.firstName ?? ""} ${orders.courier?.lastName ?? ""}",
      lang: 'ru',
      operatorId: '',
      id: orders.id,
      orderNum: orders.externalOrderId,
      operatorName: '',
      type: type,
      reviewId: reviewId ?? '',
      reviewMessage: message ?? '',
      relatedSubject: relatedSubject ?? '',
    );
    final result = await repository.createUserReview(
      token: token,
      request: request,
    );
    if (result is BaseIdResponse) {
      final result1 = await repository.updateUserReview(
        orderId: orders.id ?? '',
        token: token,
        request: UserUpdateReviewsRequest(
          userId: orders.clientId,
          seen: true,
        ),
      );
      setLoading(false);
      if (result1 is BaseResponse) return true;
      return false;
    } else {
      setLoading(false);
      showErrorMessage(result.toString());
      return false;
    }
  }

  Future<void> getMyAddress() async {
    final result = await repository.getMyAddress(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      customerId: _localSource.getCustomer().id ?? '',
      page: 1,
      limit: 100,
    );
    if (result is MyAddressResponse) {
      _customerAddresses = result.customerAddresses ?? [];
      if (_customerAddresses.isNotEmpty) {
        _currentAddress = customerAddresses[0];
        setAddressChecked(0);
      } else {
        _currentAddress = null;
      }
      update();
    } else {
      // showErrorMessage(result.toString());
    }
  }

  void changeIsCheckedCategory(int index) {
    _categoriesV2[index] = _categoriesV2[index].copyWith(
      isChecked: !(_categoriesV2[index].isChecked ?? true),
    );
    update();
  }

  List<Banners> get banners => _banners;

  List<cv2.Categories> get categories => _categoriesV2;

  List<Reviews> get reviews => _reviews;

  List<Orders> get order => _orders;

  int get index => _index;

  int get bannersIndex => _bannersIndex;

  DeliveryAddressHiveModel? get deliveryAddress => _deliveryAddress;

  PickUpBranchHiveModel? get pickUpBranch => _pickUpBranch;

  String get menuId => _menuId;

  List<CustomerAddresses> get customerAddresses => _customerAddresses;

  CustomerAddresses? get currentAddress => _currentAddress;

  LocalSource? get localeSource => _localSource;

  List<cv2.Categories> get checkedCategories =>
      _categoriesV2.where((element) => element.isChecked ?? false).toList();
}
