import 'dart:io';

import 'package:moscow_pizza_client_mobile/core/mixins/yandex_location.dart';
import 'package:moscow_pizza_client_mobile/data/hive/delivery_address_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/hive/pick_up_branch_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/models/order_discount_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_discount_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/products_statuses_response.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/date_picker/time_picker.dart';
import 'package:moscow_pizza_client_mobile/core/keys/analytic_keys.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/compute_price_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/compute_price_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/create_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/map/address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

import '../../../core/custom_widgets/text_fields/always_disabled_focus_node.dart';
import '../../../core/mixins/permissions.dart';
import '../../../data/hive/products.dart' as basket;
import '../../../data/models/shipper_response.dart';
import '../../../routes/args/chekout_arguments.dart';

class CheckoutOrderController extends BaseController
    with GetTickerProviderStateMixin, PermissionsMixin, YandexLocation {
  final HomeRepository _repository;

  CheckoutOrderController(this._repository);

  late AnimationController animationController;
  final LocalSource _localSource = LocalSource.instance;
  late TabController tabController;
  final RxString _payment = PaymentType.cash.toString().obs;
  DeliveryType _deliveryType = DeliveryType.delivery;
  DeliveryTime _deliveryTime = DeliveryTime.fastDelivery;
  List<Branches> _branches = [];
  ComputePriceResponse? _computePriceResponse;
  int _generalSum = 0;
  int _generalSumWithDiscount = 0;
  List<String> discountNames = [];
  List<MapObject> _mapObjects = [];
  late YandexMapController _mapController;
  List<basket.Products> _productsList = [];
  final List<String> _listOfStopListIds = [];
  final MapObjectId targetMapObjectId = const MapObjectId('target_place_mark');
  Point _myPoint = const Point(latitude: 41.311081, longitude: 69.240562);
  Point _branchPoint = const Point(latitude: 41.311081, longitude: 69.240562);
  Map<String, dynamic> _data = {};
  DateTime dateTime = DateTime(
    DateTime.now().year,
    DateTime.now().month,
    DateTime.now().day,
  );
  Position? _locationData;
  bool _isNoProductsInBranch = false;
  bool? _isFastDelivery = true;
  DateTime _futureTime = DateTime.now();
  DateTime _tempTime = DateTime.now();
  final bool _isMapLoading = false;
  final RxBool _errorEntrance = false.obs;
  final RxBool _errorFloor = false.obs;
  final RxBool _errorApartment = false.obs;
  final FocusNode dateOfBirthFocus = AlwaysDisabledFocusNode();
  String? _shipperFutureTime;
  final TimeOfDay _time = TimeOfDay.now().replacing(minute: 30);
  List<CustomerAddresses> _customerAddresses =
      Get.find<HomeController>().customerAddresses;
  dynamic _minimalOrderPrice = 0;
  CustomerAddresses? _currentAddress;
  Branches? _selectedBranch;
  final _animation = const MapAnimation();
  final RxBool _callStatus = true.obs;
  String selectedBranchId = '';

  final TextEditingController addressController = TextEditingController();
  final TextEditingController apartmentController = TextEditingController();
  final TextEditingController entranceController = TextEditingController();
  final TextEditingController floorController = TextEditingController();
  final TextEditingController myAddressesController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final RxBool _load = true.obs;

  double productsDiscounts = 0;

  @override
  void onInit() {
    super.onInit();
    _load.value = true;
    tabController = TabController(length: 2, vsync: this);
    animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
  }

  @override
  Future<void> onReady() async {
    super.onReady();
    await Future.wait([
      getMyAddress(),
      _checkDeliveryType(),
      getShipper(),
      getOrderDiscount(1),
      getProductDiscount(),
    ]);
    _futureTime = DateTime.now().add(
      Duration(minutes: int.tryParse(_shipperFutureTime ?? '0') ?? 0),
    );
    dateTime = DateTime(_futureTime.year, _futureTime.month, _futureTime.day);
    dateController.text =
    "${_futureTime.day.toString().padLeft(2, '0')}.${_futureTime.month.toString().padLeft(2, '0')}.${_futureTime.year}";
    _load.value = false;
  }

  bool isAnyProductInStopList() {
    if (_listOfStopListIds.isNotEmpty || _isNoProductsInBranch) {
      showErrorMessage(
        'Продукт на стоп-листе',
        duration: const Duration(seconds: 1),
      );
      return true;
    }
    return false;
  }

  void checkFieldsRequirement() {
    if (entranceController.text.isEmpty) {
      _errorEntrance.value = true;
    } else {
      _errorEntrance.value = false;
    }
    if (floorController.text.isEmpty) {
      _errorFloor.value = true;
    } else {
      _errorFloor.value = false;
    }
    if (apartmentController.text.isEmpty) {
      _errorApartment.value = true;
    } else {
      _errorApartment.value = false;
    }
  }

  void setAddressChecked(int index) {
    _currentAddress = _customerAddresses[index];
    myAddressesController.text = _currentAddress?.address ?? '';
    setCurrentAddressData();
    findCurrentAddressLocation();
    update();
  }

  void setCurrentAddressData() {
    myAddressesController.text = _currentAddress?.name ?? '';
    apartmentController.text = _currentAddress?.apartment ?? '';
    entranceController.text = _currentAddress?.building ?? '';
    floorController.text = _currentAddress?.floor ?? '';
    addressController.text = BaseFunctions.addressFormatter(
      _currentAddress?.address ?? '',
    );
  }

  Future<void> selectFutureTime(BuildContext context, String time) async {
    DateTime selectedTime =
    DateTime.now().add(Duration(minutes: int.tryParse(time) ?? 0));
    List<String> schedule = dateController.text.split('.');
    schedule = schedule.length > 1
        ? dateController.text.split('.')
        : [
      DateTime.now().day.toString(),
      DateTime.now().month.toString(),
      DateTime.now().year.toString()
    ];
    await TimePicker.showTimePicker(
      context,
      onDateTimeChanged: (time) {
        _tempTime = time;
      },
      currentTime: _tempTime,
      onConfirm: () {
        if (DateTime.now().day == (int.tryParse(schedule[0]) ?? 0) &&
            DateTime.now().month == (int.tryParse(schedule[1]) ?? 0) &&
            DateTime.now().year == (int.tryParse(schedule[2]) ?? 0)) {
          if ((_tempTime.hour) < selectedTime.hour) {
            showFutureTimeSnackBar(selectedTime);
          } else {
            if (_tempTime.hour == selectedTime.hour) {
              if (_tempTime.minute < selectedTime.minute) {
                showFutureTimeSnackBar(selectedTime);
              } else {
                setFutureTime(
                    context,
                    DateFormat('dd.MM.yyyy').parse(dateController.text),
                    time,
                    _tempTime);
              }
            } else {
              setFutureTime(
                  context,
                  DateFormat('dd.MM.yyyy').parse(dateController.text),
                  time,
                  _tempTime);
            }
          }
        } else {
          if (DateTime.now()
              .add(Duration(
              minutes:
              int.tryParse(_shipperFutureTime ?? '0') ?? 0))
              .day ==
              (int.tryParse(schedule[0]) ?? 0) &&
              DateTime.now()
                  .add(Duration(
                  minutes:
                  int.tryParse(_shipperFutureTime ?? '0') ?? 0))
                  .month ==
                  (int.tryParse(schedule[1]) ?? 0) &&
              DateTime.now()
                  .add(Duration(
                  minutes:
                  int.tryParse(_shipperFutureTime ?? '0') ?? 0))
                  .year ==
                  (int.tryParse(schedule[2]) ?? 0)) {
            if ((_tempTime.hour) < selectedTime.hour) {
              showFutureTimeSnackBar(selectedTime);
            } else {
              if (_tempTime.hour == selectedTime.hour) {
                if (_tempTime.minute < selectedTime.minute) {
                  showFutureTimeSnackBar(selectedTime);
                } else {
                  setFutureTime(
                    context,
                    DateFormat('dd.MM.yyyy').parse(dateController.text),
                    time,
                    _tempTime,
                  );
                }
              } else {
                setFutureTime(
                  context,
                  DateFormat('dd.MM.yyyy').parse(dateController.text),
                  time,
                  _tempTime,
                );
              }
            }
          } else {
            setFutureTime(
              context,
              DateFormat('dd.MM.yyyy').parse(dateController.text),
              time,
              _tempTime,
            );
          }
        }
        update();
      },
    );
  }

  List<String> months = [
    'january'.tr,
    'february'.tr,
    'march'.tr,
    'april'.tr,
    'may'.tr,
    'june'.tr,
    'july'.tr,
    'august'.tr,
    'september'.tr,
    'october'.tr,
    'november'.tr,
    'december'.tr
  ];

  void setFutureTime(BuildContext context, DateTime selectedTime, String time,
      DateTime futTime) {
    dateTime = selectedTime;
    _futureTime = futTime;
    update();
    Navigator.of(context).pop();
  }

  void showFutureTimeSnackBar(DateTime selectedTime) {
    Get.snackbar(
      'please'.tr,
      LocalSource.instance.locale == 'uz'
          ? "${selectedTime.day} ${months[selectedTime.month - 1]} ${selectedTime.hour}:${selectedTime.minute} ${"time_choose".tr}"
          : "${"time_choose".tr} ${selectedTime.day} ${months[selectedTime.month - 1]} ${selectedTime.hour}:${selectedTime.minute}",
      colorText: AppColors.white,
      snackPosition: SnackPosition.TOP,
      backgroundColor: AppColors.red,
    );
  }

  void setGeneralSum(num value) {
    _generalSum = value.toInt();
  }

  void setCallStatus(bool value) {
    _callStatus.value = value;
  }

  void setFastDelivery(bool value) {
    _isFastDelivery = value;
    update();
  }

  void setPayment(String value) {
    _payment.value = value;
    getOrderDiscount(2);
  }

  void setDelivery(DeliveryType value) {
    _deliveryType = value;
    update();
  }

  void setProducts(List<basket.Products> value) {
    _productsList = value;
    update();
  }

  Future<void> setSelectedBranch(int index) async {
    if (_selectedBranch?.id == _branches[index].id) return;
    _selectedBranch = _branches[index];
    await findChosenBranchLocation();
    if (_selectedBranch?.menuId != null) {
      await getProductsStatuses(
        newMenuId: _selectedBranch?.menuId ?? '',
        index: 1,
      );
    }
    update();
    await getOrderDiscount(3);
    await getProductDiscount();
  }

  void setIsFastDelivery(DeliveryTime value) {
    _deliveryTime = value;
    update();
  }

  void setMapController(YandexMapController ctr) {
    _mapController = ctr;
    update();
  }

  void setDataValue(Map<String, dynamic> value) {
    _data = value;
    _myPoint = _data['point'];
    update();
    findMyLocation();
  }

  Future<void> findChosenBranchLocation() async {
    _branchPoint = Point(
      latitude: (_selectedBranch?.location?.lat ?? 0.0).toDouble(),
      longitude: (_selectedBranch?.location?.long ?? 0.0).toDouble(),
    );
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: _branchPoint, zoom: 18),
      ),
      animation: _animation,
    );
    await setMapObject(_branchPoint);
  }

  Future<void> findCurrentAddressLocation() async {
    _myPoint = Point(
      latitude: (_currentAddress?.location?.lat ?? 0.0).toDouble(),
      longitude: (_currentAddress?.location?.long ?? 0.0).toDouble(),
    );
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: _myPoint, zoom: 18),
      ),
      animation: _animation,
    );
    await setMapObject(_myPoint);
  }

  Future<void> findMyLocation() async {
    if (await hasPermission()) {
      final pos = await Geolocator.getCurrentPosition();
      _myPoint = Point(latitude: pos.latitude, longitude: pos.longitude);
    }
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: _myPoint,
          zoom: 18,
        ),
      ),
      animation: _animation,
    );
    await setMapObject(_myPoint);
  }

  Future<void> getOrderDiscount(int index) async {
    if (_selectedBranch?.id != null) {
      _generalSumWithDiscount = _generalSum;
      discountNames = [];
      final result = await _repository.getOrderDiscount(
        shipperId: AppConstants.shipperId,
        orderSource: Platform.isIOS ? 'ios' : 'android',
        branchId: _selectedBranch?.id ?? 'null',
        paymentType: _payment.value == PaymentType.cash.toString()
            ? 'cash'
            : _payment.value == PaymentType.click.toString()
            ? 'click'
            : 'payme',
        isOnlyDelivery: (_deliveryType == DeliveryType.delivery).toString(),
        isOnlySelfPickUp: (_deliveryType == DeliveryType.selfPickup).toString(),
        forOrderAmount: _generalSum,
        deliveryPrice: _deliveryType == DeliveryType.delivery
            ? (_computePriceResponse?.price ?? 0).toInt()
            : 0,
        clientId: _localSource.getCustomer().id ?? '',
      );
      if (result is OrderDiscountResponse) {
        _generalSumWithDiscount =
            _generalSum + (result.allDiscountPrice ?? 0).toInt();
        for (OrderDiscounts item in result.discounts ?? []) {
          var locale = _localSource.locale;
          var discountName = locale == 'en'
              ? item.discountTitle?.en
              : locale == 'ru'
              ? item.discountTitle?.ru
              : item.discountTitle?.uz;
          discountNames.add(discountName ?? 'Null');
        }
        update();
      }
    }
  }

  Future<void> getProductDiscount() async {
    if (_selectedBranch?.id != null) {
      final result = await _repository.getProductDiscount(
        shipperId: AppConstants.shipperId,
        orderSource: Platform.isIOS ? 'ios' : 'android',
        branchId: _selectedBranch?.id ?? 'null',
        productIds: List.generate(
            _productsList.length, (index) => _productsList[index].id),
        paymentType: _payment.value == PaymentType.cash.toString()
            ? 'cash'
            : _payment.value == PaymentType.click.toString()
            ? 'click'
            : 'payme',
        isOnlyDelivery: (_deliveryType == DeliveryType.delivery).toString(),
        isOnlySelfPickUp: (_deliveryType == DeliveryType.selfPickup).toString(),
        forOrderAmount: _generalSum,
        deliveryPrice: _deliveryType == DeliveryType.delivery
            ? (_computePriceResponse?.price ?? 0).toInt()
            : 0,
        clientId: _localSource.getCustomer().id ?? '',
      );
      if (result is ProductDiscountResponse) {
        productsDiscounts = 0;
        for (final ProductWithDiscount productDiscount
        in result.productWithDiscount ?? []) {
          for (final ProductDiscount discount
          in productDiscount.discounts ?? []) {
            productsDiscounts += discount.discountPrice ?? 0;
          }
        }
        update();
      }
    }
  }

  Future<void> getTheNearestBranches() async {
    setLoading(true);
    if (await hasPermission()) {
      try {
        _locationData = await Geolocator.getCurrentPosition();
      } catch (e) {
        debugPrint('e: $e');
      }
    } else {
      bool t = await Geolocator.openLocationSettings();
      if (t) {
        try {
          _locationData = await Geolocator.getCurrentPosition();
        } catch (e) {
          debugPrint('e: $e');
        }
      }
    }
    final result = await _repository.getNearBranches(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      lat: (_myPoint.latitude).toString(),
      long: (_myPoint.longitude).toString(),
    );
    setLoading(false);
    if (result is BranchesResponse) {
      if (result.branches.isEmpty) {
        showErrorMessage('company_not_working_time'.tr);
      }
      _branches = result.branches;
      double orderPrice = 0;
      double modPrice = 0;
      for (var t in _productsList) {
        modPrice = 0;
        t.modifiers?.forEach((element) {
          modPrice =
              modPrice + (element.modifiersPrice * element.modifierQuantity);
        });
        orderPrice = orderPrice + ((t.price + modPrice) * t.quantity);
      }
      if (_branches.isNotEmpty) {
        _selectedBranch ??= _branches.first;
        var request = ComputePriceRequest(
          branchId: result.branches.first.id ?? '',
          lat: _myPoint.latitude,
          long: _myPoint.longitude,
          orderPrice: orderPrice,
        );
        await patchComputePrice(request);
        await getOrderDiscount(4);
        await getProductDiscount();
      }
      update();
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> patchComputePrice(
      ComputePriceRequest computePriceRequest) async {
    setLoading(true);
    final result = await _repository.patchComputePrice(
      token: _localSource.getAccessToken(),
      request: computePriceRequest,
    );
    setLoading(false);
    if (result is ComputePriceResponse) {
      _computePriceResponse = result;
      update();
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> getShipper() async {
    setLoading(true);
    final result =
    await _repository.getShipper(shipperId: AppConstants.shipperId);
    setLoading(false);
    if (result is ShipperResponse) {
      _shipperFutureTime = result.futureOrderTime;
      update();
    } else {
      showErrorMessage(result.toString());
    }
  }

  Future<void> _checkPickUpBranch() async {
    PickUpBranchHiveModel? pickUpBranch = await _localSource.getPickUpBranch();
    if (pickUpBranch == null) {
      return;
    }
    _deliveryType = DeliveryType.selfPickup;
    tabController.animateTo(_deliveryType.index);
    _selectedBranch = Branches(
      id: pickUpBranch.branchId,
      name: pickUpBranch.branchName,
      location: BranchLocation(
        long: pickUpBranch.longitude,
        lat: pickUpBranch.latitude,
      ),
    );
    update();
  }

  Future<void> _checkDeliveryAddress() async {
    DeliveryAddressHiveModel? deliveryAddress =
    await _localSource.getDeliveryAddress();
    if (deliveryAddress == null) {
      return;
    }
    _currentAddress = CustomerAddresses(
      name: deliveryAddress.addressName,
      location: LocationModel(
        lat: deliveryAddress.latitude,
        long: deliveryAddress.longitude,
      ),
    );
    _deliveryType = DeliveryType.delivery;
    tabController.animateTo(_deliveryType.index);
    addressController.text = _currentAddress?.name ?? '';
    update();
  }

  Future<void> _checkDeliveryType() async {
    await Future.wait([
      _checkDeliveryAddress(),
      _checkPickUpBranch(),
    ]);
  }

  Future<bool> getMyAddress() async {
    setLoading(true);
    final result = await _repository.getMyAddress(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      customerId: _localSource.getCustomer().id ?? '',
      page: 1,
      limit: 100,
    );
    setLoading(false);
    if (result is MyAddressResponse) {
      _minimalOrderPrice = result.minimalOrderPrice ?? 0;
      _customerAddresses = result.customerAddresses ?? [];
      if (_customerAddresses.isEmpty) {}
      update();
      return true;
    } else {
      showErrorMessage(result.toString());
    }
    return false;
  }

  Future<bool> postMyAddress(Map data) async {
    var request = MyAddressRequest(
      name: data['my_address'] ?? '',
      address: data['to_address'],
      apartment: data['apartment'] ?? '',
      building: data['building'] ?? '',
      customerId: LocalSource.instance.getCustomer().id,
      description: '',
      floor: data['floor'] ?? '',
      location: ToLocation(
        lat: data['lat'] ?? 41.309022097090235,
        long: data['long'] ?? 69.24136827883606,
      ),
    );
    setLoading(true);
    final result = await _repository.postMyAddress(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      request: request,
    );
    setLoading(false);
    if (result is CreateAddressResponse) {
      var res = await getMyAddress();
      return res;
    } else {
      showErrorMessage(result.toString());
    }
    return false;
  }

  Future<String> addOnDemandOrder(CheckoutArguments? args) async {
    // debugPrint('==== ${_minimalOrderPrice}');
    if (_deliveryType == DeliveryType.delivery) {
      // if (_data.isEmpty ||
      //     _data['to_address'].toString() == "" ||
      //     _data['to_address'].toString() == 'null') {
      //   Get.snackbar(
      //     "error".tr,
      //     "company_not_working_time".tr,
      //     duration: const Duration(seconds: 3),
      //     backgroundColor: AppColors.red,
      //     colorText: AppColors.white,
      //   );
      //   return '0';
      // }
      if ((args?.allPrice ?? 0) < _minimalOrderPrice) {
        await Get.dialog(
          Dialog(
            backgroundColor: Colors.transparent,
            child: Material(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'attention'.tr,
                      style: styNoInternetTitle,
                    ),
                    const SizedBox(height: 7),
                    Text(
                      'min_price'
                          .tr
                          .replaceAll('{str(minimalPrice)}',
                          BaseFunctions.moneyFormat(args?.allPrice ?? 0))
                          .replaceAll('{str(shipper.minimal_order_price)}',
                          BaseFunctions.moneyFormat(_minimalOrderPrice)),
                      textAlign: TextAlign.center,
                      style: styProfileCondensationPolicySubText.copyWith(
                          color: const Color(0xff303940)),
                    ),
                    AppUtils.kBoxHeight12,
                    CustomButton(
                      text: 'Ok',
                      onTap: Get.back,
                    )
                  ],
                ),
              ),
            ),
          ),
          barrierDismissible: false,
        );
        return '0';
      }
    }
    if (deliveryType == DeliveryType.selfPickup) {
      if (_selectedBranch == null) {
        showErrorMessage(
          'please_select_branch'.tr,
        );
        return '0';
      }
    }
    setLoading(true);
    var customer = _localSource.getCustomer();
    if (_deliveryType == DeliveryType.delivery) {
      final result = await _repository.getNearBranches(
        token: customer.accessToken ?? '',
        shipperId: AppConstants.shipperId,
        lat: _myPoint.latitude.toString(),
        long: _myPoint.longitude.toString(),
      );
      if (result is BranchesResponse) {
        if (result.branches.isEmpty) {
          showErrorMessage(result.toString());
          setLoading(false);
          return '0';
        }
      } else {
        showErrorMessage(result.toString());
        return '0';
      }
    }
    List<OrdersProducts> list = [];
    List<String> numbers = [];
    for (var t in _productsList) {
      numbers = t.quantity.toString().split('.');
      List<Modifiers> listModifier = [];
      List<OrdersVariants> listOrdersVariants = [];
      t.modifiers?.forEach((element) {
        listModifier.add(Modifiers(
          modifierId: element.modifierId,
          modifierName: element.modifierName?.parseTitle(),
          modifierQuantity:
          (element.modifierQuantity * (int.tryParse(numbers.first) ?? 1))
              .toString(),
          modifiersPrice: element.modifiersPrice.toString(),
          parentId: element.parentId,
        ));
      });
      t.combos?.forEach((element) {
        listOrdersVariants.add(
          OrdersVariants(
            groupId: element.groupId,
            variantId: element.variantId,
            quantity: element.quantity,
          ),
        );
      });
      list.add(
        OrdersProducts(
          description: '',
          quantity: t.quantity,
          price: t.price.toString(),
          productId: t.id,
          modifiers: listModifier,
          variants: listOrdersVariants,
          type: t.type,
        ),
      );
    }
    // if (_delivery == DeliveryType.delivery &&
    //     AppConstants.shipperId != 'd4b1658f-3271-4973-8591-98a82939a664') {
    //   list.add(
    //     OrdersProducts(
    //       description: '',
    //       price: 9000,
    //       productId: 'faf3bd77-05f6-47b0-ae89-d7e97aff9d60',
    //       quantity: 1,
    //     ),
    //   );
    // }
    var steps = Steps(
      branchId: _deliveryType == DeliveryType.selfPickup
          ? _selectedBranch != null
          ? _selectedBranch?.id
          : ''
          : _branches.first.id ?? '',
      description: '',
      products: list,
    );
    List<String> schedule = dateController.text.split('.');
    OnDemandOrderRequest request = OnDemandOrderRequest(
      apartment: apartmentController.text,
      aggregatorId: '',
      building: entranceController.text,
      floor: floorController.text,
      toAddress: addressController.text,
      toLocation: ToLocation(
        lat: _myPoint.latitude,
        long: _myPoint.longitude,
      ),
      clientId: customer.id,
      coDeliveryPrice: AppConstants.deliveryPrice,
      deliveryType:
      _deliveryType == DeliveryType.delivery ? 'delivery' : 'self-pickup',
      deliveryTime: '',
      description: args?.comment,
      paid: false,
      isCourierCall: _callStatus.value,
      paymentType: _payment.value == PaymentType.cash.toString()
          ? 'cash'
          : _payment.value == PaymentType.click.toString()
          ? 'click'
          : 'payme',
      source: Platform.isAndroid ? 'android' : 'ios',
      statusId: '',
      extraPhoneNumber: '',
      steps: [steps],
      futureTime: (_isFastDelivery ?? true)
          ? null
          : (deliveryType == DeliveryType.delivery)
          ? '${schedule[2]}-${schedule[1]}-${schedule[0]}'
          ' ${_futureTime.hour.toString().padLeft(2, '0')}:${_futureTime.minute.toString().padLeft(2, '0')}:00'
          : null,
    );
    String token = customer.accessToken ?? '';
    final result = await _repository.addOnDemandOrder(
      token: token,
      request: request,
    );
    setLoading(false);
    if (result is OndemandOrderResponse) {
      var customer = LocalSource.instance.getCustomer();
      await BaseFunctions.logEvent(
        eventName: AnalyticKeys.checkoutOrder,
        parameters: {
          'name': customer.name,
          'phone': customer.phone,
        },
      );
      showSuccessMessage('wait_for_operator'.tr);
      return result.paymentLink.toString();
    } else {
      if (result.toString() == 'null') {
        Get.snackbar(
          'error'.tr,
          'company_not_working_time'.tr,
          backgroundColor: AppColors.red,
          colorText: AppColors.white,
        );
      } else {
        showErrorMessage(result.toString());
      }
      return '0';
    }
  }

  String _getProductsIds() {
    final List<String> list = [];
    for (var element in _productsList) {
      list.add(element.id);
    }
    String concatenatedString = list.join(',');
    return concatenatedString;
  }

  Future<void> getProductsStatuses(
      {required String newMenuId, required int index}) async {
    // final String menuId = await _localSource.getMenuId();
    if (newMenuId.isEmpty) {
      return;
    }
    setLoading(true);
    final result = await _repository.getProductsStatuses(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      menuId: newMenuId,
      productsIds: _getProductsIds(),
    );
    if (result is ProductsStatusesResponse) {
      _isNoProductsInBranch = false;
      if (result.products == null) {
        _isNoProductsInBranch = true;
      }
      result.products?.forEach((element) {
        if (!(element.isActive ?? false)) {
          _listOfStopListIds.add(element.productId ?? '');
        }
      });
    }
    setLoading(false);
    update();
  }

  Future<void> getLocationYandex() async {
    if (await hasPermission()) {
      _locationData = await Geolocator.getCurrentPosition();
      _myPoint = Point(
        latitude: _locationData?.latitude ?? 0,
        longitude: _locationData?.longitude ?? 0,
      );
      await findMyLocation();
    }
  }

  Future<void> setMapObject(Point value) async {
    PlacemarkMapObject placeMark = PlacemarkMapObject(
      mapId: targetMapObjectId,
      point: value,
      zIndex: 20,
      opacity: 1,
      icon: PlacemarkIcon.single(
        PlacemarkIconStyle(
          image: BitmapDescriptor.fromAssetImage(
            'assets/png/location.png',
          ),
        ),
      ),
    );
    _mapObjects = [placeMark];
    await cameraPositionChanged(value);
    update();
  }

  Future<void> cameraPositionChanged(Point value) async {
    Point point = Point(
      longitude: value.longitude,
      latitude: value.latitude,
    );
    final response = await getData(
      '${AppConstants.yandexUrl}?apikey=${_localSource.getYandexKey()}&format=json&geocode=${point.latitude},${point.longitude}&sco=latlong&results=1&lang=${BaseFunctions.getMapLocale()}',
      value,
    );
    if (response != null) {
      AddressResponse address = AddressResponse.fromJson(response);
      if ((address.response?.geoObjectCollection?.featureMember ?? [])
          .isNotEmpty) {
        String text = address.response?.geoObjectCollection?.featureMember![0]
            .geoObject?.metaDataProperty?.geocoderMetaData?.text ??
            '';
        addressController.text = BaseFunctions.addressFormatter(text);
      }
    }
  }

  Future<void> setNewLocation(String text, Point value) async {
    _myPoint = value;
    addressController.text = BaseFunctions.addressFormatter(text);
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: value, zoom: 18),
      ),
      animation: _animation,
    );
    await setMapObject(value);
    update();
  }

  Future<void> getSelectedLocation() async {
    if (_deliveryType == DeliveryType.selfPickup && _selectedBranch != null) {
      await setNewLocation(
        '',
        Point(
          latitude: (_selectedBranch?.location?.lat ?? 0).toDouble(),
          longitude: (_selectedBranch?.location?.long ?? 0).toDouble(),
        ),
      );
      return;
    }
    if (_deliveryType == DeliveryType.delivery && _currentAddress != null) {
      await setNewLocation(
        _currentAddress?.name ?? '',
        Point(
          latitude: (_currentAddress?.location?.lat ?? 0).toDouble(),
          longitude: (_currentAddress?.location?.long ?? 0).toDouble(),
        ),
      );
      update();
      return;
    }
    if (await hasPermission()) {
      _locationData = await Geolocator.getCurrentPosition();
      await findMyLocation();
    }
  }

  double get getAllPrice {
    double price = 0;
    for (final basket.Products product in _productsList) {
      price += product.price * product.quantity;
      for (final basket.Modifiers modifier in product.modifiers ?? []) {
        price +=
            (modifier.addModifierPrice ?? false ? 0 : modifier.modifiersPrice) *
                (modifier.modifierQuantity * product.quantity);
      }
    }
    final double deliveryPrice = (_deliveryType == DeliveryType.delivery
        ? (_computePriceResponse?.price ?? 0).toDouble()
        : 0);
    return price + deliveryPrice;
  }

  bool get callStatus => _callStatus.value;

  TimeOfDay get time => _time;

  RxString get payment => _payment;

  DeliveryType get deliveryType => _deliveryType;

  DeliveryTime get deliveryTime => _deliveryTime;

  List<Branches> get branches => _branches;

  Position? get locationData => _locationData;

  Map<String, dynamic> get data => _data;

  DateTime get futureTime => _futureTime;

  List<CustomerAddresses> get customerAddresses => _customerAddresses;

  bool? get isFastDelivery => _isFastDelivery;

  CustomerAddresses? get currentAddress => _currentAddress;

  Branches? get selectedBranch => _selectedBranch;

  List<MapObject> get mapObjects => _mapObjects;

  bool get isMapLoading => _isMapLoading;

  List<basket.Products> get productsList => _productsList;

  List<String> get listOfStopListIds => _listOfStopListIds;

  ComputePriceResponse? get computePriceResponse => _computePriceResponse;

  num get generalSum => _generalSum;

  num get generalSumWithDiscount => _generalSumWithDiscount;

  RxBool get errorEntrance => _errorEntrance;

  RxBool get errorFloor => _errorFloor;

  RxBool get errorApartment => _errorApartment;

  String? get shipperFutureTime => _shipperFutureTime;

  RxBool get load => _load;

  YandexMapController get mapController => _mapController;

  Point get initialPoint => _myPoint;
}
