import 'package:flutter/cupertino.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/mixins/yandex_location.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/map/address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/map/yandex_helper.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

class AddressDetailController extends BaseController with YandexLocation {
  late TextEditingController mapAddressController;
  late TextEditingController apartmentController;
  late TextEditingController entranceController;
  late TextEditingController floorController;
  late TextEditingController myMapAddressController;
  List<FeatureMember> _address = [];
  FeatureMember? inputAddressGeos;
  RxBool isVisibleAddressList = false.obs;
  Point point = const Point(latitude: 41.33564, longitude: 69.28021);

  bool _addressNameError = false;
  bool _addressError = false;
  bool _apartmentError = false;
  bool _entranceError = false;
  bool _floorError = false;

  void setError({
    bool? addressName,
    bool? address,
    bool? apartment,
    bool? entrance,
    bool? floor,
  }) {
    _addressNameError = addressName ?? _addressNameError;
    _addressError = address ?? _addressError;
    _apartmentError = apartment ?? _apartmentError;
    _entranceError = entrance ?? _entranceError;
    _floorError = floor ?? _floorError;
    update();
  }

  @override
  void onInit() {
    super.onInit();
    mapAddressController = TextEditingController();
    apartmentController = TextEditingController();
    entranceController = TextEditingController();
    floorController = TextEditingController();
    myMapAddressController = TextEditingController();
  }

  Future<List<FeatureMember>> onSearchAddress(String search) async {
    final String lang = LocalSource.instance.locale;
    YandexHelper networkHelper = YandexHelper(
        '${AppConstants.yandexUrl}?format=json&apikey=${LocalSource.instance.getYandexKey()}&geocode=$search&ll=41.311081,69.240562&spn=2.5,2.5&results=10&lang=$lang');
    setLoading(true);
    final response = await networkHelper.getData();
    setLoading(false);
    if (response != null && response != '') {
      AddressResponse searchData = AddressResponse.fromJson(response);
      if ((searchData.response?.geoObjectCollection?.featureMember ?? [])
          .isNotEmpty) {
        _address =
            searchData.response?.geoObjectCollection?.featureMember ?? [];
        update();
      }
    }
    return address.toList();
  }

  bool checkFieldsRequirement() {
    if (myMapAddressController.text.isEmpty) {
      setError(addressName: true);
      return false;
    }
    if (mapAddressController.text.isEmpty) {
      setError(address: true);
      return false;
    }
    if (apartmentController.text.isEmpty) {
      setError(apartment: true);
      return false;
    }
    if (entranceController.text.isEmpty) {
      setError(entrance: true);
      return false;
    }
    if (floorController.text.isEmpty) {
      setError(floor: true);
      return false;
    }
    return true;
  }

  List<FeatureMember> get address => _address;

  bool get addressNameError => _addressNameError;

  bool get addressError => _addressError;

  bool get apartmentError => _apartmentError;

  bool get entranceError => _entranceError;

  bool get floorError => _floorError;

  @override
  void dispose() {
    // mapController.dispose();
    myMapAddressController.dispose();
    mapAddressController.dispose();
    apartmentController.dispose();
    entranceController.dispose();
    floorController.dispose();
    super.dispose();
  }
}
