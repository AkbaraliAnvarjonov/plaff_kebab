import 'dart:async';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/mixins/yandex_location.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/map/address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/home_repository.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';
import 'package:geolocator/geolocator.dart';

import '../../../core/mixins/permissions.dart';
import '../../../data/models/create_address_response.dart';

class MapController extends BaseController
    with PermissionsMixin, YandexLocation {
  late final HomeRepository _homeRepository;

  MapController(this._homeRepository);

  List<MapObject> _mapObjects = [];
  final MapObjectId targetMapObjectId = const MapObjectId('target_place_mark');
  final LocalSource _localSource = LocalSource.instance;
  late YandexMapController _mapController;
  final Point _point = const Point(latitude: 41.311081, longitude: 69.240562);
  late Point _myPoint = const Point(latitude: 41.311081, longitude: 69.240562);
  late Position? _locationData;
  final TextEditingController locationController = TextEditingController();
  final TextEditingController apartmentController = TextEditingController();
  final TextEditingController entranceController = TextEditingController();
  final TextEditingController floorController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final RxBool _errorEntrance = false.obs;
  final RxBool _errorFloor = false.obs;
  final RxBool _errorApartment = false.obs;
  final RxBool _errorName = false.obs;

  List<Orders> _orders = [];
  final bool _isMapLoading = false;

  final animation = const MapAnimation();

  void setController(YandexMapController controller) {
    _mapController = controller;
    update();
  }

  @override
  Future<void> onInit() async {
    super.onInit();
    await hasPermission();
  }

  @override
  Future<void> onReady() async {
    super.onReady();
    await getLocation();
  }

  @override
  void onClose() {
    nameController.clear();
    apartmentController.clear();
    floorController.clear();
    entranceController.clear();
    _mapController.dispose();
    super.onClose();
  }

  Future<void> cameraPositionChanged(Point value) async {
    _myPoint = value;
    final response = await getData(
      '${AppConstants.yandexUrl}?apikey=${LocalSource.instance.getYandexKey()}&format=json&geocode=${value.latitude},${value.longitude}&sco=latlong&results=1&lang=${BaseFunctions.getMapLocale()}',
      value,
    );
    if (response != null && response.isNotEmpty) {
      AddressResponse address = AddressResponse.fromJson(response);
      if ((address.response?.geoObjectCollection?.featureMember ?? [])
          .isNotEmpty) {
        String text = address.response?.geoObjectCollection?.featureMember![0]
            .geoObject?.metaDataProperty?.geocoderMetaData?.text ??
            '';
        locationController.text = BaseFunctions.addressFormatter(text);
        update();
      }
    } else {
      locationController.text = '';
      update();
    }
  }

  void setMapController(YandexMapController ctr) {
    _mapController = ctr;
    update();
  }

  void setEntrance(String value) {
    errorEntrance.value = false;
  }

  void setFloor(String value) {
    errorFloor.value = false;
  }

  void setApartment(String value) {
    errorApartment.value = false;
  }

  void setName(String value) {
    _errorName.value = false;
  }

  Future<void> findMyLocation() async {
    if (await hasPermission()) {
      final pos = await Geolocator.getCurrentPosition();

      _myPoint = Point(latitude: pos.latitude, longitude: pos.longitude);
    }
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: _myPoint, zoom: 20),
      ),
      animation: animation,
    );
    await setMapObject(_myPoint);
  }

  Future<void> getLocation() async {
    if (await hasPermission()) {
      _locationData = await Geolocator.getCurrentPosition();
      _myPoint = Point(
        latitude: _locationData?.latitude ?? 0,
        longitude: _locationData?.longitude ?? 0,
      );
      await findMyLocation();
    }
  }

  MyAddressRequest? checkFieldsRequirement() {
    if (locationController.text.isEmpty) {
      return null;
    }
    if (nameController.text.isEmpty) {
      _errorName.value = true;
      return null;
    } else {
      _errorName.value = false;
    }
    MyAddressRequest request = MyAddressRequest(
      name: nameController.text.trim(),
      address: locationController.text.trim(),
      apartment: apartmentController.text.trim(),
      building: entranceController.text.trim(),
      customerId: LocalSource.instance.getCustomer().id,
      description: '',
      floor: floorController.text.trim(),
      location: ToLocation(
        lat: _myPoint.latitude,
        long: _myPoint.longitude,
      ),
    );
    return request;
  }

  Future<bool> postMyAddress(MyAddressRequest request) async {
    setLoading(true);
    final result = await _homeRepository.postMyAddress(
      token: _localSource.getAccessToken(),
      shipperId: AppConstants.shipperId,
      request: request,
    );
    setLoading(false);
    if (result is CreateAddressResponse) {
      return true;
    } else {
      showErrorMessage(result.toString());
      return false;
    }
  }

  Future<void> setMapObject(Point value) async {
    PlacemarkMapObject placeMark = PlacemarkMapObject(
      mapId: targetMapObjectId,
      point: value,
      zIndex: 20,
      opacity: 1,
      icon: PlacemarkIcon.single(
        PlacemarkIconStyle(
          image: BitmapDescriptor.fromAssetImage(
            'assets/png/location.png',
          ),
        ),
      ),
    );
    _mapObjects = [placeMark];
    await cameraPositionChanged(value);
    update();
  }

  Future<void> move(Point value) async {
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: point, zoom: 20),
      ),
      animation: animation,
    );
  }

  void setOrders(List<Orders> list) {
    _orders = list;
    update();
  }

  List<Orders> get orders => _orders;

  YandexMapController get mapController => _mapController;

  Point get point => _point;

  bool get isMapLoading => _isMapLoading;

  List<MapObject> get mapObjects => _mapObjects;

  RxBool get errorEntrance => _errorEntrance;

  RxBool get errorFloor => _errorFloor;

  RxBool get errorApartment => _errorApartment;

  RxBool get errorName => _errorName;
}
