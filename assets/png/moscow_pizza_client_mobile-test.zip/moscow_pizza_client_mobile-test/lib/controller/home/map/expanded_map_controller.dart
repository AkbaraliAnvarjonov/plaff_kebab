import 'dart:async';
import 'package:dio/dio.dart';
import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/mixins/yandex_location.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/map/address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/saved_address_response.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';
import 'package:geolocator/geolocator.dart';

import '../../../core/mixins/permissions.dart';
import '../checkout_order/checkout_order_controller.dart';

class ExpandedMapController extends BaseController
    with PermissionsMixin, YandexLocation {
  late List<MapObject> _mapObjects = [];
  final MapObjectId targetMapObjectId = const MapObjectId('target_place_mark');
  late YandexMapController _mapController;
  Point _point = const Point(latitude: 41.311081, longitude: 69.240562);
  Point _myPoint = const Point(latitude: 41.311081, longitude: 69.240562);
  Position? _locationData;
  String text = '';

  Map<String, dynamic> _data = {};
  List<Orders> _orders = [];
  final bool _isMapLoading = false;

  final animation = const MapAnimation();

  void setDataValue(Map<String, dynamic> value) {
    _data = value;
    _myPoint = _data['point'];
    update();
    findMyLocation();
  }

  void setController(YandexMapController controller) {
    _mapController = controller;
    update();
  }

  @override
  void onInit() {
    super.onInit();
    getLocation();
  }

  // @override
  // void onClose() {
  //   locationSubscription.cancel();
  //   super.onClose();
  // }

  Future<void> cameraPositionChanged(Point value) async {
    Point point = Point(
      longitude: value.longitude,
      latitude: value.latitude,
    );
    _point = point;
    final response = await getData(
      '${AppConstants.yandexUrl}?apikey=${LocalSource.instance.getYandexKey()}&format=json&geocode=${point.latitude},${point.longitude}&sco=latlong&results=1&lang=${BaseFunctions.getMapLocale()}',
      point,
    );
    if (response != null) {
      AddressResponse address = AddressResponse.fromJson(response);
      if ((address.response?.geoObjectCollection?.featureMember ?? [])
          .isNotEmpty) {
        text = address.response?.geoObjectCollection?.featureMember![0]
            .geoObject?.metaDataProperty?.geocoderMetaData?.text ??
            '';
      }
    }
  }

  void setMapController(YandexMapController ctr) {
    _mapController = ctr;
    update();
  }

  Future<void> findMyLocation() async {
    await _mapController.moveCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: _myPoint, zoom: 20),
      ),
      animation: animation,
    );
    await setMapObject(_myPoint);
  }

  Future<void> getLocation() async {
    await hasPermission();
    _locationData = await Geolocator.getCurrentPosition();
    _myPoint = Point(
      latitude: _locationData?.latitude ?? 0,
      longitude: _locationData?.longitude ?? 0,
    );
    await findMyLocation();
  }

  Future<void> setMapObject(Point value) async {
    PlacemarkMapObject placeMark = PlacemarkMapObject(
      mapId: targetMapObjectId,
      point: value,
      zIndex: 20,
      opacity: 1,
      icon: PlacemarkIcon.single(
        PlacemarkIconStyle(
          image: BitmapDescriptor.fromAssetImage(
            'assets/png/location.png',
          ),
        ),
      ),
    );
    _mapObjects = [placeMark];
    await cameraPositionChanged(value);
    update();
  }

  void setOrders(List<Orders> list) {
    _orders = list;
    update();
  }

  void setNewLocation() {
    Get.find<CheckoutOrderController>().setNewLocation(text, point);
    Get.back();
  }

  List<Orders> get orders => _orders;

  YandexMapController get mapController => _mapController;

  Point get point => _point;

  Map get data => _data;

  bool get isMapLoading => _isMapLoading;

  List<MapObject> get mapObjects => _mapObjects;

  CustomerAddresses? _selectedCustomerAddress;

  CustomerAddresses? get selectedCustomerAddress => _selectedCustomerAddress;
}
