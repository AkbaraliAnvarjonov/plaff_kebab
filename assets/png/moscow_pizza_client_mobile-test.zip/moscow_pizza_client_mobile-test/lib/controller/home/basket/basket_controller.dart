import 'dart:io';

import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';

import '../../../base/base_controller.dart';
import '../../../core/constants/constants.dart';
import '../../../data/hive/products.dart';
import '../../../data/models/product_by_id_response.dart';
import '../../../data/models/product_favourite_response.dart';
import '../../../data/repository/basket_repository.dart';

class BasketController extends BaseController {
  TextEditingController commentController = TextEditingController();
  final ScrollController scrollController = ScrollController();
  final BasketRepository? _repository;
  double _modifierPrice = 0;
  List<Favourites>? _favourites;
  String productId = '';
  String secondaryProductId = '';
  final LocalSource _localSource = LocalSource.instance;
  final DeliveryType _deliveryType = DeliveryType.delivery;


  Future<void> productIds() async {
    var ls = await _repository?.getAllBasketProductsAsync() ?? [];
    for (var element in ls) {
      productId = '$productId,${element.id}';
    }
    if (productId.isNotEmpty) {
      productId = productId.substring(1);
    }
  }

  void changeSelected(Favourites? favourites, bool isSel) {
    favourites?.isSelected = isSel;
    update();
  }

  Future<void> updateFav(
      {bool isMinus = false, required Favourites? favourites}) async {
    var ls = await _repository?.getAllBasketProductsAsync() ?? [];
    for (var element in ls) {
      if (element.uniqueId == (favourites?.id ?? '')) {
        if (isMinus) {
          if (element.quantity > 1) {
            element.quantity = element.quantity - 1;
          } else {
            favourites?.quantity = 0;
            var product = Products(
              id: favourites?.id ?? '',
              image: favourites?.image ?? '',
              name: favourites?.title?.parseTitle(),
              price:
                  double.tryParse((favourites?.outPrice ?? 0.0).toString()) ??
                      0.0,
              quantity: 1,
              uniqueId: favourites?.id ?? '',
              modifiers: [],
            );
            await _repository?.removeProduct(product);
          }
        } else {
          element.quantity = element.quantity + 1;
        }
        var product = Products(
          id: favourites?.id ?? '',
          image: favourites?.image ?? '',
          name: favourites?.title?.parseTitle(),
          price:
              double.tryParse((favourites?.outPrice ?? 0.0).toString()) ?? 0.0,
          quantity: element.quantity,
          uniqueId: favourites?.id ?? '',
          modifiers: [],
        );
        await _repository?.updateProduct(product);
      }
    }
    update();
  }

  Future<void> changeTabIndexProductFavourites() async {
    secondaryProductId = '';
    var ls = await _repository?.getAllBasketProductsAsync() ?? [];
    for (var element in ls) {
      secondaryProductId = '$secondaryProductId,${element.id}';
    }
    if (secondaryProductId.isNotEmpty) {
      secondaryProductId = secondaryProductId.substring(1);
      if (productId != secondaryProductId) {
        await getProductFavourites(secondaryProductId);
      }
    }
  }

  BasketController(this._repository);

  Future<void> getProductFavourites(String productIds) async {
    setLoading(true);
    final result = await _repository?.getProductFavorites(
      shipperId: AppConstants.shipperId,
      productIds: productIds,
      // branchId: branchId,
      orderSource: Platform.isIOS ? 'ios' : 'android',
      isOnlyDelivery: (_deliveryType == DeliveryType.delivery).toString(),
      isOnlySelfPickUp: (_deliveryType == DeliveryType.selfPickup).toString(),
      clientId: _localSource.getCustomer().id ?? '',
      isWithDiscounts: true,
    );
    if (result is ProductFavouritesResponse) {
      _favourites = result.favourites;
      update();
    } else {
      setLoading(false);
      showErrorMessage(result.toString());
    }
    setLoading(false);
  }

  void updateModifierPrice(List<Modifiers>? modifier) {
    _modifierPrice = 0;
    for (var element in modifier ?? []) {
      _modifierPrice = _modifierPrice +
          ((element.modifierQuantity).toDouble() *
              (element.modifiersPrice).toDouble());
    }
  }

  Future<List<Products>>? getAllBasketProductsAsync() {
    return _repository?.getAllBasketProductsAsync();
  }

  Future<void> insertProduct(Products product) async {
    await _repository?.insertProduct(product);
  }

  Future<void> removeProduct(Products product,
      [bool isLastDeletedProduct = false]) async {
    if (isLastDeletedProduct) commentController = TextEditingController();
    await _repository?.removeProduct(product);
  }

  Future<void> updateQuantity({
    bool isMinus = false,
    bool isDelete = false,
    required Products product,
  }) async {
    if (isMinus) {
      if (product.quantity > 1) {
        product.quantity = product.quantity - 1;
        await _repository?.updateProduct(product);
      } else if (isDelete) {
        commentController = TextEditingController();
        await _repository?.removeProduct(product);
      }
    } else {
      product.quantity = product.quantity + 1;
      await _repository?.updateProduct(product);
    }
  }

  Future<void> removeAll() async {
    commentController = TextEditingController();
    await _repository?.removeAll();
  }

  double get modifierPrice => _modifierPrice;

  List<Favourites>? get favourites => _favourites;

  BasketRepository? get repository => _repository;
}
