import 'package:get/get.dart';

abstract class BaseRepository {
  Future<String> getErrorMessage(String message) async {
    String errorMessage = '';
    switch (message) {
      case 'Connection timeout':
        errorMessage = 'try_later'.tr;
        break;
      case 'Something wrong':
        errorMessage = 'something_wrong'.tr;
        break;
      default:
        try {
          errorMessage = message;
        } catch (e) {
          errorMessage = message;
        }
    }
    return errorMessage;
  }
}
