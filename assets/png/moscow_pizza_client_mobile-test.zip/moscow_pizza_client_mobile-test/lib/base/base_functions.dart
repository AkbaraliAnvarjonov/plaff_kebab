import 'dart:io';

import 'package:firebase_analytics/firebase_analytics.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/banners_response.dart'
    as t;
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/token/refresh_token_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/token/refresh_token_response.dart';
import 'package:moscow_pizza_client_mobile/data/repository/refresh/refresh_token_repository.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';

import '../core/constants/constants.dart';
import '../data/models/modifier_response.dart' as mv2;
import '../data/models/order_status.dart';
import '../data/models/product_by_id_response.dart' as pbi;

class BaseFunctions {
  BaseFunctions._();

  static final FirebaseAnalytics _firebaseAnalytics =
      FirebaseAnalytics.instance;

  static Future<void> logEvent({
    required String eventName,
    Map<String, dynamic>? parameters,
  }) async {
    await _firebaseAnalytics.logEvent(name: eventName, parameters: parameters);
  }

  static String stringLengthMax255(String value) {
    String replaceAllProduct = value.replaceAll(',,', ',');
    if (replaceAllProduct.length > 255) {
      replaceAllProduct = replaceAllProduct.substring(0, 254);
    }
    return replaceAllProduct;
  }

  static String getMapLocale() {
    final String defaultSystemLocale = Get.locale?.languageCode ?? '';
    switch (defaultSystemLocale.split('_').first) {
      case 'ru':
        return 'ru_RU';
      case 'en':
        return 'en_US';
      case 'uz':
        return 'uz_UZ';
      default:
        return 'ru_RU';
    }
  }

  static String moneyFormat(num number) {
    final isNegative = number.isNegative;
    String result = '0';
    result = NumberFormat().format(number.abs()).split(',').join(' ');
    return isNegative ? '-$result' : result;
  }

  static String moneyFormatSymbol(num number) {
    final isNegative = number.isNegative;
    String result = '0';
    result = NumberFormat().format(number.abs()).split(',').join(' ');
    return "${isNegative ? "-$result" : result} ${"sum".tr}";
  }

  static String phoneFormat(String phone) {
    if (phone.length >= 13) {
      String t = phone;
      t = t.replaceAll('+998', '');
      t = '${t.substring(0, 2)} ${t.substring(2, 5)} ${t.substring(5, 7)} ${t.substring(7, 9)}';
      return '+998 $t';
    } else {
      return phone;
    }
  }

  static String getStringByLanguage(t.Title? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getTranslateVariantName(VariantName? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getStringSingleModifierName(mv2.Name? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getModifierTitleTranslate(mv2.Description? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getModifierNameTranslate(ModifierName? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getStringByLanguageDesc(pbi.Description? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getTranslateLanguage(pbi.Title? value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static String getTransLanguage(dynamic value) {
    var lang = LocalSource.instance.locale;
    if (lang == 'ru') {
      return value?.ru ?? '';
    } else if (lang == 'en') {
      return value?.en ?? '';
    } else {
      return value?.uz ?? '';
    }
  }

  static Future<void> refreshToken() async {
    var request = RefreshTokenRequest(
      refreshToken: LocalSource.instance.getRefreshToken(),
    );
    final refreshTokenRepository = RefreshTokenRepository();
    final result = await refreshTokenRepository.refreshToken(request: request);
    if (result is RefreshTokenResponse) {
      await LocalSource.instance.setRefreshedTokens(
        refreshToken: result.refreshToken ?? '',
        accessToken: result.accessToken ?? '',
      );
      await LocalSource.instance.setRefresh(false);
    } else {
      await LocalSource.instance.removeProfile();
      await Get.offAllNamed(AppRoutes.main);
    }
  }

  static String getDefaultLocale() {
    final String defaultSystemLocale = Platform.localeName;
    switch (defaultSystemLocale.split('_').first) {
      case 'ru':
        return 'ru';
      case 'en':
        return 'en';
      case 'uz':
        return 'uz';
      default:
        return 'ru';
    }
  }

  static String dateFormatter(String str) {
    DateTime date = DateFormat('yyyy-MM-dd HH:mm:ss').parse(str);
    return DateFormat('dd.MM.yyyy').format(date);
  }

  static String timeFormatter(String str) {
    DateTime date = DateFormat('yyyy-MM-dd HH:mm:ss').parse(str);
    return DateFormat('HH:mm').format(date);
  }

  static String addressFormatter(String address) {
    String finished = address.replaceAll('ʻ', "'");
    return finished;
  }

  static bool isProfile = false;

  static void setIsProfile(bool value) {
    isProfile = value;
  }

  static OrderStatus getSelfPickUpStatus(String? statusId) {
    switch (statusId) {
      case AppConstants.newId:
        return OrderStatus.newStatus;

      case AppConstants.operatorAccepted:
        return OrderStatus.vendorAccepted;

      case AppConstants.vendorAccepted:
        return OrderStatus.vendorAccepted;

      case AppConstants.vendorReady:
        return OrderStatus.vendorReady;

      case AppConstants.finished:
        return OrderStatus.finished;
      case AppConstants.serverCancelled:
        return OrderStatus.serverCancelled;
      case AppConstants.operatorCancelled:
        return OrderStatus.operatorCancelled;
      case AppConstants.delivered:
        return OrderStatus.delivered;
      case AppConstants.futureTime:
        return OrderStatus.futureTime;
      default:
        {
          return OrderStatus.newStatus;
        }
    }
  }

  static OrderStatus getDeliveryStatus(String? statusId) {
    switch (statusId) {
      case AppConstants.newId:
        return OrderStatus.newStatus;

      case AppConstants.operatorAccepted:
        return OrderStatus.operatorAccepted;
      case AppConstants.courierAccepted:
        return OrderStatus.vendorAccepted;

      case AppConstants.vendorAccepted:
        return OrderStatus.vendorReady;
      case AppConstants.vendorReady:
        return OrderStatus.vendorReady;

      case AppConstants.courierPickedUp:
        return OrderStatus.courierPickUp;

      case AppConstants.finished:
        return OrderStatus.finished;

      case AppConstants.serverCancelled:
        return OrderStatus.serverCancelled;

      case AppConstants.operatorCancelled:
        return OrderStatus.operatorCancelled;

      case AppConstants.delivered:
        return OrderStatus.delivered;

      case AppConstants.futureTime:
        return OrderStatus.futureTime;

      default:
        {
          return OrderStatus.newStatus;
        }
    }
  }

  static String getDeliveryText(String statusId) {
    var status = getDeliveryStatus(statusId);
    switch (status) {
      case OrderStatus.newStatus:
        {
          return 'order_processed'.tr;
        }
      case OrderStatus.vendorReady:
        {
          return 'branch_accepted'.tr;
        }
      case OrderStatus.courierPickUp:
        {
          return 'courier_took'.tr;
        }
      case OrderStatus.finished:
        {
          return 'finished_order'.tr;
        }
      case OrderStatus.delivered:
        {
          return 'delivered'.tr;
        }
      case OrderStatus.serverCancelled:
        {
          return 'server_cancelled'.tr;
        }
      case OrderStatus.operatorCancelled:
        {
          return 'operator_cancelled'.tr;
        }
      case OrderStatus.futureTime:
        {
          return 'future_time'.tr;
        }
      default:
        {
          return 'order_processed'.tr;
        }
    }
  }

  static String getSelfPickUpText(String statusId) {
    var status = getSelfPickUpStatus(statusId);
    switch (status) {
      case OrderStatus.newStatus:
        {
          return 'order_processed'.tr;
        }
      case OrderStatus.vendorReady:
        {
          return 'branch_accepted'.tr;
        }
      case OrderStatus.finished:
        {
          return 'finished_order'.tr;
        }
      case OrderStatus.delivered:
        {
          return 'delivered'.tr;
        }
      case OrderStatus.serverCancelled:
        {
          return 'server_cancelled'.tr;
        }
      case OrderStatus.operatorCancelled:
        {
          return 'operator_cancelled'.tr;
        }
      case OrderStatus.futureTime:
        {
          return 'future_time'.tr;
        }
      default:
        {
          return 'order_processed'.tr;
        }
    }
  }

// static bool checkDatabaseUniqueKey(
//     String databaseKey, String currentProductKey) {
//   List<String> db = databaseKey.split("/");
//   List<String> current = currentProductKey.split("/");
//   String dbPId = db[0];
//   String cPId = current[0];
//   List<String> dbModId = db[1].split("_");
//   List<String> currentModId = current[1].split("_");
//   List<String> dbModQuantity = db[2].split("_");
//   List<String> currentModQuantity = current[2].split("_");
//
//   Map<String, String> dbModMap = {};
//   Map<String, String> currentMap = {};
//   for (int i = 0; i < dbModId.length; i++) {
//     dbModMap[dbModId[i]] = dbModQuantity[i];
//   }
//   for (int i = 0; i < currentModQuantity.length; i++) {
//     currentMap[currentModQuantity[i]] = currentModQuantity[i];
//   }
//
//   return false;
// }
}
