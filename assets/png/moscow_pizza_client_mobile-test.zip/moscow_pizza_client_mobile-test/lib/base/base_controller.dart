import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

export 'package:get/get.dart';

abstract class BaseController extends GetxController {
  RxBool isLoading = false.obs;

  void setLoading(bool value) {
    isLoading.value = value;
  }

  void showErrorMessage(String message, {Duration? duration}) {
    Get.snackbar(
      'error'.tr,
      duration: duration,
      message,
      backgroundColor: AppColors.red,
      borderRadius: 8,
      colorText: AppColors.white,
      maxWidth: Get.width,
      margin: AppUtils.kAllPadding16,
    );
  }

  void showSuccessMessage(String message) {
    Get.snackbar(
      'order_accepted'.tr,
      message,
      titleText: Text(
        'order_accepted'.tr,
        style: AppTextStyles.snackBarTitleText,
      ),
      messageText: Text(message, style: AppTextStyles.snackBarMessageText),
      backgroundColor: AppColors.green,
      borderRadius: 8,
      padding: AppUtils.kAllPadding16,
      colorText: AppColors.white,
      maxWidth: Get.width,
      margin: AppUtils.kAllPadding16,
      duration: const Duration(seconds: 1),
      animationDuration: const Duration(milliseconds: 300),
    );
  }
}
