import 'package:moscow_pizza_client_mobile/translations/en_translations.dart';
import 'package:moscow_pizza_client_mobile/translations/ru_translations.dart';
import 'package:moscow_pizza_client_mobile/translations/uz_translations.dart';

final class AppTranslation {
  static Map<String, Map<String, String>> translations = {
    'en': en,
    'ru': ru,
    'uz': uz,
  };
}
