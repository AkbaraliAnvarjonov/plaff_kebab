import 'package:moscow_pizza_client_mobile/data/hive/delivery_address_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/hive/pick_up_branch_hive_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:get/get.dart';
import 'package:keyboard_dismisser/keyboard_dismisser.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'bindings/main_binding.dart';
import 'core/constants/constants.dart';
import 'core/notification_service.dart';
import 'core/theme/app_theme.dart';
import 'data/data_sources/local/local_source.dart';
import 'data/hive/hive_databese.dart';
import 'data/hive/products.dart';
import 'translations/app_translations.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

// flutter pub run flutter_launcher_icons:main
// flutter run -d windows
// flutter build apk --release
// flutter build apk --split-per-abi
// flutter build appbundle --release
// flutter pub run build_runner watch --delete-conflicting-outputs

void main() async {
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);

  /// init storage
  await Hive.initFlutter();
  await LocalSource.getInstance();
  Hive
    ..registerAdapter(ProductAdapter())
    ..registerAdapter(ModifierAdapter())
    ..registerAdapter(ComboAdapter())
    ..registerAdapter(NameTitleAdapter())
    ..registerAdapter(DeliveryAddressAdapter())
    ..registerAdapter(PickUpBranchAdapter());
  await HiveDatabase.getInstance();

  /// init notification
  await NotificationService.initialize();

  /// init app
  runApp(
    MyApp(
      currentLocale: LocalSource.instance.locale,
    ),
  );
  FlutterNativeSplash.remove();
}

class MyApp extends StatelessWidget {
  final String currentLocale;

  const MyApp({
    Key? key,
    required this.currentLocale,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return KeyboardDismisser(
      child: GetMaterialApp(
        title: 'Московская пицца',
        debugShowCheckedModeBanner: false,
        initialBinding: MainBinding(),
        navigatorKey: AppConstants.navigatorKey,
        initialRoute: AppRoutes.initial,
        theme: AppThemes.light,
        darkTheme: AppThemes.dark,
        themeMode: ThemeMode.light,
        getPages: AppPages.pages,
        defaultTransition: Transition.cupertino,
        transitionDuration: const Duration(milliseconds: 300),
        locale: Locale(currentLocale),
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
          DefaultCupertinoLocalizations.delegate
        ],
        supportedLocales: const [
          Locale('ru', 'RU'),
          Locale('uz', 'UZ'),
          Locale('en', 'US'),
        ],
        translationsKeys: AppTranslation.translations,
      ),
    );
  }
}
