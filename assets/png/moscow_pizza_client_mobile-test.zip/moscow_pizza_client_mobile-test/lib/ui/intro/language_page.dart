import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/keys/analytic_keys.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/ui/intro/widget/lang_button.dart';

class LanguagePage extends StatelessWidget {
  const LanguagePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(toolbarHeight: 0),
      backgroundColor: AppColors.white,
      body: SafeArea(
        minimum: AppUtils.kAllPadding16,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AppUtils.kBoxHeight20,
            Align(
              child: Image.asset(
                'assets/png/moscowskaya_pizza.png',
                width: 128,
                height: 128,
              ),
            ),
            const Spacer(),
            const Text('Выберите язык:', style: AppTextStyles.blackBoldText15),
            AppUtils.kBoxHeight12,
            LangButton(
              onTap: () async {
                await LocalSource.instance.setLocale('uz');
                await Get.updateLocale(const Locale('uz'));
                await Get.offAllNamed(AppRoutes.main);
                await BaseFunctions.logEvent(
                  eventName: AnalyticKeys.languagePressed,
                  parameters: {'locale': 'uz'},
                );
              },
              assets: 'assets/png/ic_uzbek.png',
              text: "O'zbekcha",
            ),
            AppUtils.kBoxHeight16,
            LangButton(
              onTap: () async {
                await LocalSource.instance.setLocale('ru');
                await Get.updateLocale(const Locale('ru'));
                await Get.offAllNamed(AppRoutes.main);
                await BaseFunctions.logEvent(
                  eventName: AnalyticKeys.languagePressed,
                  parameters: {'locale': 'ru'},
                );
              },
              assets: 'assets/png/ic_russian.png',
              text: 'Русский',
            ),
            AppUtils.kBoxHeight16,
            LangButton(
              onTap: () async {
                await LocalSource.instance.setLocale('en');
                await Get.updateLocale(const Locale('en'));
                await Get.offAllNamed(AppRoutes.main);
                await BaseFunctions.logEvent(
                  eventName: AnalyticKeys.languagePressed,
                  parameters: {'locale': 'en'},
                );
              },
              assets: 'assets/png/ic_united_kingdom.png',
              text: 'English',
            ),
            const Spacer(flex: 2),
          ],
        ),
      ),
    );
  }
}
