import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class LangButton extends StatelessWidget {
  final String assets;
  final String text;
  final Function()? onTap;

  const LangButton({
    Key? key,
    required this.assets,
    required this.text,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomButton(
      height: 64,
      backgroundColor: AppColors.grey400,
      onTap: onTap,
      child: Padding(
        padding: AppUtils.kAllPadding16,
        child: Row(
          children: [
            Image(
              image: AssetImage(assets),
              height: 32,
              width: 32,
            ),
            AppUtils.kBoxWidth12,
            Text(text, style: AppTextStyles.blackBoldText15)
          ],
        ),
      ),
    );
  }
}
