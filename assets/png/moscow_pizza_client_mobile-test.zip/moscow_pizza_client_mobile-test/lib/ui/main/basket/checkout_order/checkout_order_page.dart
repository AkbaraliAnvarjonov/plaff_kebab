import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/basket/basket_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/current_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/routes/args/chekout_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/custom_radio_button.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/delivery_address_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/delivery_time_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/nearest_branches_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/select_delivery_type_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/sum_widget.dart';

import '../../my_orders/widgets/custom_tab_bar.dart';
import 'widgets/select_payment_type_widget.dart';

class CheckoutOrderPage extends GetView<CheckoutOrderController> {
  const CheckoutOrderPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    BasketController basketController = Get.find<BasketController>();
    CheckoutArguments? args =
        Get.arguments is CheckoutArguments ? Get.arguments : null;
    return GetBuilder<CheckoutOrderController>(
      initState: (_) {
        controller.setProducts(args?.products ?? []);
      },
      builder: (ctr) {
        DateTime selectedTime = DateTime.now().add(
          Duration(minutes: int.tryParse(ctr.shipperFutureTime ?? '0') ?? 0),
        );
        if (ctr.generalSum == 0) {
          ctr.setGeneralSum(args?.allPrice ?? 0);
        }
        return Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Text('checkout_order'.tr),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(56),
              child: CustomTabBar(
                controller: controller.tabController,
                labels: ['delivery'.tr, 'self_pick_up'.tr],
                onTap: (index) {
                  ctr
                    ..setDelivery(DeliveryType.values[index])
                    ..getOrderDiscount(5)
                    ..getProductDiscount();
                },
              ),
            ),
          ),
          body: Obx(
            () => ModalProgressHUD(
              inAsyncCall: ctr.isLoading.value,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: AppUtils.kPaddingTop16,
                child: Column(
                  children: [
                    ctr.deliveryType == DeliveryType.delivery
                        ? DeliveryAddressWidget(
                            currentAddress: ctr.currentAddress,
                            customerAddresses: ctr.customerAddresses,
                          )
                        : const NearestBranchesWidget(),
                    if (ctr.deliveryType == DeliveryType.delivery)
                      Container(
                        decoration: const BoxDecoration(
                          borderRadius: AppUtils.kBorderRadius12,
                          color: AppColors.white,
                        ),
                        margin: AppUtils.kTopMargin12,
                        padding: AppUtils.kAllPadding12,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'call_status_text'.tr,
                              style: styHistoryOrdersDetailItemProductName
                                  .copyWith(fontSize: 17),
                            ),
                            AppUtils.kBoxHeight16,
                            CustomRadioButton(
                              isChecked: ctr.callStatus,
                              title: 'yes'.tr,
                              onTap: () {
                                ctr.setCallStatus(true);
                              },
                            ),
                            AppUtils.kBoxHeight12,
                            AppUtils.kDivider1,
                            AppUtils.kBoxHeight12,
                            CustomRadioButton(
                              isChecked: !ctr.callStatus,
                              title: 'not'.tr,
                              onTap: () async {
                                ctr.setCallStatus(false);
                              },
                            ),
                          ],
                        ),
                      ),
                    if (ctr.deliveryType == DeliveryType.delivery)
                      SelectDeliveryTypeWidget(
                        onTap: ctr.setIsFastDelivery,
                        deliveryTime: ctr.deliveryTime,
                      ),
                    AppUtils.kBoxHeight12,
                    if (ctr.deliveryType == DeliveryType.delivery)
                      ctr.deliveryTime == DeliveryTime.scheduledDelivery
                          ? const DeliveryTimeWidget()
                          : AppUtils.kBox,
                    Obx(
                      () => SelectPaymentTypeWidget(
                        onTap: ctr.setPayment,
                        payment: ctr.payment.value,
                      ),
                    ),
                    AppUtils.kBoxHeight12,
                    SumWidget(
                      listOfStopListIds: ctr.listOfStopListIds,
                      deliveryPrice: ctr.deliveryType == DeliveryType.delivery ? ctr.computePriceResponse?.price ?? 0 : 0,
                      isCheckout: true,
                      isDelivery: ctr.deliveryType == DeliveryType.delivery,
                      generalSum: ctr.generalSumWithDiscount,
                      listOfBasketProducts: args?.products ?? [],
                      discountNames: ctr.discountNames,
                      sum: ctr.getAllPrice,
                      sumDiscount: ctr.generalSumWithDiscount + (ctr.deliveryType == DeliveryType.delivery ? ctr.computePriceResponse?.price ?? 0 : 0),
                    ),
                    AppUtils.kBoxHeight12,
                  ],
                ),
              ),
            ),
          ),
          bottomNavigationBar: Material(
            color: AppColors.white,
            child: SafeArea(
              minimum: AppUtils.kAllPadding16,
              child: Obx(
                () => CustomButton(
                  text: 'checkout_order'.tr,
                  onTap: ctr.isLoading.value
                      ? null
                      : () async {
                          if (ctr.isAnyProductInStopList()) {
                            return;
                          }
                          !ctr.callStatus
                              ? ctr.checkFieldsRequirement()
                              // ignore: unnecessary_statements
                              : () {};
                          if (ctr.deliveryTime ==
                                  DeliveryTime.scheduledDelivery &&
                              ctr.deliveryType == DeliveryType.delivery) {
                            DateTime selectTime = DateTime(
                                ctr.dateTime.year,
                                ctr.dateTime.month,
                                ctr.dateTime.day,
                                ctr.dateTime.hour + ctr.futureTime.hour,
                                ctr.dateTime.minute + ctr.futureTime.minute);
                            if (selectTime.isAfter(DateTime.now().add(Duration(
                                minutes: (int.tryParse(
                                            ctr.shipperFutureTime ?? '0') ??
                                        0) -
                                    1)))) {
                              if (!ctr.callStatus) {
                                if (!ctr.errorApartment.value &&
                                    !ctr.errorFloor.value &&
                                    !ctr.errorEntrance.value) {
                                  String result =
                                      await ctr.addOnDemandOrder(args);
                                  if (result.isNotEmpty && result != '0') {
                                    await basketController.removeAll();
                                    // ignore: use_build_context_synchronously
                                    Navigator.of(context).pop(true);
                                    await Get.find<CurrentOrdersController>()
                                        .getCurrentOrders();
                                  } else if (result.isEmpty) {
                                    await basketController.removeAll();
                                    // ignore: use_build_context_synchronously
                                    Navigator.of(context).pop(true);
                                    await Get.find<CurrentOrdersController>()
                                        .getCurrentOrders();
                                  }
                                } else {
                                  Get.snackbar(
                                    'please'.tr,
                                    'validation_address'.tr,
                                    colorText: AppColors.white,
                                    snackPosition: SnackPosition.TOP,
                                    backgroundColor: AppColors.red,
                                  );
                                }
                              } else {
                                String result =
                                    await ctr.addOnDemandOrder(args);
                                if (result.isNotEmpty && result != '0') {
                                  await basketController.removeAll();
                                  // ignore: use_build_context_synchronously
                                  Navigator.of(context).pop(true);
                                  await Get.find<CurrentOrdersController>()
                                      .getCurrentOrders();
                                } else if (result.isEmpty) {
                                  await basketController.removeAll();
                                  // ignore: use_build_context_synchronously
                                  Navigator.of(context).pop(true);
                                  await Get.find<CurrentOrdersController>()
                                      .getCurrentOrders();
                                }
                              }
                            } else {
                              Get.snackbar(
                                'please'.tr,
                                LocalSource.instance.locale == 'uz'
                                    ? '${selectedTime.day} ${ctr.months[selectedTime.month - 1]} ${selectedTime.hour}:${selectedTime.minute} ${'time_choose'.tr}'
                                    : '${'time_choose'.tr} ${selectedTime.day} ${ctr.months[selectedTime.month - 1]} ${selectedTime.hour}:${selectedTime.minute}',
                                colorText: AppColors.white,
                                snackPosition: SnackPosition.TOP,
                                backgroundColor: AppColors.red,
                              );
                            }
                          } else {
                            if (!ctr.callStatus) {
                              if (!ctr.errorApartment.value &&
                                  !ctr.errorFloor.value &&
                                  !ctr.errorEntrance.value) {
                                String result =
                                    await ctr.addOnDemandOrder(args);
                                if (result.isNotEmpty && result != '0') {
                                  await basketController.removeAll();
                                  // ignore: use_build_context_synchronously
                                  Navigator.of(context).pop(true);
                                  await Get.find<CurrentOrdersController>()
                                      .getCurrentOrders();
                                } else if (result.isEmpty) {
                                  await basketController.removeAll();
                                  // ignore: use_build_context_synchronously
                                  Navigator.of(context).pop(true);
                                  await Get.find<CurrentOrdersController>()
                                      .getCurrentOrders();
                                }
                              } else {
                                Get.snackbar(
                                  'please'.tr,
                                  'validation_address'.tr,
                                  colorText: AppColors.white,
                                  snackPosition: SnackPosition.TOP,
                                  backgroundColor: AppColors.red,
                                );
                              }
                            } else {
                              String result = await ctr.addOnDemandOrder(args);
                              if (result.isNotEmpty && result != '0') {
                                await basketController.removeAll();
                                // ignore: use_build_context_synchronously
                                Navigator.of(context).pop(true);
                                await Get.find<CurrentOrdersController>()
                                    .getCurrentOrders();
                              } else if (result.isEmpty) {
                                await basketController.removeAll();
                                // ignore: use_build_context_synchronously
                                Navigator.of(context).pop(true);
                                await Get.find<CurrentOrdersController>()
                                    .getCurrentOrders();
                              }
                            }
                          }
                        },
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
