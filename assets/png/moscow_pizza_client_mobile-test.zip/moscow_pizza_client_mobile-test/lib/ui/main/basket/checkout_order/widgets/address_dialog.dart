import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';

class AddressDialog extends StatelessWidget {
  const AddressDialog({
    Key? key,
    this.listAddress = const [],
    this.addAddressTap,
    this.selectedAddress,
  }) : super(key: key);

  final List<CustomerAddresses> listAddress;
  final Function()? addAddressTap;
  final Function(int index)? selectedAddress;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CheckoutOrderController>(
      builder: (logic) {
        return Dialog(
          backgroundColor: Colors.transparent,
          child: Container(
            constraints: BoxConstraints(maxHeight: Get.height / 2),
            padding: AppUtils.kAllPadding12,
            decoration: const BoxDecoration(
              borderRadius: AppUtils.kBorderRadius12,
              color: Colors.white,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  constraints: BoxConstraints(maxHeight: Get.height / 2 - 92),
                  child: ListView.separated(
                    shrinkWrap: true,
                    itemCount: logic.customerAddresses.length,
                    itemBuilder: (_, index) => Material(
                      color: Colors.white,
                      child: InkWell(
                        onTap: () {
                          selectedAddress!(index);
                        },
                        child: Padding(
                          padding: AppUtils.kVerticalPadding8,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Flexible(
                                flex: 3,
                                child: Text(
                                  logic.customerAddresses[index].name ?? '',
                                  style: styBasketItemTitle,
                                ),
                              ),
                              AppUtils.kBoxWidth16,
                              Flexible(
                                  flex: 5,
                                  child: Text(
                                    logic.customerAddresses[index].address ??
                                        '',
                                    style: styAuthInfo,
                                    maxLines: 2,
                                  )),
                            ],
                          ),
                        ),
                      ),
                    ),
                    separatorBuilder: (_, __) => AppUtils.kDivider1,
                  ),
                ),
                AppUtils.kBoxHeight16,
                Material(
                  child: InkWell(
                    onTap: addAddressTap,
                    borderRadius: AppUtils.kBorderRadius8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        vertical: 12,
                        horizontal: 40,
                      ),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: AppUtils.kBorderRadius8,
                        border: Border.all(color: Colors.black45),
                      ),
                      child: Text('add_address'.tr),
                    ),
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
