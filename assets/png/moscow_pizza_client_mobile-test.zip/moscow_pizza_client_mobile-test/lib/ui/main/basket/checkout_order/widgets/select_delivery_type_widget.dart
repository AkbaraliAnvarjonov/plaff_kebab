import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';

import 'check_order_item_widget.dart';
import 'package:get/get.dart';

class SelectDeliveryTypeWidget extends StatelessWidget {
  final Function(DeliveryTime value)? onTap;
  final DeliveryTime? deliveryTime;

  const SelectDeliveryTypeWidget({
    Key? key,
    this.onTap,
    this.deliveryTime,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var ctr = Get.find<CheckoutOrderController>();
    return Padding(
      padding: AppUtils.kTopMargin12,
      child: ClipRRect(
        borderRadius: AppUtils.kBorderRadius12,
        child: Material(
          color: AppColors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: AppUtils.kAllPadding12,
                child: Text(
                  'delivery_method'.tr,
                  style: styCheckSaleTitle,
                ),
              ),
              CheckOrderItemWidget(
                onTap: () {
                  onTap!(DeliveryTime.fastDelivery);
                  ctr..setFastDelivery(true)
                  ..getProductDiscount();
                },
                checked: deliveryTime == DeliveryTime.fastDelivery,
                text: 'fast_delivery1'.tr,
                assets: 'ic_self_call',
              ),
              const Padding(
                padding: EdgeInsets.only(left: 64),
                child: AppUtils.kDivider1,
              ),
              CheckOrderItemWidget(
                onTap: () {
                  onTap!(DeliveryTime.scheduledDelivery);
                  ctr..setFastDelivery(false)
                  ..getProductDiscount();
                },
                checked: deliveryTime == DeliveryTime.scheduledDelivery,
                text: 'future_delivery'.tr,
                assets: 'ic_car_delivery',
              ),
            ],
          ),
        ),
      ),
    );
  }
}
