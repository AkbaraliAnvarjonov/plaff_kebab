import 'package:flutter/material.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/widgets/basket_empty_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/widgets/basket_favourite_widget.dart';
import '../../../base/base_functions.dart';
import '../../../controller/home/basket/basket_controller.dart';
import '../../../controller/main/main_controller.dart';
import '../../../core/custom_widgets/buttons/custom_button.dart';
import '../../../core/custom_widgets/custom_circular_progress_indicator.dart';
import '../../../core/custom_widgets/text_fields/custom_text_field.dart';
import '../../../core/keys/app_keys.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_icons.dart';
import '../../../core/theme/app_text_style.dart';
import '../../../core/theme/app_utils.dart';
import '../../../data/data_sources/local/local_source.dart';
import '../../../data/hive/products.dart';
import '../../../routes/app_pages.dart';
import '../../../routes/args/chekout_arguments.dart';
import '../widgets/attention_dialog.dart';
import 'widgets/basket_item.dart';

class BasketPage extends GetView<BasketController> {
  const BasketPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String productIds = '';
    return ValueListenableBuilder<Box<Products>>(
      valueListenable: Hive.box<Products>(AppKeys.productsHiveKey).listenable(),
      builder: (_, snapshot, __) {
        var allPrice = 0.0;
        List<Products> ls = [];
        var modifierPrice = 0.0;
        if (snapshot.values.toList().isNotEmpty) {
          allPrice = 0.0;
          modifierPrice = 0.0;
          ls = snapshot.values.toList();
          for (var element in ls) {
            productIds = '';
            // ignore: use_string_buffers
            productIds = '$productIds,${element.id}';
            modifierPrice = 0;
            if (element.modifiers?.isNotEmpty ?? false) {
              for (Modifiers modifier in element.modifiers ?? []) {
                modifierPrice +=
                    ((modifier.addModifierPrice ?? true) ? 0 : modifier.modifiersPrice) *
                        modifier.modifierQuantity;
              }
            }
            allPrice += (element.price + modifierPrice + element.discounts) *
                element.quantity;
          }
          if (productIds.isNotEmpty) {
            productIds = productIds.substring(1);
          }
        }
        var localSource = LocalSource.instance;
        return GetBuilder<BasketController>(
          builder: (ctr) {
            return Scaffold(
              appBar: AppBar(
                centerTitle: true,
                title: Text('basket'.tr),
                actions: [
                  Visibility(
                    visible: ls.isNotEmpty,
                    child: IconButton(
                      tooltip: 'clear'.tr,
                      icon: const Icon(
                        AppIcons.recycle,
                        color: AppColors.black3,
                      ),
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (context) => AttentionDialog(
                            isAllDelete: true,
                            onDone: () async {
                              await localSource.removeAll();
                              Get.back();
                            },
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
              body: ls.isEmpty
                  ? const BasketEmptyWidget()
                  : CustomScrollView(
                      keyboardDismissBehavior:
                          ScrollViewKeyboardDismissBehavior.onDrag,
                      controller: controller.scrollController,
                      slivers: [
                        SliverToBoxAdapter(
                          child: Container(
                            margin: AppUtils.kVerticalPadding16,
                            decoration: const BoxDecoration(
                              borderRadius: AppUtils.kBorderRadius12,
                              color: AppColors.white,
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                ListView.separated(
                                  itemCount: ls.length,
                                  primary: true,
                                  shrinkWrap: true,
                                  padding: AppUtils.kHorizontalPadding12,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemBuilder: (_, index) {
                                    return BasketItem(
                                      product: ls[index],
                                      onDelete: () {
                                        showDialog(
                                          context: context,
                                          barrierDismissible: true,
                                          builder: (context) => AttentionDialog(
                                            onDone: () async {
                                              await ctr.removeProduct(
                                                  ls[index], ls.length == 1);
                                              Get.back();
                                            },
                                          ),
                                        );
                                      },
                                      onIncrement: (value) async {
                                        /// remove product by warm dialog
                                        if (value && ls[index].quantity == 1) {
                                          await showDialog(
                                            context: context,
                                            barrierDismissible: true,
                                            builder: (context) =>
                                                AttentionDialog(
                                              onDone: () async {
                                                await localSource.updateQuantity(
                                                  isMinus: value,
                                                  isDelete: true,
                                                  product: ls[index],
                                                );
                                                if (snapshot.values.toList()
                                                        .length ==
                                                    1) {
                                                  Get.back();
                                                } else {
                                                  Get.back();
                                                }
                                              },
                                            ),
                                          );
                                        } else {
                                          await localSource.updateQuantity(
                                            isMinus: value,
                                            product: ls[index],
                                          );
                                        }
                                      },
                                    );
                                  },
                                  separatorBuilder: (_, __) =>
                                      AppUtils.kDividerPadding16,
                                ),
                                // AppUtils.kDividerPadding16,
                                if (ls.isNotEmpty) AppUtils.kBoxHeight12,
                              ],
                            ),
                          ),
                        ),
                        SliverToBoxAdapter(
                          child: Material(
                            borderRadius: AppUtils.kBorderRadius12,
                            color: AppColors.white,
                            child: Padding(
                              padding: AppUtils.kAllPadding16,
                              child: CustomTextField(
                                controller: controller.commentController,
                                labelText: 'comment'.tr,
                                hintText: 'add_comment_to_order'.tr,
                              ),
                            ),
                          ),
                        ),
                        SliverToBoxAdapter(
                          child: Visibility(
                            visible: ctr.favourites?.isNotEmpty ?? false,
                            child: ctr.isLoading.value
                                ? const Center(
                                    child: CustomCircularProgressIndicator())
                                : const BasketFavouriteWidget(),
                          ),
                        ),
                      ],
                    ),
              bottomNavigationBar: Material(
                color: ls.isEmpty ? AppColors.transparent : AppColors.white,
                child: SafeArea(
                  minimum: AppUtils.kAllPadding16,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Visibility(
                        visible: ls.isNotEmpty,
                        child: Padding(
                          padding: const EdgeInsets.only(
                              right: 16, left: 16, bottom: 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'order_price'.tr,
                                style: styBasketOrderPrice,
                              ),
                              Expanded(
                                child: Text(
                                  BaseFunctions.moneyFormatSymbol(allPrice),
                                  style: styBasketOrderPrice,
                                  textAlign: TextAlign.end,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      CustomButton(
                        text:
                            ls.isEmpty ? 'add_product'.tr : 'checkout_order'.tr,
                        onTap: () async {
                          if (ls.isEmpty) {
                            await Get.find<MainController>().changeTabIndex(0);
                          } else if (localSource.hasProfile) {
                            final result = await Get.toNamed(
                              AppRoutes.checkoutOrder,
                              arguments: CheckoutArguments(
                                ls,
                                allPrice,
                                controller.commentController.text.trim(),
                              ),
                            );
                            if (result != null) {
                              controller.commentController.clear();
                              await Get.find<MainController>().changeTabIndex(2);
                            }
                          } else {
                            BaseFunctions.setIsProfile(false);
                            await Get.toNamed(AppRoutes.auth);
                          }
                        },
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
