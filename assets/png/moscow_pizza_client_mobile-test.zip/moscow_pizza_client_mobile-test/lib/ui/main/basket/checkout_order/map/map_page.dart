import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/map_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

import 'map_delivery_address_widget.dart';

class MapPage extends GetView<MapController> {
  const MapPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MapController>(
      builder: (ctr) {
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: const SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
          ),
          child: Scaffold(
            body: Obx(() {
              return ModalProgressHUD(
                inAsyncCall: ctr.isLoading.value,
                child: Stack(
                  children: [
                    Positioned.fill(
                      bottom: 300,
                      child: YandexMap(
                        mapObjects: ctr.mapObjects,
                        rotateGesturesEnabled: false,
                        tiltGesturesEnabled: false,
                        logoAlignment: const MapAlignment(
                          horizontal: HorizontalAlignment.center,
                          vertical: VerticalAlignment.top,
                        ),
                        onMapCreated: (yandexMapController) async {
                          ctr.setMapController(yandexMapController);
                          await yandexMapController.toggleUserLayer(visible: false);
                          // await ctr.mapController.moveCamera(
                          //   CameraUpdate.newCameraPosition(
                          //     CameraPosition(target: ctr.point, zoom: 15),
                          //   ),
                          //   animation: ctr.animation,
                          // );
                        },
                        onMapTap: (point) {
                          ctr.setMapObject(point);
                        },
                        onCameraPositionChanged: (cameraPosition, _, finished) {
                          if (finished) {
                            ctr.setMapObject(cameraPosition.target);
                          }
                        },
                      ),
                    ),
                    Positioned(
                      top: 34,
                      left: 12,
                      child: IconButton(
                        icon: const Icon(Icons.clear, size: 32),
                        onPressed: Get.back,
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: MapDeliveryAddressWidget(),
                    ),
                  ],
                ),
              );
            }),
          ),
        );
      },
    );
  }
}
