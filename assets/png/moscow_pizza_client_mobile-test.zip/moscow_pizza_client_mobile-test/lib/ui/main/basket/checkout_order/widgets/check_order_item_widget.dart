import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/radio_button_checked.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class CheckOrderItemWidget extends StatelessWidget {
  final bool checked;
  final Function()? onTap;
  final String text;
  final String assets;
  final double height;
  final Widget child;
  final Widget? rightChild;

  const CheckOrderItemWidget({
    Key? key,
    this.checked = false,
    this.onTap,
    required this.text,
    required this.assets,
    this.height = 56,
    this.child = const SizedBox(),
    this.rightChild,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          InkWell(
            onTap: onTap,
            child: Ink(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(
                      top: 14,
                      bottom: 14,
                      right: 12,
                      left: 12,
                    ),
                    child: Ink(
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        border: Border.all(color: AppColors.lightTestGrey),
                        borderRadius: AppUtils.kBorderRadius6,
                      ),
                      height: 28,
                      width: 40,
                      padding: AppUtils.kAllPadding4,
                      child: Image.asset('assets/png/$assets.png'),
                    ),
                  ),
                  Expanded(
                    child: Text(
                      text,
                      style: styCheckSaleItemText,
                    ),
                  ),
                  height != 64
                      ? Padding(
                          padding: AppUtils.kAllPadding16,
                          child: RadioButtonChecked(
                            isChecked: checked,
                            size: 20,
                          ),
                        )
                      : rightChild ?? AppUtils.kBox,
                ],
              ),
            ),
          ),
          child,
        ],
      ),
    );
  }
}
