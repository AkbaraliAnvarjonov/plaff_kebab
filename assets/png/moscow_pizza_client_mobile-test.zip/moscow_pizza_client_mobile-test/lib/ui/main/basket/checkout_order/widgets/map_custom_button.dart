import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class MapCustomButton extends StatelessWidget {
  final IconData icon;
  final Function()? onTap;
  final EdgeInsets? margin;

  const MapCustomButton({Key? key, required this.icon, this.onTap, this.margin})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        margin: margin,
        height: 35,
        width: 35,
        padding: AppUtils.kAllPadding8,
        decoration: BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 1,
                blurRadius: 10,
                offset: const Offset(0, 3), // changes position of shadow
              ),
            ]),
        child: IconButton(
          padding: EdgeInsets.zero,
          icon: Icon(icon),
          onPressed: onTap,
          iconSize: 20,
          splashRadius: 20,
        ),
      ),
    );
  }
}
