import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';

class BranchItemWidget extends StatelessWidget {
  final Function()? onTap;
  final Branches? branch;
  final Branches? selectedBranch;
  final Position? locationData;

  const BranchItemWidget({
    Key? key,
    this.onTap,
    this.branch,
    this.selectedBranch,
    this.locationData,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: AppUtils.kBorderRadius12,
      onTap: onTap,
      child: Ink(
        padding: AppUtils.kAllPadding12,
        child: Row(
          children: [
            const Padding(
              padding: AppUtils.kVertical12,
              child: Material(
                color: Colors.transparent,
                child: Image(
                  image: AssetImage('assets/png/ic_branch.png'),
                  height: 24,
                  width: 24,
                ),
              ),
            ),
            AppUtils.kBoxWidth12,
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 2),
                    child: Text(
                      branch?.name ?? 'Xadra',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: styCheckoutOrderBranchesItemName,
                    ),
                  ),
                  Text(
                    branch?.address ?? "30 Navoiy shoh ko'chasi,",
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: styCheckoutOrderBranchesItemAddress,
                  ),
                ],
              ),
            ),
            AppUtils.kBoxWidth12,
            (branch?.id == selectedBranch?.id)
                ? const Icon(
                    Icons.radio_button_checked_rounded,
                    size: 24,
                    color: AppColors.assets,
                  )
                : const Icon(
                    Icons.radio_button_unchecked,
                    size: 24,
                    color: AppColors.unChecked,
                  ),
          ],
        ),
      ),
    );
  }
}
