import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/checkout_order_branches_widget.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

import '../../../../../core/custom_widgets/custom_circular_progress_indicator.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_icons.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../routes/app_pages.dart';
import 'map_custom_button.dart';

class NearestBranchesWidget extends StatelessWidget {
  const NearestBranchesWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CheckoutOrderController>(
      builder: (ctr) {
        return Container(
          padding: AppUtils.kAllPadding16,
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'the_nearest_branches'.tr,
                style: AppTextStyles.blackBoldText17,
              ),
              AppUtils.kBoxHeight16,
              SizedBox(
                height: 156,
                child: ctr.isMapLoading
                    ? const CustomCircularProgressIndicator()
                    : ClipRRect(
                        borderRadius: AppUtils.kBorderRadius12,
                        child: Stack(
                          children: [
                            Positioned.fill(
                              child: YandexMap(
                                scrollGesturesEnabled: false,
                                mapObjects: ctr.mapObjects,
                                rotateGesturesEnabled: false,
                                tiltGesturesEnabled: false,
                                logoAlignment: const MapAlignment(
                                  horizontal: HorizontalAlignment.center,
                                  vertical: VerticalAlignment.top,
                                ),
                                onMapCreated: (yandexMapController) async {
                                  ctr.setMapController(yandexMapController);
                                  await ctr.getSelectedLocation();
                                  await yandexMapController.toggleUserLayer(
                                    visible: false,
                                  );
                                },
                                onMapTap: (point) {},
                                zoomGesturesEnabled: false,
                                onCameraPositionChanged:
                                    (cameraPosition, _, finished) {
                                  if (finished) {
                                    ctr..setMapObject(cameraPosition.target)
                                    ..getTheNearestBranches();
                                  }
                                },
                              ),
                            ),
                            Positioned(
                              top: 8,
                              left: 8,
                              child: MapCustomButton(
                                icon: AppIcons.expand_map,
                                onTap: () {
                                  Get.toNamed(AppRoutes.expandedMap);
                                },
                              ),
                            ),
                            Positioned(
                              bottom: 8,
                              right: 8,
                              child: MapCustomButton(
                                icon: AppIcons.map_pointer,
                                onTap: () {
                                  ctr.findMyLocation();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
              AppUtils.kBoxHeight16,
              CheckoutOrderBranchesWidget(
                selectedBranch: ctr.selectedBranch,
                shrinkWrap: true,
                scrollPhysics: const NeverScrollableScrollPhysics(),
                branches: ctr.branches,
                locationData: ctr.locationData,
                onTap: (index) => ctr.setSelectedBranch(index),
              ),
            ],
          ),
        );
      },
    );
  }
}
