import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../controller/home/basket/basket_controller.dart';
import '../../../../core/theme/app_text_style.dart';
import 'basket_favourite_body_widget.dart';

class BasketFavouriteWidget extends StatelessWidget {
  const BasketFavouriteWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BasketController>(
      builder: (ctr) {
        return Container(
          padding: AppUtils.kAllPadding16,
          margin: const EdgeInsets.only(top: 12, bottom: 12),
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: AppUtils.kBottomMargin16,
                child: Text(
                  'favourites'.tr,
                  style: styProfileCondensationPolicyText,
                ),
              ),
              SizedBox(
                height: 224,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  shrinkWrap: true,
                  itemBuilder: (_, index) {
                    return BasketFavouriteBodyWidget(
                      favorites: ctr.favourites?[index],
                    );
                  },
                  separatorBuilder: (_, index) => AppUtils.kBoxWidth8,
                  itemCount: ctr.favourites?.length ?? 0,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
