import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/map_custom_button.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/widgets/home_address_bottom_sheet.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

import '../../../../../core/custom_widgets/custom_circular_progress_indicator.dart';
import '../../../../../core/custom_widgets/text_fields/custom_map_text_field.dart';
import '../../../../../core/custom_widgets/text_fields/custom_text_field.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../routes/app_pages.dart';

class DeliveryAddressWidget extends StatelessWidget {
  final List<CustomerAddresses> customerAddresses;
  final Function(int)? onChanged;
  final CustomerAddresses? currentAddress;

  const DeliveryAddressWidget({
    Key? key,
    required this.customerAddresses,
    this.currentAddress,
    this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final FocusNode flatFocus = FocusNode();
    final FocusNode entranceFocus = FocusNode();
    final FocusNode floorFocus = FocusNode();
    return GetBuilder<CheckoutOrderController>(
      builder: (ctr) {
        return Container(
          padding: AppUtils.kAllPadding16,
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'delivery_address'.tr,
                style: AppTextStyles.blackBoldText17,
              ),
              AppUtils.kBoxHeight16,
              CustomTextField(
                autoFocus: false,
                labelPadding: 12,
                isResizable: true,
                labelStyle: styCheckSaleTitle,
                fillColor: AppColors.grey300,
                controller: ctr.addressController,
                keyboardType: TextInputType.text,
                inputAction: TextInputAction.done,
                readOnly: true,
                labelText: 'current_address'.tr,
                hintText: 'address'.tr,
              ),
              AppUtils.kBoxHeight8,
              ctr.callStatus
                  ? Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: CustomMapTextField(
                            hintText: 'entrance'.tr,
                            currentFocus: entranceFocus,
                            nextFocus: floorFocus,
                            errorText: 'entrance_error'.tr,
                            // showError: ctr.entranceError,
                            controller: ctr.entranceController,
                            onChanged: (value) {
                              /*  if(controller.entranceController.text.isNotEmpty)
                              controller.setError(entrance: false);*/
                            },
                            keyboardType: TextInputType.text,
                          ),
                        ),
                        AppUtils.kBoxWidth8,
                        Expanded(
                          child: CustomMapTextField(
                            hintText: 'floor'.tr,
                            currentFocus: floorFocus,
                            controller: ctr.floorController,
                            errorText: 'floor_error'.tr,
                            onChanged: (value) {},
                            keyboardType: TextInputType.number,
                          ),
                        ),
                        AppUtils.kBoxWidth8,
                        Expanded(
                          child: CustomMapTextField(
                            hintText: 'flat'.tr,
                            currentFocus: flatFocus,
                            nextFocus: entranceFocus,
                            errorText: 'apartment_error'.tr,
                            controller: ctr.apartmentController,
                            onChanged: (value) {},
                            keyboardType: TextInputType.text,
                          ),
                        ),
                      ],
                    )
                  : Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Obx(
                            () => CustomMapTextField(
                              hintText: 'entrance'.tr,
                              currentFocus: entranceFocus,
                              nextFocus: floorFocus,
                              errorText: 'entrance_error'.tr,
                              showError: ctr.errorEntrance.value,
                              controller: ctr.entranceController,
                              onChanged: (value) {},
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ),
                        AppUtils.kBoxWidth8,
                        Expanded(
                          child: Obx(
                            () => CustomMapTextField(
                              hintText: 'floor'.tr,
                              currentFocus: floorFocus,
                              controller: ctr.floorController,
                              errorText: 'floor_error'.tr,
                              showError: ctr.errorFloor.value,
                              onChanged: (value) {},
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ),
                        AppUtils.kBoxWidth8,
                        Expanded(
                          child: Obx(
                            () => CustomMapTextField(
                              hintText: 'flat'.tr,
                              currentFocus: flatFocus,
                              nextFocus: entranceFocus,
                              errorText: 'apartment_error'.tr,
                              showError: ctr.errorApartment.value,
                              controller: ctr.apartmentController,
                              onChanged: (value) {},
                              keyboardType: TextInputType.number,
                            ),
                          ),
                        ),
                      ],
                    ),
              AppUtils.kBoxHeight8,
              SizedBox(
                height: 156,
                child: ctr.isMapLoading
                    ? const CustomCircularProgressIndicator()
                    : ClipRRect(
                        borderRadius: AppUtils.kBorderRadius12,
                        child: Stack(
                          children: [
                            Positioned.fill(
                              child: YandexMap(
                                scrollGesturesEnabled: false,
                                mapObjects: ctr.mapObjects,
                                rotateGesturesEnabled: false,
                                tiltGesturesEnabled: false,
                                logoAlignment: const MapAlignment(
                                  horizontal: HorizontalAlignment.center,
                                  vertical: VerticalAlignment.top,
                                ),
                                onMapCreated: (yandexMapController) async {
                                  ctr.setMapController(yandexMapController);
                                  await ctr.getProductsStatuses(
                                    newMenuId: ctr.deliveryType ==
                                            DeliveryType.delivery
                                        ? (ctr.branches.firstOrNull?.menuId ??
                                            '')
                                        : (ctr.selectedBranch?.menuId ?? ''),
                                    index: 3,
                                  );
                                  await ctr.getSelectedLocation();
                                  await yandexMapController.toggleUserLayer(
                                    visible: false,
                                  );
                                },
                                onMapTap: (point) {
                                  // ctr.setMapObject(point);
                                },
                                zoomGesturesEnabled: false,
                                onCameraPositionChanged:
                                    (cameraPosition, __, finished) {
                                  if (!ctr.load.value) {
                                    ctr.load.value = true;
                                  }
                                  if (finished) {
                                    ctr.setMapObject(cameraPosition.target);
                                    ctr
                                        .getTheNearestBranches()
                                        .then((value) async {
                                      await ctr.getProductsStatuses(
                                        newMenuId:
                                            ctr.branches.firstOrNull?.menuId ??
                                                '',
                                        index: 4,
                                      );
                                    });
                                    ctr.load.value = false;
                                  }
                                },
                              ),
                            ),
                            Positioned(
                              top: 8,
                              left: 8,
                              child: MapCustomButton(
                                icon: AppIcons.expand_map,
                                onTap: () {
                                  Get.toNamed(AppRoutes.expandedMap);
                                },
                              ),
                            ),
                            Positioned(
                              bottom: 8,
                              right: 8,
                              child: MapCustomButton(
                                icon: AppIcons.map_pointer,
                                onTap: () {
                                  ctr.findMyLocation();
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
              ),
              AppUtils.kBoxHeight16,
              CustomTextField(
                readOnly: true,
                autoFocus: false,
                labelPadding: 12,
                isResizable: true,
                onTap: () async {
                  if (customerAddresses.isNotEmpty) {
                    await showModalBottomSheet(
                      isScrollControlled: true,
                      enableDrag: true,
                      isDismissible: true,
                      context: context,
                      builder: (context) => GetBuilder<CheckoutOrderController>(
                        builder: (ctr) {
                          return HomeAddressBottomSheet(
                            addresses: ctr.customerAddresses,
                            onTap: () async {
                              Get.back();
                              final result = await Get.toNamed(AppRoutes.map);

                              // if (result != null) {
                              //   await ctr.getMyAddress();
                              // }
                              if (result != null) {
                                await ctr.getMyAddress();
                                if (ctr.customerAddresses.isNotEmpty) {
                                  ctr.setAddressChecked(0);
                                }
                              }
                            },
                            onChanged: (index) {
                              ctr.setAddressChecked(index);
                              Get.back();
                            },
                          );
                        },
                      ),
                      backgroundColor: Colors.transparent,
                    );
                  } else {
                    final result = await Get.toNamed(AppRoutes.map);
                    if (result != null) {
                      await ctr.getMyAddress();
                      if (ctr.customerAddresses.isNotEmpty) {
                        ctr.setAddressChecked(0);
                      }
                    }
                  }
                },
                labelStyle: styCheckSaleTitle,
                fillColor: AppColors.grey300,
                controller: ctr.myAddressesController,
                keyboardType: TextInputType.text,
                inputAction: TextInputAction.done,
                labelText: 'my_addresses'.tr,
                hintText: 'choose_address'.tr,
                suffixIcon: const Icon(Icons.keyboard_arrow_down_outlined),
              ),
            ],
          ),
        );
      },
    );
  }
}
