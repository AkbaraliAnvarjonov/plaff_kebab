import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/radio_button_checked.dart';

import '../../../../../core/theme/app_utils.dart';

class CustomRadioButton extends StatelessWidget {
  const CustomRadioButton({
    Key? key,
    required this.isChecked,
    required this.title,
    required this.onTap,
  }) : super(key: key);

  final bool isChecked;
  final String title;
  final Function() onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: AppUtils.kVerticalPadding8,
        child: Row(
          children: [
            RadioButtonChecked(
              isChecked: isChecked,
              size: 20,
            ),
            AppUtils.kBoxWidth6,
            Expanded(child: Text(title))
          ],
        ),
      ),
    );
  }
}
