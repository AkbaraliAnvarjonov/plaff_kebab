import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/extension/number_parsing.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../core/custom_widgets/plus_minus_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import '../../../../../data/models/product_by_id_response.dart';
import '../../../../controller/home/basket/basket_controller.dart';
import '../../widgets/attention_dialog.dart';

class BasketFavouriteWithoutBouncingWidget extends StatelessWidget {
  const BasketFavouriteWithoutBouncingWidget({
    Key? key,
    required this.favorites,
  }) : super(key: key);

  final Favourites? favorites;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BasketController>(
      builder: (ctr) => Container(
        margin: AppUtils.kAllPadding8,
        height: 36,
        decoration: const BoxDecoration(
          color: AppColors.white,
          borderRadius: AppUtils.kBorderRadius8,
          boxShadow: [
            BoxShadow(
              blurRadius: 10,
              color: Color.fromRGBO(0, 0, 0, 0.05),
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            PlusMinusButton(
              isMinus: true,
              onTap: () {
                if (BaseFunctions.moneyFormat(favorites?.quantity ?? 1)
                        .toInt() ==
                    1) {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => AttentionDialog(
                      onDone: () async {
                        await ctr.repository?.removeProduct(Products(
                          id: favorites?.id ?? '',
                          image: favorites?.image ?? '',
                          name: favorites?.title?.parseTitle(),
                          price: double.tryParse(
                                  (favorites?.outPrice ?? 0.0).toString()) ??
                              0.0,
                          quantity: 1,
                          uniqueId: favorites?.id ?? '',
                          modifiers: [],
                        ));
                        Get.back();
                      },
                    ),
                  );
                } else {
                  ctr.updateFav(isMinus: true, favourites: favorites);
                }
              },
            ),
            Padding(
              padding: AppUtils.kHorizontalPadding8,
              child: Text(
                BaseFunctions.moneyFormat(favorites?.quantity ?? 1),
                style: styProductDetailQuantity,
              ),
            ),
            PlusMinusButton(
              onTap: () {
                ctr.updateFav(
                  favourites: favorites,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
