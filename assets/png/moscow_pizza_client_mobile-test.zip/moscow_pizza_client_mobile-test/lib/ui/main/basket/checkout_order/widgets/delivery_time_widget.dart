import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/checkout_order/checkout_order_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import '../../../../../core/custom_widgets/date_picker/time_picker.dart';
import '../../../../../core/custom_widgets/text_fields/custom_text_field.dart';
import '../../../../../core/theme/app_icons.dart';

class DeliveryTimeWidget extends StatelessWidget {
  const DeliveryTimeWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CheckoutOrderController>
      (
    //     initState: (init) {
    //   Get.find<CheckoutOrderController>().dateController.text =
    //       "${Get.find<CheckoutOrderController>().futureTime.day.toString().padLeft(2, '0')}.${Get.find<CheckoutOrderController>().futureTime.month.toString().padLeft(2, '0')}.${Get.find<CheckoutOrderController>().futureTime.year}";
    // },
        builder: (controller) {
          DateTime initialDateTime = DateTime.now().add(Duration(minutes: int.tryParse(controller.shipperFutureTime ?? '0') ?? 0));
      return Container(
        width: Get.width,
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: AppUtils.kBorderRadius12,
        ),
        padding: AppUtils.kAllPadding16,
        margin: AppUtils.kBottomMargin12,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'choose_time'.tr,
              style: AppTextStyles.blackBoldText17,
            ),
            Row(
              children: [
                SizedBox(
                  width: (Get.width - 48) / 2,
                  child: GetBuilder<CheckoutOrderController>(
                    builder: (ctr) {
                      return CustomTextField(
                        autoFocus: false,
                        readOnly: true,
                        onTap: () {
                          TimePicker.showDatePicker(
                            context,
                            title: 'choose_time'.tr,
                            onDateTimeChanged: (date) {
                              ctr.dateController.text =
                                  "${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}";
                              ctr.dateTime =
                                  DateTime(date.year, date.month, date.day);
                            },
                            isChooseTime: true,
                            initialDateTime: DateTime(initialDateTime.year, initialDateTime.month, initialDateTime.day),
                            dateTime: controller.dateTime,
                          );
                        },
                        suffixIcon: const Icon(AppIcons.date),
                        currentFocus: controller.dateOfBirthFocus,
                        controller: ctr.dateController,
                        hintTextStyle: AppTextStyles.blackText15,
                        hintText:
                            "${DateTime.now().day.toString().padLeft(2, '0')}.${DateTime.now().month.toString().padLeft(2, '0')}.${DateTime.now().year}",
                      );
                    },
                  ),
                ),
                AppUtils.kBoxWidth16,
                Expanded(
                  child: SizedBox(
                    width: (Get.width - 48) / 2,
                    child: InkWell(
                      onTap: () => controller.selectFutureTime(
                          context, controller.shipperFutureTime ?? '0'),
                      child: Container(
                        margin: const EdgeInsets.only(top: 22),
                        padding: const EdgeInsets.all(14),
                        decoration: const BoxDecoration(
                          color: AppColors.background,
                          borderRadius: AppUtils.kBorderRadius8,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Row(
                              children: [
                                const Icon(
                                  Icons.access_time,
                                  color: AppColors.black3,
                                  size: 20,
                                ),
                                AppUtils.kBoxWidth10,
                                Text(
                                  '${controller.futureTime.hour.toString().padLeft(2, '0')}'
                                  ':${controller.futureTime.minute.toString().padLeft(2, '0')}',
                                  style: AppTextStyles.blackText15,
                                ),
                              ],
                            ),
                            const Icon(
                              Icons.keyboard_arrow_down_outlined,
                              color: AppColors.black3,
                              size: 24,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    });
  }
}
