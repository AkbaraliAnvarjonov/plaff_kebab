import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/expanded_map_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/map/expanded_map/widgets/cofirm_location_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/map_custom_button.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

class ExpandedMapPage extends GetView<ExpandedMapController> {
  const ExpandedMapPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ExpandedMapController>(
      initState: (state) {
        controller.getLocation();
      },
      builder: (ctr) {
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: const SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
          ),
          child: Scaffold(
            body: Stack(
              children: [
                Positioned.fill(
                  bottom: 100,
                  child: YandexMap(
                    mapObjects: ctr.mapObjects,
                    rotateGesturesEnabled: false,
                    tiltGesturesEnabled: false,
                    logoAlignment: const MapAlignment(
                      horizontal: HorizontalAlignment.center,
                      vertical: VerticalAlignment.top,
                    ),
                    onMapCreated: (yandexMapController) async {
                      ctr.setMapController(yandexMapController);
                      await ctr.getLocation();
                      await yandexMapController.toggleUserLayer(visible: false);
                    },
                    onMapTap: (point) {
                      ctr.setMapObject(point);
                    },
                    onCameraPositionChanged: (cameraPosition, _, finished) {
                      if (finished) {
                        ctr.setMapObject(cameraPosition.target);
                      }
                    },
                  ),
                ),
                Positioned(
                  top: 56,
                  left: 16,
                  child: MapCustomButton(
                      onTap: () {
                        Get.back();
                      },
                      icon: Icons.arrow_back_ios_outlined),
                ),
                Positioned(
                  bottom: 370,
                  right: 16,
                  child: MapCustomButton(
                      onTap: () {
                        controller.findMyLocation();
                      },
                      icon: AppIcons.map_pointer),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: ConfirmLocationWidget(
                    onTap: () {
                      ctr.setNewLocation();
                    },
                  ),
                )
              ],
            ),
          ),
        );
      },
    );
  }
}
