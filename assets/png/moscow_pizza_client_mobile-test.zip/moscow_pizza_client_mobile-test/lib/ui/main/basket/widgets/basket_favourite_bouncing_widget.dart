import 'package:moscow_pizza_client_mobile/core/custom_widgets/bouncing_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import '../../../../../routes/app_pages.dart';
import '../../../../controller/home/basket/basket_controller.dart';
import '../../../../core/theme/app_text_style.dart';
import '../../../../data/models/product_by_id_response.dart';
import '../../../../routes/args/product_detail_page_arguments.dart';

class BasketFavouriteBouncingWidget extends StatelessWidget {
  const BasketFavouriteBouncingWidget({
    Key? key,
    required this.favorites,
  }) : super(key: key);

  final Favourites? favorites;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BasketController>(
      builder: (ctr) => BouncingWidget(
        duration: const Duration(milliseconds: 100),
        scaleFactor: 1.5,
        onPressed: () async {
          if (favorites?.hasModifier ?? true) {
            await Get.toNamed(
              AppRoutes.productDetail,
              arguments: ProductDetailPageArguments(
                product: ProductByIdResponse(
                  id: favorites?.id,
                  title: favorites?.title,
                  description: favorites?.description,
                  image: favorites?.image,
                ),
              ),
            );
          } else {
            await ctr.repository?.insertProduct(
              Products(
                id: favorites?.id ?? '',
                image: favorites?.image ?? '',
                name: favorites?.title?.parseTitle(),
                price:
                    double.tryParse((favorites?.outPrice ?? 0.0).toString()) ??
                        0.0,
                quantity: 1,
                uniqueId: favorites?.id ?? '',
                modifiers: [],
              ),
            );
            Future.delayed(
              const Duration(milliseconds: 120),
              () => ctr.changeSelected(
                favorites,
                true,
              ),
            );
          }
        },
        child: Container(
          margin: AppUtils.kAllPadding8,
          height: 36,
          decoration: const BoxDecoration(
            color: AppColors.white,
            borderRadius: AppUtils.kBorderRadius8,
            boxShadow: [
              BoxShadow(
                blurRadius: 10,
                color: Color.fromRGBO(0, 0, 0, 0.05),
              )
            ],
          ),
          child: Center(
            child: Text(
              "${favorites?.discounts == 0 ? favorites?.outPrice : (favorites?.discounts ?? -1).isNegative ? 0 : favorites?.discounts} ${"sum".tr}",
              style: styTabBarItemTitle,
            ),
          ),
        ),
      ),
    );
  }
}
