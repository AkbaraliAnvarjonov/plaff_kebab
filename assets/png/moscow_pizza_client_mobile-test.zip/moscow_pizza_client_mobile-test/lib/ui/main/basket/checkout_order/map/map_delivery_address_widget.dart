import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/map_controller.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_request.dart';

import '../../../../../base/base_controller.dart';
import '../../../../../controller/home/home_controller.dart';
import '../../../../../core/custom_widgets/buttons/custom_button.dart';
import '../../../../../core/custom_widgets/text_fields/always_disabled_focus_node.dart';
import '../../../../../core/custom_widgets/text_fields/custom_map_text_field.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_icons.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../widgets/map_custom_button.dart';

class MapDeliveryAddressWidget extends StatelessWidget {
  final String? title;
  final FocusNode _flatFocus = FocusNode();
  final FocusNode _entranceFocus = FocusNode();
  final FocusNode _floorFocus = FocusNode();
  final GlobalKey<FormState> formKey = GlobalKey();

  MapDeliveryAddressWidget({
    Key? key,
    this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MapController>(
      builder: (ctr) {
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              MapCustomButton(
                margin: const EdgeInsets.only(bottom: 16, right: 16),
                icon: AppIcons.map_pointer,
                onTap: () {
                  ctr.findMyLocation();
                },
              ),
              DecoratedBox(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.only(
                    topLeft: AppUtils.kRadius12,
                    topRight: AppUtils.kRadius12,
                  ),
                  color: AppColors.white,
                ),
                child: SafeArea(
                  top: false,
                  minimum: AppUtils.kAllPadding12,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Center(
                        child: Container(
                          height: 5,
                          width: 46,
                          decoration: const BoxDecoration(
                              color: AppColors.background,
                              borderRadius: AppUtils.kBorderRadius10),
                        ),
                      ),
                      AppUtils.kBoxHeight12,
                      Text(title ?? 'delivery_address'.tr, style: styMapTitle),
                      AppUtils.kBoxHeight16,
                      CustomMapTextField(
                        hintText: '',
                        currentFocus: AlwaysDisabledFocusNode(),
                        controller: ctr.locationController,
                        keyboardType: TextInputType.text,
                        onTap: () async {},
                      ),
                      AppUtils.kBoxHeight8,
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: CustomMapTextField(
                              controller: ctr.entranceController,
                              maxLength: 10,
                              hintText: 'entrance'.tr,
                              currentFocus: _entranceFocus,
                              nextFocus: _floorFocus,
                              errorText: 'entrance_error'.tr,
                              onChanged: (s) => ctr.setEntrance(s),
                              keyboardType: TextInputType.text,
                            ),
                          ),
                          AppUtils.kBoxWidth8,
                          Expanded(
                            child: CustomMapTextField(
                              controller: ctr.floorController,
                              maxLength: 10,
                              hintText: 'floor'.tr,
                              currentFocus: _floorFocus,
                              errorText: 'floor_error'.tr,
                              onChanged: (s) => ctr.setFloor(s),
                              keyboardType: TextInputType.number,
                            ),
                          ),
                          AppUtils.kBoxWidth8,
                          Expanded(
                            child: CustomMapTextField(
                              controller: ctr.apartmentController,
                              maxLength: 10,
                              hintText: 'flat'.tr,
                              currentFocus: _flatFocus,
                              nextFocus: _entranceFocus,
                              errorText: 'apartment_error'.tr,
                              onChanged: (s) => ctr.setApartment(s),
                              keyboardType: TextInputType.text,
                            ),
                          ),
                          AppUtils.kBoxWidth8,
                        ],
                      ),
                      AppUtils.kBoxHeight8,
                      Obx(
                        () => CustomMapTextField(
                          controller: ctr.nameController,
                          showError: ctr.errorName.value,
                          onChanged: (s) => ctr.setName(s),
                          errorText: 'error_destination'.tr,
                          hintText: 'address_name'.tr,
                          keyboardType: TextInputType.text,
                        ),
                      ),
                      AppUtils.kBoxHeight8,
                      SafeArea(
                        child: CustomButton(
                          text: 'confirm'.tr,
                          onTap: () async {
                            MyAddressRequest? res = ctr.checkFieldsRequirement();
                            if (res != null) {
                              await ctr.postMyAddress(res);
                              await Get.find<HomeController>().getMyAddress();
                              // Get.find<CheckoutOrderController>().getMyAddress();
                              Get.back(result: true);
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
