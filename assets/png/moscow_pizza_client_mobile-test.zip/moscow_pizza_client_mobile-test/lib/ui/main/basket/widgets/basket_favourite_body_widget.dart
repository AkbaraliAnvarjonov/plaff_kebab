import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import '../../../../../base/base_functions.dart';
import '../../../../../core/constants/constants.dart';
import '../../../../../core/keys/app_keys.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import '../../../../../data/models/product_by_id_response.dart';
import '../../../../../routes/app_pages.dart';
import '../../../../controller/home/basket/basket_controller.dart';
import '../../../../routes/args/product_detail_page_arguments.dart';
import 'basket_favourite_bouncing_widget.dart';
import 'basket_favourite_without_bouncing_widget.dart';

class BasketFavouriteBodyWidget extends StatelessWidget {
  const BasketFavouriteBodyWidget({
    Key? key,
    required this.favorites,
  }) : super(key: key);

  final Favourites? favorites;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<BasketController>(
      builder: (ctr) => Container(
        height: 224,
        width: 148,
        decoration: const BoxDecoration(borderRadius: AppUtils.kBorderRadius8),
        child: Material(
          color: AppColors.recommendBackground,
          borderRadius: AppUtils.kBorderRadius8,
          child: InkWell(
            borderRadius: AppUtils.kBorderRadius8,
            customBorder: const RoundedRectangleBorder(
              borderRadius: AppUtils.kBorderRadius8,
            ),
            onTap: () async {
              if (favorites?.hasModifier ?? true) {
                await Get.toNamed(
                  AppRoutes.productDetail,
                  arguments: ProductDetailPageArguments(
                    product: ProductByIdResponse(
                      id: favorites?.id,
                      title: favorites?.title,
                      description: favorites?.description,
                      image: favorites?.image,
                    ),
                  ),
                );
              } else {
                if (favorites?.quantity == 1) {
                  await ctr.repository?.insertProduct(
                    Products(
                      id: favorites?.id ?? '',
                      image: favorites?.image ?? '',
                      name: favorites?.title?.parseTitle(),
                      price: double.tryParse(
                              (favorites?.outPrice ?? 0.0).toString()) ??
                          0.0,
                      quantity: 1,
                      uniqueId: favorites?.id ?? '',
                      modifiers: [],
                    ),
                  );
                }
                Future.delayed(
                  const Duration(milliseconds: 150),
                  () => ctr.changeSelected(
                    favorites,
                    true,
                  ),
                );
              }
            },
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: AppUtils.kBorderRadius8,
                  child: FadeInImage.assetNetwork(
                    imageCacheHeight: 114,
                    imageCacheWidth: 148,
                    height: 114,
                    image: '${AppConstants.imageUrl}${favorites?.image ?? ''}',
                    fit: BoxFit.fill,
                    placeholder: 'assets/png/product_place_holder.png',
                    placeholderErrorBuilder: (_, __, ___) {
                      return const Center(
                        child: Image(
                          image: AssetImage(
                            'assets/png/product_place_holder.png',
                          ),
                        ),
                      );
                    },
                    imageErrorBuilder: (_, __, ___) {
                      return const Center(
                        child: Image(
                          image: AssetImage(
                            'assets/png/product_place_holder.png',
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        margin: AppUtils.kAllPadding8,
                        child: Text(
                          BaseFunctions.getTranslateLanguage(favorites?.title),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          style: styProfileAboutServiceText.copyWith(
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                      ValueListenableBuilder<Box<Products>>(
                        valueListenable:
                            Hive.box<Products>(AppKeys.productsHiveKey)
                                .listenable(),
                        builder: (_, snapshot, __) {
                          bool isBasket = false;
                          for (int i = 0; i < snapshot.length; i++) {
                            if (snapshot.getAt(i)?.uniqueId == favorites?.id) {
                              isBasket = true;
                              favorites?.quantity =
                                  snapshot.getAt(i)?.quantity ?? 1;
                            }
                          }
                          return isBasket
                              ? BasketFavouriteWithoutBouncingWidget(
                                  favorites: favorites,
                                )
                              : BasketFavouriteBouncingWidget(
                                  favorites: favorites,
                                );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
