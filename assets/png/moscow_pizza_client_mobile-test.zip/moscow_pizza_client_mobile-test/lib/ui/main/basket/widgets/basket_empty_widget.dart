import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class BasketEmptyWidget extends StatelessWidget {
  const BasketEmptyWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisAlignment: MainAxisAlignment.center,
      children:  [
        const Image(
          image: AssetImage(
            'assets/png/ic_take_away.png',
          ),
          width: 120,
          height: 120,
        ),
        AppUtils.kBoxHeight32,
        Text(
          'no_products_in_basket'.tr,
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}
