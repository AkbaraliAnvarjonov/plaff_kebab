import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';

import 'check_order_item_widget.dart';

class SelectPaymentTypeWidget extends StatelessWidget {
  final Function(String value)? onTap;
  final String? payment;

  const SelectPaymentTypeWidget({
    Key? key,
    this.onTap,
    this.payment,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: AppUtils.kBorderRadius12,
      child: ColoredBox(
        color: AppColors.white,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Padding(
              padding: AppUtils.kAllPadding12,
              child: Text(
                'payment_type'.tr,
                style: styCheckSaleTitle,
              ),
            ),
            CheckOrderItemWidget(
              onTap: () => onTap!(PaymentType.cash.toString()),
              checked: payment == PaymentType.cash.toString(),
              text: 'cash'.tr,
              assets: 'ic_money',
            ),
            const Padding(
              padding: EdgeInsets.only(left: 64),
              child: AppUtils.kDivider1,
            ),
            CheckOrderItemWidget(
              onTap: () => onTap!(PaymentType.payMe.toString()),
              checked: payment == PaymentType.payMe.toString(),
              text: 'Payme',
              assets: 'ic_payme',
            ),
            const Padding(
              padding: EdgeInsets.only(left: 64),
              child: AppUtils.kDivider1,
            ),
            CheckOrderItemWidget(
              onTap: () => onTap!(PaymentType.click.toString()),
              checked: payment == PaymentType.click.toString(),
              text: 'Click',
              assets: 'ic_click',
            ),
          ],
        ),
      ),
    );
  }
}
