import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/address_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/text_fields/custom_map_text_field.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

class AddressDetailPage extends GetView<AddressDetailController> {
  final FocusNode _addressFocus = FocusNode();
  final FocusNode _flatFocus = FocusNode();
  final FocusNode _myAddressFocus = FocusNode();
  final FocusNode _entranceFocus = FocusNode();
  final FocusNode _floorFocus = FocusNode();

  AddressDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Map<String, dynamic> mapData =
        Get.arguments is Map<String, dynamic> ? Get.arguments : null;
    String address = mapData['address'] is String ? mapData['address'] : '';
    String? title = mapData['title'] is String ? mapData['title'] : null;
    controller.mapAddressController.text = address;

    return GetBuilder<AddressDetailController>(
      initState: (state) {},
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(
            title: Text(title ?? 'delivery_address'.tr),
          ),
          body: Obx(
            () => ListView(
              physics: const BouncingScrollPhysics(),
              padding: AppUtils.kAllPadding12,
              children: [
                title != null ? AppUtils.kBoxHeight12 : AppUtils.kBox,
                Visibility(
                  visible: title != null,
                  child: CustomMapTextField(
                    hintText: 'enter_address'.tr,
                    currentFocus: _myAddressFocus,
                    nextFocus: _addressFocus,
                    errorText: 'address_name_error'.tr,
                    showError: controller.addressNameError,
                    controller: controller.myMapAddressController,
                    backgroundColor: AppColors.white,
                    keyboardType: TextInputType.text,
                    onChanged: (s) {
                      if (controller.myMapAddressController.text.isNotEmpty) {
                        controller.setError(addressName: false);
                      }
                    },
                  ),
                ),
                AppUtils.kBoxHeight12,
                CustomMapTextField(
                  hintText: 'address_name'.tr,
                  currentFocus: _addressFocus,
                  nextFocus: _flatFocus,
                  errorText: 'address_error'.tr,
                  showError: controller.addressError,
                  controller: controller.mapAddressController,
                  backgroundColor: AppColors.white,
                  keyboardType: TextInputType.text,
                  onChanged: (s) {
                    if (controller.mapAddressController.text.trim().isEmpty) {
                      controller.isVisibleAddressList.value = false;
                    } else {
                      controller.onSearchAddress(s);
                      controller.isVisibleAddressList.value = true;
                      controller.setError(address: false);
                    }
                  },
                ),
                AppUtils.kBoxHeight12,
                Visibility(
                  visible: controller.isVisibleAddressList.value,
                  child: ListView.separated(
                    shrinkWrap: true,
                    physics: const ClampingScrollPhysics(),
                    itemCount: controller.address.length > 10
                        ? 10
                        : controller.address.length,
                    separatorBuilder: (con, index) =>
                        const Divider(height: 0.5),
                    itemBuilder: (context, index) {
                      return Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            controller.isVisibleAddressList.value = false;
                            controller.inputAddressGeos =
                                controller.address[index];
                            controller.mapAddressController.text = controller
                                    .address[index]
                                    .geoObject
                                    ?.metaDataProperty
                                    ?.geocoderMetaData
                                    ?.text ??
                                '';
                            controller.point = Point(
                              latitude: double.tryParse(
                                    (controller.address[index].geoObject?.point
                                                ?.pos ??
                                            '')
                                        .substring(9, 19),
                                  ) ??
                                  0,
                              longitude: double.tryParse(
                                    controller.address[index].geoObject?.point
                                            ?.pos ??
                                        ''.substring(0, 9),
                                  ) ??
                                  0,
                            );
                          },
                          child: Ink(
                            padding: const EdgeInsets.symmetric(
                              vertical: 12,
                              horizontal: 4,
                            ),
                            child: Text(
                              controller.address[index].geoObject?.name ?? '',
                              style: const TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w400,
                                color: AppColors.darkGrey,
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                AppUtils.kBoxHeight12,
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: CustomMapTextField(
                        hintText: 'flat'.tr,
                        currentFocus: _flatFocus,
                        nextFocus: _entranceFocus,
                        errorText: 'apartment_error'.tr,
                        showError: controller.apartmentError,
                        controller: controller.apartmentController,
                        backgroundColor: AppColors.white,
                        onChanged: (value) {
                          if (controller.apartmentController.text.isNotEmpty) {
                            controller.setError(apartment: false);
                          }
                        },
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    AppUtils.kBoxHeight12,
                    Expanded(
                      child: CustomMapTextField(
                        hintText: 'entrance'.tr,
                        currentFocus: _entranceFocus,
                        nextFocus: _floorFocus,
                        errorText: 'entrance_error'.tr,
                        showError: controller.entranceError,
                        controller: controller.entranceController,
                        backgroundColor: AppColors.white,
                        onChanged: (value) {
                          if (controller.entranceController.text.isNotEmpty) {
                            controller.setError(entrance: false);
                          }
                        },
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    AppUtils.kBoxHeight12,
                    Expanded(
                      child: CustomMapTextField(
                        hintText: 'floor'.tr,
                        currentFocus: _floorFocus,
                        errorText: 'floor_error'.tr,
                        showError: controller.floorError,
                        onChanged: (value) {
                          if (controller.floorController.text.isNotEmpty) {
                            controller.setError(floor: false);
                          }
                        },
                        controller: controller.floorController,
                        backgroundColor: AppColors.white,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                )
              ],
            ),
          ),
          bottomNavigationBar: SafeArea(
            minimum: AppUtils.kAllPadding16,
            child: CustomButton(
              height: 48,
              onTap: () {
                if (controller.checkFieldsRequirement()) {
                  Get.back(result: {
                    'my_address': controller.myMapAddressController.text.trim(),
                    'to_address': controller.mapAddressController.text.trim(),
                    'building': controller.entranceController.text.trim(),
                    'apartment': controller.apartmentController.text.trim(),
                    'floor': controller.floorController.text.trim(),
                    'point': controller.point,
                    'long': controller.point.longitude,
                    'lat': controller.point.latitude
                  });
                }
              },
              child: Text(
                title != null ? 'save'.tr : 'add_address'.tr,
                style: styEditProfileButtonText,
              ),
            ),
          ),
        );
      },
    );
  }
}
