import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../../../core/custom_widgets/buttons/custom_button.dart';
import '../../../../../../../core/theme/app_colors.dart';
import '../../../../../../../core/theme/app_utils.dart';

class ConfirmLocationWidget extends StatelessWidget {
  final Function() onTap;
  const ConfirmLocationWidget({Key? key, required this.onTap}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topLeft: AppUtils.kRadius12,
          topRight: AppUtils.kRadius12,
        ),
        color: AppColors.white,
      ),
      child: SafeArea(
        top: false,
        minimum: AppUtils.kAllPadding12,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Center(
              child: Container(
                height: 5,
                width: 46,
                decoration: const BoxDecoration(
                  color: AppColors.background,
                  borderRadius: AppUtils.kBorderRadius10,
                ),
              ),
            ),
            AppUtils.kBoxHeight20,
            CustomButton(
              text: 'confirm'.tr,
              onTap: onTap,
            ),
          ],
        ),
      ),
    );
  }
}
