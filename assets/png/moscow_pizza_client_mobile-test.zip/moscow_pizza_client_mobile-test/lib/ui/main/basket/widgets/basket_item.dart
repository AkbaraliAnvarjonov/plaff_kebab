import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/basket/basket_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/plus_minus_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import '../../../../data/hive/products.dart';

class BasketItem extends GetView<BasketController> {
  final Products product;
  final Function(bool isMinus) onIncrement;
  final Function() onDelete;

  const BasketItem({
    Key? key,
    required this.product,
    required this.onIncrement,
    required this.onDelete,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white,
      child: Ink(
        padding: AppUtils.kAllPadding16,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: AppUtils.kBorderRadius12,
              child: Container(
                height: 84,
                width: 84,
                decoration: const BoxDecoration(
                  borderRadius: AppUtils.kBorderRadius12,
                  color: AppColors.white,
                ),
                child: CachedNetworkImage(
                  // imageCacheHeight: 400,
                  // imageCacheWidth: 400,
                  fit: BoxFit.cover,
                  imageUrl: '${AppConstants.imageUrl}${product.image}',
                  placeholder: (_, __) {
                    return const Center(
                      child: Image(
                        image: AssetImage(
                          'assets/png/product_place_holder.png',
                        ),
                      ),
                    );
                  },
                  errorWidget: (_, __, ___) {
                    return const Center(
                      child: Image(
                        image: AssetImage(
                          'assets/png/product_place_holder.png',
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            AppUtils.kBoxWidth16,
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(
                          BaseFunctions.getTransLanguage(product.name),
                          style: styBasketItemTitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      AppUtils.kBoxWidth8,
                      InkWell(
                        onTap: onDelete,
                        child: Ink(
                          child: const Icon(
                            Icons.close,
                            size: 20,
                            color: Color(0xFF9AA6AC),
                          ),
                        ),
                      )
                    ],
                  ),
                  ((product.combos ?? []).isEmpty &&
                          (product.modifiers ?? []).isEmpty)
                      ? AppUtils.kBoxHeight24
                      : AppUtils.kBox,
                  ...List.generate(
                    (product.combos ?? []).length,
                    (index) => Padding(
                      padding: AppUtils.kVerticalPadding2,
                      child: Text(
                        BaseFunctions.getTransLanguage(
                            product.combos?[index].variantName ?? ''),
                        style:
                            stySubMyAddress.copyWith(color: AppColors.black3),
                      ),
                    ),
                  ),
                  ...List.generate(
                    (product.modifiers ?? []).length,
                    (index) => Padding(
                      padding: AppUtils.kVerticalPadding2,
                      child: Text(
                        '${BaseFunctions.getTransLanguage(product.modifiers?[index].modifierName ?? '')} (x${product.modifiers?[index].modifierQuantity ?? 0})',
                        style:
                            stySubMyAddress.copyWith(color: AppColors.black3),
                      ),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          BaseFunctions.moneyFormatSymbol(
                              // product.price.toDouble() +
                              //     controller.modifierPrice
                              product.getAllPrice()),
                          style: stySearchItemPrice,
                          textAlign: TextAlign.start,
                        ),
                      ),
                      DecoratedBox(
                        decoration: BoxDecoration(
                          color: AppColors.white,
                          borderRadius: AppUtils.kBorderRadius8,
                          border: Border.all(
                            color: AppColors.inactive,
                          ),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            PlusMinusButton(
                              isMinus: true,
                              size: 32,
                              onTap: () => onIncrement(true),
                            ),
                            Padding(
                              padding: AppUtils.kHorizontalPadding10,
                              child: Text(
                                BaseFunctions.moneyFormat(product.quantity),
                                style: styProductDetailQuantity,
                              ),
                            ),
                            PlusMinusButton(
                              onTap: () => onIncrement(false),
                              size: 32,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
