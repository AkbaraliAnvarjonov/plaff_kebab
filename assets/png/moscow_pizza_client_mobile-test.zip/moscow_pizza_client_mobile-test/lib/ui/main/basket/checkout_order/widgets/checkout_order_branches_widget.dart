import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';

import 'branch_item_widget.dart';

class CheckoutOrderBranchesWidget extends StatelessWidget {
  final List<Branches> branches;
  final Branches? selectedBranch;
  final Function(int index) onTap;
  final Position? locationData;
  final bool? shrinkWrap;
  final ScrollPhysics? scrollPhysics;

  const CheckoutOrderBranchesWidget({
    Key? key,
    this.branches = const [],
    required this.onTap,
    this.locationData,
    this.shrinkWrap,
    this.scrollPhysics,
    this.selectedBranch,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (branches.isEmpty) return AppUtils.kBox;
    return ListView.separated(
      shrinkWrap: shrinkWrap ?? false,
      itemCount: branches.length,
      physics: scrollPhysics,
      itemBuilder: (_, index) {
        return BranchItemWidget(
          selectedBranch: selectedBranch,
          branch: branches[index],
          onTap: () => onTap(index),
          locationData: locationData,
        );
      },
      separatorBuilder: (_, __) => const Padding(
        padding: EdgeInsets.only(
          left: 50,
        ),
        child: AppUtils.kDivider1,
      ),
    );
  }
}
