import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/core/extension/extension.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/widgets/product_item2.dart';

class ProductListWidget extends StatelessWidget {
  const ProductListWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (ctr) => SliverPadding(
        padding: const EdgeInsets.only(
          top: 16,
          bottom: 16,
        ),
        sliver: SliverList(
          delegate: SliverChildBuilderDelegate(
            (context, index) {
              if (index.isEven) {
                var category = ctr.checkedCategories.isNotEmpty &&
                        ctr.checkedCategories.length <= ctr.categories.length
                    ? ctr.checkedCategories[index.exactIndex]
                    : ctr.categories[index.exactIndex];
                return Material(
                  color: AppColors.white,
                  borderRadius: AppUtils.kBorderRadius12,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                          top: 16,
                          right: 16,
                          left: 16,
                        ),
                        child: Text(
                          BaseFunctions.getTranslateLanguage(category.title),
                          style: styCategoryTitle,
                          semanticsLabel: '',
                        ),
                      ),
                      if (category.products.isNotEmpty)
                        ...List.generate(
                          category.products.length.doubleTheListCount,
                          (index) {
                            if (index.isEven) {
                              return ProductItem(
                                isDeliveryTypeSelected:
                                    ctr.deliveryAddress != null ||
                                        ctr.pickUpBranch != null,
                                isInStopList: ctr.menuId.isNotEmpty &&
                                    !(category.products[index.exactIndex]
                                            .activeInMenu ??
                                        false),
                                product: category.products[index.exactIndex],
                              );
                            }
                            return AppUtils.kDividerPadding16;
                          },
                        ),
                    ],
                  ),
                );
              }
              return AppUtils.kBoxHeight16;
            },
            childCount: ctr.checkedCategories.isNotEmpty &&
                    ctr.checkedCategories.length <= ctr.categories.length
                ? ctr.checkedCategories.length.doubleTheListCount
                : ctr.categories.length.doubleTheListCount,
          ),
        ),
      ),
    );
  }
}
