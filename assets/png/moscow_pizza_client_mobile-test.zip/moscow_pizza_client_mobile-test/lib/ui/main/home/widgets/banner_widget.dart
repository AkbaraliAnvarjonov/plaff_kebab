import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';

import 'banner_item.dart';

class BannerWidget extends StatelessWidget {
  const BannerWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (ctr) {
        if (ctr.banners.isEmpty) {
          return AppUtils.kBox;
        }
        return Container(
          decoration: const BoxDecoration(
            color: AppColors.white,
            borderRadius: AppUtils.kBorderRadius12,
          ),
          height: ((Get.width - 24) / (1248 / 540)) + 36,
          padding: AppUtils.kVerticalPadding12,
          margin: const EdgeInsets.only(top: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                height: (Get.width - 24) / (1248 / 540),
                child: PageView.builder(
                  controller: ctr.pageController,
                  onPageChanged: (i) {
                    ctr.setBannersIndex(i);
                  },
                  itemCount: ctr.banners.length,
                  itemBuilder: (context, index) {
                    var banner = ctr.banners[index];
                    return BannerItem(
                      banner: banner,
                      onTap: () => Get.toNamed(
                        AppRoutes.bannerDetail,
                        arguments: banner,
                      ),
                    );
                  },
                ),
              ),
              AppUtils.kBoxHeight8,
              SizedBox(
                height: 4,
                child: Center(
                  child: ListView.separated(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: ctr.banners.length,
                    itemBuilder: (_, index) {
                      return AnimatedContainer(
                        width: index == ctr.bannersIndex ? 16 : 8,
                        height: 4,
                        duration: const Duration(milliseconds: 300),
                        decoration: BoxDecoration(
                            borderRadius: AppUtils.kBorderRadius16,
                            color: index == ctr.bannersIndex
                                ? AppColors.assets
                                : AppColors.grey100),
                      );
                    },
                    separatorBuilder: (_, __) => AppUtils.kBoxWidth4,
                  ),
                ),
              )
            ],
          ),
        );
      },
    );
  }
}
