import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_circular_progress_indicator.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/flappy_searchbar/flappy_search_bar.dart'
    as flappy;
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/routes/args/product_detail_page_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/widgets/banner_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/widgets/product_list_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/widgets/search_item.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/widgets/tab_list_widget.dart';
import '../../../core/custom_widgets/custom_android_ios_indicator.dart';
import '../../../data/models/products_v2_response.dart';

class HomePage extends GetView<HomeController> {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HomeController>(
      builder: (ctr) {
        return Scaffold(
          appBar: AppBar(
            centerTitle: false,
            scrolledUnderElevation: 0,
            title: InkWell(
              borderRadius: AppUtils.kBorderRadius8,
              onTap: () {
                Get.toNamed(AppRoutes.deliveryTypeMap);
                return;
                // Get.toNamed(AppRoutes.AUTH);
                // showModalBottomSheet(
                //     context: context,
                //     builder: (context) => GetBuilder<HomeController>(
                //       builder: (ctr) {
                //         return HomeAddressBottomSheet(
                //           addresses: ctr.customerAddresses,
                //           onTap: () async {
                //             Get.back();
                //             Get.toNamed(AppRoutes.deliveryTypeMap);
                //             // final result = await Get.toNamed(AppRoutes.MAP);
                //             // if (result != null) {
                //             //   controller.getMyAddress();
                //             // }
                //           },
                //           onChanged: (index) {
                //             ctr.setAddressChecked(index);
                //             Get.back();
                //           },
                //         );
                //       },
                //     ),
                //     backgroundColor: Colors.transparent,
                //   );
              },
              child: Ink(
                padding: AppUtils.kAllPadding2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (ctr.deliveryAddress != null || ctr.pickUpBranch != null)
                      Text(ctr.deliveryAddress != null
                          ? 'delivery'.tr
                          : 'self_call'.tr),
                    AppUtils.kBoxHeight2,
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          AppIcons.location,
                          size: 16,
                        ),
                        AppUtils.kBoxWidth8,
                        Flexible(
                          child: ConstrainedBox(
                            constraints: BoxConstraints(
                              maxWidth: Get.width * 0.8,
                            ),
                            child: ctr.deliveryAddress != null ||
                                    ctr.pickUpBranch != null
                                ? Text(
                                    ctr.deliveryAddress != null
                                        ? ctr.deliveryAddress?.addressName ?? ''
                                        : ctr.pickUpBranch?.branchName ?? '',
                                    overflow: TextOverflow.ellipsis,
                                    semanticsLabel: 'current_address',
                                    style: AppTextStyles.blackText15,
                                  )
                                : Text(
                                    'add_address'.tr,
                                    style: AppTextStyles.blackText15,
                                  ),
                          ),
                        ),
                        AppUtils.kBoxWidth8,
                        const Icon(
                          Icons.keyboard_arrow_down_outlined,
                          color: AppColors.black3,
                          size: 16,
                        )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
          body: flappy.SearchBar<Products>(
            onError: (error) => Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  AppUtils.kBoxHeight2,
                  const Image(
                    image: AssetImage(
                      'assets/png/ic_paper_bag.png',
                    ),
                    width: 120,
                    height: 120,
                  ),
                  Text(
                    'not_found'.tr,
                    style: stySearchNotFound,
                  )
                ],
              ),
            ),
            hintText: 'search'.tr,
            hintStyle: stySearchItem.copyWith(color: AppColors.grey),
            textStyle: stySearchItem,
            searchBarPadding: const EdgeInsets.only(
              right: 12,
              left: 12,
              bottom: 16,
            ),
            focusNode: FocusNode(),
            cancellationWidget: Text(
              'cancel'.tr,
              maxLines: 1,
              style: stySearchItem,
              textAlign: TextAlign.center,
            ),
            placeHolder: GetBuilder<HomeController>(
              builder: (ctr) {
                return ModalProgressHUD(
                  inAsyncCall: ctr.isLoading.value,
                  child: CustomScrollView(
                    controller: ctr.scrollController,
                    keyboardDismissBehavior:
                        ScrollViewKeyboardDismissBehavior.onDrag,
                    slivers: [
                      if (ctr.categories.isNotEmpty)
                        const SliverAppBar(
                          pinned: true,
                          expandedHeight: 0,
                          floating: true,
                          toolbarHeight: 0,
                          elevation: 0,
                          titleSpacing: 0,
                          bottom: PreferredSize(
                            preferredSize: Size.fromHeight(52),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TabListWidget(),
                                AppUtils.kBoxHeight12,
                              ],
                            ),
                          ),
                        ),
                      CustomAndroidIosIndicator(
                        onRefreshAndroid: () async {
                          await controller.refreshCategoryWithProductsV2();
                          return;
                        },
                        onRefreshIos: () async {
                          await controller.refreshCategoryWithProductsV2();
                          return;
                        },
                      ),
                      SliverList(
                        delegate: SliverChildBuilderDelegate(
                          (_, index) => const BannerWidget(),
                          childCount: 1,
                        ),
                      ),
                      const ProductListWidget(),
                    ],
                  ),
                );
              },
            ),
            onItemFound: (product, index) => SearchItem(
              product: product,
              onTap: () async {
                await Get.toNamed(
                  AppRoutes.productDetail,
                  arguments: ProductDetailPageArguments(
                    product: ProductByIdResponse(
                      id: product?.id,
                      image: product?.image,
                      title: product?.title,
                      description: product?.description,
                    ),
                  ),
                );
              },
            ),
            onSearch: ctr.searchProductV2,
            listPadding: AppUtils.kAllPadding12,
            loader: const Center(child: CustomCircularProgressIndicator()),
          ),
        );
      },
    );
  }
}
