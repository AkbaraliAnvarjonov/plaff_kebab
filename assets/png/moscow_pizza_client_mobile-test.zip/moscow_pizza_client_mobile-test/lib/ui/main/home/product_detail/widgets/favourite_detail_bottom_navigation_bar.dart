import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../controller/main/main_controller.dart';
import '../../../../../core/custom_widgets/buttons/custom_button.dart';
import '../../../../../core/keys/app_keys.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import 'favourite_detail_plus_minus.dart';

class FavouriteDetailBottomNavigationBar extends StatelessWidget {
  const FavouriteDetailBottomNavigationBar({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) => Material(
        color: AppColors.white,
        child: ValueListenableBuilder<Box<Products>>(
          valueListenable: Hive.box<Products>(AppKeys.productsHiveKey).listenable(),
          builder: (_, snapshot, __) {
            ctr.getHiveUniqueKey();
            bool isBasket = false;
            String hiveUniqueKey =
            BaseFunctions.stringLengthMax255(ctr.hiveUniqueKey);
            if (ctr.productInBasketIds.contains(hiveUniqueKey)) {
              isBasket = true;
            }
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: [
                AppUtils.kDivider1,
                AppUtils.kBoxHeight12,
                ctr.productById != null
                    ? FavouriteDetailPlusMinus(isBasket: isBasket)
                    : LinearProgressIndicator(
                  backgroundColor: AppColors.assets.withOpacity(0.3),
                  valueColor:
                  const AlwaysStoppedAnimation(AppColors.assets),
                ),
                SafeArea(
                  minimum: AppUtils.kAllPadding16,
                  child: CustomButton(
                    onTap: ctr.isLoading.value
                        ? null
                        : () async {
                      if (ctr.optionAvailable) {
                        if (isBasket) {
                          Get.back(result: true);
                          await Get.find<MainController>().changeTabIndex(1);
                        } else {
                          ctr..showSuccessMessage("add_success".tr)
                          ..findModifier();
                        }
                      }
                    },
                    text: isBasket ? 'move_to_basket'.tr : 'add'.tr,
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
