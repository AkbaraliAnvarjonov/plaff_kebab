import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_circular_progress_indicator.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';

import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import 'favourite_detail_group_modifier_pm_button.dart';

class FavouriteDetailGroupModifiersWidget extends StatelessWidget {
  final GroupModifiers? groupModifiers;
  final int? parentIndex;

  const FavouriteDetailGroupModifiersWidget({
    Key? key,
    required this.groupModifiers,
    this.parentIndex,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) {
        return Container(
          margin: AppUtils.kTopMargin12,
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          child: ctr.isLoading.value
              ? const Center(child: CustomCircularProgressIndicator())
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                        padding: const EdgeInsets.only(
                          left: 12,
                          right: 12,
                          top: 12,
                        ),
                        child: Text.rich(
                          TextSpan(
                            text: BaseFunctions.getStringSingleModifierName(
                                groupModifiers?.name),
                            children: [
                              (groupModifiers?.isCompulsory ?? false)
                                  ? const TextSpan(
                                      text: '*',
                                      style: TextStyle(
                                        color: AppColors.red,
                                      ),
                                    )
                                  : const TextSpan(text: ''),
                            ],
                          ),
                          style: AppTextStyles.styGroupModifierName,
                          maxLines: 1,
                        )),
                    ListView.separated(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      padding: EdgeInsets.zero,
                      itemCount: groupModifiers?.variants?.length ?? 0,
                      itemBuilder: (ctx, index) {
                        return Padding(
                          padding: const EdgeInsets.only(
                              left: 12, right: 10, top: 12, bottom: 12),
                          child: Column(
                            children: [
                              InkWell(
                                onTap: () {
                                  ctr..checkedGroupModifier(
                                      parentIndex ?? 0, index)
                                  ..limitedGroupModifiers(
                                      parentIndex ?? 0, index);
                                },
                                child: Row(
                                  children: [
                                    (groupModifiers
                                                ?.variants?[index].isChecked ??
                                            false)
                                        ? const Icon(
                                            Icons.check_circle,
                                            size: 24,
                                            color: AppColors.assets,
                                          )
                                        : const Icon(
                                            Icons.radio_button_unchecked,
                                            size: 24,
                                            color: AppColors.unChecked,
                                          ),
                                    Expanded(
                                      child: Padding(
                                        padding:
                                            const EdgeInsets.only(left: 10),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Expanded(
                                              child: Text(
                                                BaseFunctions
                                                    .getModifierTitleTranslate(
                                                        groupModifiers
                                                            ?.variants?[index]
                                                            .title),
                                                maxLines: 1,
                                                style: const TextStyle(
                                                    fontWeight: FontWeight.w400,
                                                    fontSize: 15,
                                                    color: Color.fromRGBO(
                                                        20, 20, 20, 1)),
                                              ),
                                            ),
                                            Text(
                                              '+${groupModifiers?.variants?[index].outPrice ?? 0}',
                                              style: const TextStyle(
                                                fontWeight: FontWeight.w400,
                                                fontSize: 15,
                                                color: Color.fromRGBO(
                                                    133, 133, 133, 1),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              FavouriteDetailGroupModifierPMButton(
                                  variants: groupModifiers?.variants?[index],
                                  index: index,
                                  parentIndex: parentIndex)
                            ],
                          ),
                        );
                      },
                      separatorBuilder: (context, index) =>
                          const Padding(
                        padding: EdgeInsets.only(left: 48),
                        child: AppUtils.kDivider1,
                      ),
                    ),
                  ],
                ),
        );
      },
    );
  }
}
