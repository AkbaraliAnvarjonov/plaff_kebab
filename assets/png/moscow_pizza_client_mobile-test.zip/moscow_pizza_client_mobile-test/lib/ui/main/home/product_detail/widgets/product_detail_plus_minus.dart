import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../../base/base_functions.dart';
import '../../../../../controller/home/product_detail_controller.dart';
import '../../../../../core/custom_widgets/plus_minus_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';

class ProductDetailPlusMinus extends StatelessWidget {
  final bool isBasket;

  const ProductDetailPlusMinus({
    Key? key,
    required this.isBasket,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) {
        double totalPriceWithDiscount = (ctr.price +
                    ctr.productDiscounts +
                    ctr.priceOfSingleModifier +
                    ctr.priceOfGroupModifier) *
                ctr.quantity
            ;
        double totalTrice = (ctr.price +
                    ctr.priceOfSingleModifier +
                    ctr.priceOfGroupModifier) *
                ctr.quantity
            ;
        return Padding(
          padding: AppUtils.kHorizontalPadding12,
          child: ctr.optionAvailable
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    DecoratedBox(
                      decoration: BoxDecoration(
                        color: AppColors.white,
                        borderRadius: AppUtils.kBorderRadius8,
                        border: Border.all(
                          color: AppColors.inactive,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          PlusMinusButton(
                            // ignore: avoid_bool_literals_in_conditional_expressions
                            isDisable: ctr.quantity == 1 ? true : false,
                            isMinus: true,
                            onTap: () {
                              if (!(ctr.hasModifier ||
                                  ctr.productType == 'combo')) {
                                ctr.updateQuantity(isMinus: true);
                              }
                              // else if (isBasket) {
                              //   ctr.updateQuantity();
                              // }
                              ctr.decrementQuantity();
                            },
                          ),
                          Padding(
                            padding: AppUtils.kHorizontalPadding8,
                            child: Text(
                              BaseFunctions.moneyFormat(ctr.quantity),
                              style: styProductDetailQuantity,
                            ),
                          ),
                          PlusMinusButton(
                            onTap: () {
                              if (!(ctr.hasModifier ||
                                  ctr.productType == 'combo')) {
                                ctr.updateQuantity();
                              }
                              // else if (isBasket) {
                              //   ctr.updateQuantity();
                              // }
                              ctr.incrementQuantity();
                            },
                          ),
                        ],
                      ),
                    ),
                    const Spacer(),
                    Column(
                      children: [
                        Text(
                          BaseFunctions.moneyFormatSymbol(
                              totalPriceWithDiscount),
                          style: AppTextStyles.productDetailButton,
                        ),
                        if (totalTrice != totalPriceWithDiscount)
                          Text(
                            BaseFunctions.moneyFormatSymbol(totalTrice),
                            style: AppTextStyles.productDetailButton.copyWith(
                                decoration: TextDecoration.lineThrough),
                          ),
                      ],
                    ),
                  ],
                )
              : Text(
                  'this_type_not_available'.tr,
                  style: styConfirmCodeErrorText,
                ),
        );
      },
    );
  }
}
