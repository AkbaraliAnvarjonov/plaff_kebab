import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/product_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_combo_basic_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_combo_choice_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_detail_bottom_navigation_bar.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_detail_option_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_detail_single_modifiers_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_detail_banner.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_detail_title_desc.dart';
import '../../../../core/custom_widgets/custom_circular_progress_indicator.dart';
import 'widgets/product_detail_group_modifiers_widget.dart';

class ProductDetailPage extends GetView<ProductDetailController> {
  const ProductDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GetBuilder<ProductDetailController>(
        builder: (ctr) => NestedScrollView(
          physics: const ClampingScrollPhysics(),
          headerSliverBuilder: (context, innerBoxIsScrolled) {
            return [
              ProductDetailBanner(
                innerBoxIsScrolled: innerBoxIsScrolled,
              ),
            ];
          },
          body: CustomScrollView(
            physics: const ClampingScrollPhysics(),
            keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
            slivers: [
              const SliverToBoxAdapter(child: ProductDetailTitleDesc()),
              SliverList(
                delegate: SliverChildListDelegate(
                  [
                    ...List.generate(
                      ctr.products?.length ?? 0,
                      (index) {
                        return ctr.products?[index].type == 'combo_basic'
                            ? ProductComboBasicWidget(
                                product: ctr.products?[index],
                                index: index,
                              )
                            : ProductComboChoiceWidget(
                                product: ctr.products?[index],
                                index: index,
                              );
                      },
                    ),

                    /// Options
                    ...List.generate(
                      controller.productById?.properties?.length ?? 0,
                      (index) => ProductDetailOptionWidget(
                        properties: controller.productById?.properties?[index],
                        indexProperty: index,
                      ),
                    ),
                  ],
                ),
              ),

              // Single Modifiers
              SliverToBoxAdapter(
                child: Visibility(
                  visible:
                      ctr.singleModifiersLength > 0 && controller.hasModifier,
                  child: ctr.isLoading.value
                      ? const Center(child: CustomCircularProgressIndicator())
                      : ListView.builder(
                          padding: EdgeInsets.zero,
                          itemCount: ctr.singleModifiersLength,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return ProductDetailSingleModifiersWidget(
                              index: index,
                              singleModifiers: controller
                                  .productModifiers?.singleModifiers?[index],
                            );
                          },
                        ),
                ),
              ),
              //Group Modifiers
              SliverToBoxAdapter(
                child: Visibility(
                  visible:
                      ctr.groupModifiersLength > 0 && controller.hasModifier,
                  child: ListView.builder(
                    padding: EdgeInsets.zero,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemCount: ctr.groupModifiersLength,
                    itemBuilder: (context, index) {
                      return ProductDetailGroupModifiersWidget(
                        parentIndex: index,
                        groupModifiers:
                            controller.productModifiers?.groupModifiers?[index],
                      );
                    },
                  ),
                ),
              ),
              if (ctr.productById?.favorites?.isEmpty ?? false)
                const SliverToBoxAdapter(
                  child: SizedBox(height: 12),
                ),
              SliverToBoxAdapter(
                child: Visibility(
                  visible: ctr.productById?.favorites?.isNotEmpty ?? false,
                  child: FavouriteWidget(
                    favorites: ctr.productById?.favorites,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: const ProductDetailBottomNavigationBar(),
    );
  }
}
