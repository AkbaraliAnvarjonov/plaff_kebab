import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';
import '../../../../../core/theme/app_text_style.dart';
import 'favourite_detail_single_modifier_pm_button.dart';

class FavouriteDetailSingleModifiersWidget extends StatelessWidget {
  final SingleModifiers? singleModifiers;
  final int? index;

  const FavouriteDetailSingleModifiersWidget({
    Key? key,
    required this.singleModifiers,
    this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) {
        return Container(
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          margin: AppUtils.kTopMargin12,
          padding: AppUtils.kAllPadding16,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: AppUtils.kBottomMargin16,
                child: Text(
                  BaseFunctions.getStringSingleModifierName(
                    singleModifiers?.categoryName,
                  ),
                  style: styProfileAppBarTitles.copyWith(color: AppColors.black6),
                ),
              ),
              InkWell(
                onTap: () {
                  if ((singleModifiers?.isCompulsory ?? false) == false) {
                    ctr.checkedSingleModifier(index ?? 0);
                  }
                },
                child: Row(
                  children: [
                    (singleModifiers?.isChecked ?? false)
                        ? const Icon(
                            Icons.check_circle_rounded,
                            size: 24,
                            color: AppColors.assets,
                          )
                        : const Icon(
                            Icons.radio_button_unchecked,
                            size: 24,
                            color: AppColors.unChecked,
                          ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text.rich(
                                TextSpan(
                                  text:
                                      BaseFunctions.getStringSingleModifierName(
                                          singleModifiers?.name),
                                  children: [
                                    (singleModifiers?.isCompulsory ?? false)
                                        ? const TextSpan(
                                            text: '*',
                                            style: TextStyle(
                                              color: AppColors.red,
                                            ))
                                        : const TextSpan(text: ''),
                                  ],
                                ),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 15,
                                  color: Color.fromRGBO(20, 20, 20, 1),
                                ),
                                maxLines: 1,
                              ),
                            ),
                            Text(
                              (singleModifiers?.price?.isNotEmpty ?? false)
                                  ? '+${singleModifiers?.price ?? 0}'
                                  : '',
                              style: const TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 15,
                                color: Color.fromRGBO(133, 133, 133, 1),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              FavouriteDetailSingleModifierPMButton(
                index: index,
                singleModifiers: singleModifiers,
              ),
            ],
          ),
        );
      },
    );
  }
}
