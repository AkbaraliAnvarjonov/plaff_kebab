import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/banner_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/banners_response.dart';

class BannerDetailPage extends GetView<BannerDetailController> {
  const BannerDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var banner = Get.arguments as Banners;
    final width = Get.width - 24;
    return Scaffold(
      appBar: AppBar(title: Text('promotions'.tr)),
      body: Stack(
        children: [
          Align(
            alignment: Alignment.topCenter,
            child: Padding(
              padding: AppUtils.kAllPadding12,
              child: ClipRRect(
                borderRadius: AppUtils.kBorderRadius12,
                child: Material(
                  color: AppColors.white,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ClipRRect(
                        borderRadius: AppUtils.kBorderRadius12,
                        child: SizedBox(
                          height: (Get.width - 24) / (1248 / 540),
                          child: Hero(
                            tag: banner.id ?? '',
                            child: CachedNetworkImage(
                              imageUrl: banner.image ?? '',
                              fit: BoxFit.cover,
                              width: double.infinity,
                              height: width,
                              progressIndicatorBuilder:
                                  (context, url, downloadProgress) => Center(
                                child: Platform.isAndroid
                                    ? const CircularProgressIndicator()
                                    : const CupertinoActivityIndicator(),
                              ),
                              errorWidget: (context, url, error) => Center(
                                child: Image.asset(
                                  "assets/png/moscowskaya_pizza.png",
                                  height: 136,
                                  width: 136,
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          top: 12,
                          bottom: 8,
                          left: 12,
                          right: 12,
                        ),
                        child: Text(
                          BaseFunctions.getStringByLanguage(banner.title),
                          style: styBannerDetailTitle.copyWith(
                            color: AppColors.black6,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(
                          left: 12,
                          right: 12,
                          bottom: 12,
                        ),
                        child: Text(
                          BaseFunctions.getStringByLanguage(banner.title),
                          style: styBannerDetailDescription.copyWith(
                            color: AppColors.black,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
