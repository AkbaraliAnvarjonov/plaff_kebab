import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../core/custom_widgets/plus_minus_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';

class FavouriteDetailSingleModifierPMButton extends StatelessWidget {
  final SingleModifiers? singleModifiers;
  final int? index;

  const FavouriteDetailSingleModifierPMButton(
      {Key? key, required this.singleModifiers, required this.index})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) {
        if ((singleModifiers?.isChecked ?? false) &&
            ctr.max(index ?? 0) &&
            (singleModifiers?.price?.isNotEmpty ?? false)) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                margin: AppUtils.kTopMargin12,
                padding:
                    const EdgeInsets.only(left: 6, top: 5, right: 6, bottom: 5),
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: AppUtils.kBorderRadius8,
                  border: Border.all(
                    color: AppColors.inactive,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    PlusMinusButton(
                      onTap: () {
                        ctr..decrementSingleModifier(index ?? 0)
                        ..incrementPriceOfSingleModifier(index ?? 0);
                      },
                      size: 24,
                      isMinus: true,
                      borderRadius: AppUtils.kBorderRadius4,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: Text(
                        BaseFunctions.moneyFormat(singleModifiers?.count ?? 0),
                        style: styProductDetailQuantity,
                      ),
                    ),
                    PlusMinusButton(
                      onTap: () {
                        ctr..incrementSingleModifier(index ?? 0)
                        ..incrementPriceOfSingleModifier(index ?? 0);
                      },
                      size: 24,
                      borderRadius: AppUtils.kBorderRadius4,
                    ),
                  ],
                ),
              ),
            ],
          );
        } else {
          return AppUtils.kBox;
        }
      },
    );
  }
}
