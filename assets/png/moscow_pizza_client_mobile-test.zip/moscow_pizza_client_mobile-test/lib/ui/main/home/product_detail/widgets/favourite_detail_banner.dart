import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:share_plus/share_plus.dart';

import '../../../../../core/constants/constants.dart';
import '../../../../../core/custom_widgets/buttons/circle_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_icons.dart';
import '../../../../../core/theme/app_utils.dart';

class FavouriteDetailBanner extends StatelessWidget {
  const FavouriteDetailBanner({
    Key? key,
    required this.size,
    required this.top,
  }) : super(key: key);

  final Size size;
  final double top;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) => SizedBox(
        height:
        (260 / AppConstants.designSize.height * size.height).ceilToDouble(),
        child: Stack(
          children: [
            Positioned.fill(
              child: Hero(
                tag: ctr.product.title ?? '',
                child: FadeInImage.assetNetwork(
                  imageCacheHeight: 400,
                  imageCacheWidth: 400,
                  height: 260 / AppConstants.designSize.height * size.height,
                  image:
                  '${AppConstants.imageUrl}${ctr.optionImage ?? ctr.product.image}',
                  fit: BoxFit.fill,
                  placeholder: 'assets/png/product_place_holder.png',
                  placeholderErrorBuilder: (_, __, ___) {
                    return const Center(
                      child: Image(
                        image: AssetImage(
                          'assets/png/product_place_holder.png',
                        ),
                      ),
                    );
                  },
                  imageErrorBuilder: (_, __, ___) {
                    return const Center(
                      child: Image(
                        image: AssetImage(
                          'assets/png/product_place_holder.png',
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            Positioned(
              top: top,
              right: 16,
              left: 16,
              height: kToolbarHeight,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  CircleButton(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    icon: Platform.isAndroid
                        ? Icons.arrow_back
                        : Icons.arrow_back_ios_rounded,
                  ),
                  CircleButton(
                    onTap: () {
                      Share.share(AppConstants.shareLink);
                    },
                    icon: AppIcons.share,
                  ),
                ],
              ),
            ),
            const Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              height: 16,
              child: Material(
                borderRadius: AppUtils.kBorderTopRadius12,
                color: AppColors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
