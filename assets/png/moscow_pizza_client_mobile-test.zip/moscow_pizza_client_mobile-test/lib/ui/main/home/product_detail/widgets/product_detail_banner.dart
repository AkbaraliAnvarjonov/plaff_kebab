import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:share_plus/share_plus.dart';

import '../../../../../controller/home/product_detail_controller.dart';
import '../../../../../core/constants/constants.dart';
import '../../../../../core/custom_widgets/buttons/circle_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_icons.dart';
import '../../../../../core/theme/app_utils.dart';

class ProductDetailBanner extends StatelessWidget {
  const ProductDetailBanner({
    Key? key,
    required this.innerBoxIsScrolled,
  }) : super(key: key);

  final bool innerBoxIsScrolled;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) {
        return SliverAppBar(
          pinned: true,
          leading: Align(
            alignment: Alignment.centerRight,
            child: CircleButton(
              onTap: () {
                Navigator.pop(context);
              },
              icon: Platform.isAndroid
                  ? Icons.arrow_back
                  : Icons.arrow_back_ios_rounded,
            ),
          ),
          expandedHeight: Get.width / (600 / 400),
          actions: [
            CircleButton(
              onTap: () {
                Share.share(AppConstants.shareLink);
              },
              icon: AppIcons.share,
            ),
            AppUtils.kBoxWidth16,
          ],
          flexibleSpace: FlexibleSpaceBar(
            title: innerBoxIsScrolled
                ? Text(
                    BaseFunctions.getTranslateLanguage(ctr.product.title),
                    textScaleFactor: 1,
                    style: AppTextStyles.appBarTitle,
                  )
                : null,
            background: Hero(
              tag: ctr.product.title ?? '',
              child: Stack(
                children: [
                  Positioned.fill(
                    child: FadeInImage.assetNetwork(
                      imageCacheHeight: 400,
                      imageCacheWidth: 400,
                      height: Get.width / (600 / 400),
                      image:
                          '${AppConstants.imageUrl}${ctr.optionImage ?? ctr.product.image}',
                      fit: BoxFit.fill,
                      placeholder: 'assets/png/product_place_holder.png',
                      placeholderErrorBuilder: (_, __, ___) {
                        return const Center(
                          child: Image(
                            image: AssetImage(
                              'assets/png/product_place_holder.png',
                            ),
                          ),
                        );
                      },
                      imageErrorBuilder: (_, __, ___) {
                        return const Center(
                          child: Image(
                            image: AssetImage(
                              'assets/png/product_place_holder.png',
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    height: 16,
                    child: Material(
                      borderRadius: AppUtils.kBorderTopRadius12,
                      color: AppColors.white,
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
    // return GetBuilder<ProductDetailController>(
    //   builder: (ctr) => SizedBox(
    //     height: Get.width / (600 / 400),
    //     child: Stack(
    //       children: [
    //         Positioned.fill(
    //           child: Hero(
    //             tag: ctr.product.title ?? '',
    //             child: FadeInImage.assetNetwork(
    //               imageCacheHeight: 400,
    //               imageCacheWidth: 400,
    //               height: Get.width / (600 / 400),
    //               image:
    //                   '${AppConstants.imageUrl}${ctr.optionImage ?? ctr.product.image}',
    //               fit: BoxFit.fill,
    //               placeholder: 'assets/png/product_place_holder.png',
    //               placeholderErrorBuilder: (_, __, ___) {
    //                 return const Center(
    //                   child: Image(
    //                     image: AssetImage(
    //                       'assets/png/product_place_holder.png',
    //                     ),
    //                   ),
    //                 );
    //               },
    //               imageErrorBuilder: (_, __, ___) {
    //                 return const Center(
    //                   child: Image(
    //                     image: AssetImage(
    //                       'assets/png/product_place_holder.png',
    //                     ),
    //                   ),
    //                 );
    //               },
    //             ),
    //           ),
    //         ),
    //         Positioned(
    //           top: top,
    //           right: 16,
    //           left: 16,
    //           height: kToolbarHeight,
    //           child: Row(
    //             mainAxisAlignment: MainAxisAlignment.spaceBetween,
    //             children: [
    //               CircleButton(
    //                 onTap: () {
    //                   Navigator.pop(context);
    //                 },
    //                 icon: Platform.isAndroid
    //                     ? Icons.arrow_back
    //                     : Icons.arrow_back_ios_rounded,
    //               ),
    //               CircleButton(
    //                 onTap: () {
    //                   Share.share(AppConstants.shareLink);
    //                 },
    //                 icon: AppIcons.share,
    //               ),
    //             ],
    //           ),
    //         ),
    //         const Positioned(
    //           left: 0,
    //           right: 0,
    //           bottom: 0,
    //           height: 16,
    //           child: Material(
    //             borderRadius: AppUtils.kBorderTopRadius12,
    //             color: AppColors.white,
    //           ),
    //         ),
    //       ],
    //     ),
    //   ),
    // );
  }
}
