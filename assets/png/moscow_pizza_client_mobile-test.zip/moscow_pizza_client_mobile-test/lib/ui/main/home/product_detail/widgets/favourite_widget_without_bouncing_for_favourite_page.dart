import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/extension/number_parsing.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../core/custom_widgets/plus_minus_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import '../../../../../data/models/product_by_id_response.dart';
import '../../../widgets/attention_dialog.dart';

class FavouriteWidgetWithoutBouncingForFavouritePage extends StatelessWidget {
  const FavouriteWidgetWithoutBouncingForFavouritePage({
    Key? key,
    required this.favorites,
    required this.index,
  }) : super(key: key);

  final List<Favourites>? favorites;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) => Container(
        margin: AppUtils.kAllPadding8,
        height: 36,
        decoration: const BoxDecoration(
          color: AppColors.white,
          borderRadius: AppUtils.kBorderRadius8,
          boxShadow: [
            BoxShadow(
              blurRadius: 10,
              color: Color.fromRGBO(0, 0, 0, 0.05),
            )
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            PlusMinusButton(
              isMinus: true,
              onTap: () {
                if (BaseFunctions.moneyFormat(favorites?[index].quantity ?? 1)
                        .toInt() ==
                    1) {
                  showDialog(
                    context: context,
                    barrierDismissible: true,
                    builder: (context) => AttentionDialog(
                      onDone: () async {
                        await ctr.repository?.removeProduct(Products(
                          id: favorites?[index].id ?? '',
                          image: favorites?[index].image ?? '',
                          name: favorites?[index].title?.parseTitle(),
                          price: double.tryParse(
                                  (favorites?[index].outPrice ?? 0.0)
                                      .toString()) ??
                              0.0,
                          quantity: 1,
                          uniqueId: favorites?[index].id ?? '',
                          modifiers: [],
                        ));
                        Get.back();
                      },
                    ),
                  );
                } else {
                  ctr.updateFav(
                      index: index,
                      isMinus: true,
                      favourites: favorites?[index]);
                }
              },
            ),
            Padding(
              padding: AppUtils.kHorizontalPadding8,
              child: Text(
                BaseFunctions.moneyFormat(favorites?[index].quantity ?? 1),
                style: styProductDetailQuantity,
              ),
            ),
            PlusMinusButton(
              onTap: () {
                ctr.updateFav(
                    index: index,
                    favourites: favorites?[index]);
              },
            ),
          ],
        ),
      ),
    );
  }
}
