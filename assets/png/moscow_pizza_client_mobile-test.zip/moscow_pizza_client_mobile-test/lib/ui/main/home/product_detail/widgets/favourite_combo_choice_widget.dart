import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/data/models/combo_response.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';

class FavouriteComboChoiceWidget extends StatelessWidget {
  const FavouriteComboChoiceWidget({
    Key? key,
    required this.product,
    required this.index,
  }) : super(key: key);
  final Groups? product;
  final int index;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: AppUtils.kBorderRadius12,
        color: AppColors.white,
      ),
      margin: AppUtils.kTopMargin12,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding:
                const EdgeInsets.only(top: 16, right: 12, left: 12, bottom: 12),
            child: Text(
              BaseFunctions.getTranslateLanguage(product?.title),
              style: styProfileAppBarTitles.copyWith(color: AppColors.black6),
            ),
          ),
          AppUtils.kDivider1,
          GetBuilder<FavouriteDetailController>(
            builder: (ctr) => ListView.separated(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: product?.variants?.length ?? 0,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                return InkWell(
                  highlightColor: AppColors.transparent,
                  onTap: () {
                    ctr.comboChoiceSelection(this.index, index);
                  },
                  child: Padding(
                    padding: AppUtils.kAllPadding16,
                    child: Row(
                      children: [
                        (product?.selectedIndex ?? 0) == index
                            ? const Icon(
                                AppIcons.radio,
                                size: 24,
                                color: AppColors.assets,
                              )
                            : const Icon(
                                Icons.radio_button_unchecked,
                                size: 24,
                                color: AppColors.unChecked,
                              ),
                        AppUtils.kBoxWidth10,
                        Expanded(
                          child: Text(
                            BaseFunctions.getTranslateLanguage(
                                product?.variants?[index].title),
                            style: styProductDetailButton.copyWith(
                              color: AppColors.black,
                            ),
                            overflow: TextOverflow.ellipsis,
                            maxLines: 1,
                          ),
                        ),
                        Padding(
                          padding: AppUtils.kPaddingLeft16,
                          child: Text('x${product?.quantity ?? 0}'),
                        ),
                      ],
                    ),
                  ),
                );
              },
              separatorBuilder: (context, index) =>
                  const Padding(
                padding: AppUtils.kPaddingLeft16,
                child: AppUtils.kDivider1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
