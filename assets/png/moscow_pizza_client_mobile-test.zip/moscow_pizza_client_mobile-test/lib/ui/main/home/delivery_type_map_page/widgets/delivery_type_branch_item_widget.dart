import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';

class DeliveryTypeBranchItemWidget extends StatelessWidget {
  final Function()? onTap;
  final Branches? branch;
  final Position? locationData;
  final bool isSelected;

  const DeliveryTypeBranchItemWidget({
    Key? key,
    this.onTap,
    this.branch,
    this.locationData,
    this.isSelected = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: AppUtils.kBorderRadius12,
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(
              color: isSelected ? AppColors.assets : AppColors.transparent),
          color: AppColors.textFieldColor,
          borderRadius: AppUtils.kBorderRadius8,
        ),
        padding: AppUtils.kAllPadding12,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              branch?.name ?? '',
              style: styCheckoutOrderBranchesItemName,
            ),
            Text(
              branch?.address ?? '',
              style: styAddress2,
            ),
            Text(
              '${'open_until'.tr} ${branch?.workHourEnd ?? ''}',
              style: styAddress2,
            ),
          ],
        ),
      ),
    );
  }
}
