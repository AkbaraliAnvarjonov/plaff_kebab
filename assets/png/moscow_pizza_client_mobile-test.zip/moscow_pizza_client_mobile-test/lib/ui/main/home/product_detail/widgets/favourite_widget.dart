import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/product_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_utils.dart';
import 'favourite_widget_body.dart';

class FavouriteWidget extends StatelessWidget {
  final List<Favourites>? favorites;

  const FavouriteWidget({Key? key, required this.favorites}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) => Container(
        padding: AppUtils.kAllPadding16,
        margin: const EdgeInsets.only(top: 12, bottom: 12),
        decoration: const BoxDecoration(
          borderRadius: AppUtils.kBorderRadius12,
          color: AppColors.white,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: AppUtils.kBottomMargin16,
              child: Text(
                'favourites'.tr,
                style: styProfileCondensationPolicyText,
              ),
            ),
            SizedBox(
              height: 240,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return FavouriteWidgetBody(
                      favorites: favorites, index: index);
                },
                separatorBuilder: (context, index) => AppUtils.kBoxWidth8,
                itemCount: favorites?.length ?? 0,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
