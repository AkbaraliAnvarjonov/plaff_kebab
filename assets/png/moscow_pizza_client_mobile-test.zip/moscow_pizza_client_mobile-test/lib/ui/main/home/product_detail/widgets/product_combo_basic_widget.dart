import 'package:flutter/material.dart';
import '../../../../../base/base_functions.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/models/combo_response.dart';

class ProductComboBasicWidget extends StatelessWidget {
  const ProductComboBasicWidget({
    Key? key,
    required this.product,
    required this.index,
  }) : super(key: key);
  final Groups? product;
  final int index;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: AppUtils.kBorderRadius12,
        color: AppColors.white,
      ),
      margin: AppUtils.kTopMargin12,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(
              top: 16,
              right: 12,
              left: 12,
              bottom: 12,
            ),
            child: Text(
              BaseFunctions.getTranslateLanguage(product?.title),
              style: styProfileAppBarTitles.copyWith(color: AppColors.black6),
            ),
          ),
          AppUtils.kDivider1,
          Padding(
            padding: AppUtils.kAllMargin16,
            child: Row(
              children: [
                const Icon(
                  Icons.check_circle,
                  size: 24,
                  color: AppColors.secondary,
                ),
                AppUtils.kBoxWidth10,
                Expanded(
                  child: Text(
                    BaseFunctions.getTranslateLanguage(
                        product?.variants?.first.title),
                    style: styProductDetailButton.copyWith(
                      color: AppColors.black,
                    ),
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                  ),
                ),
                Padding(
                  padding: AppUtils.kPaddingLeft16,
                  child: Text('x${product?.quantity ?? 0}'),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
