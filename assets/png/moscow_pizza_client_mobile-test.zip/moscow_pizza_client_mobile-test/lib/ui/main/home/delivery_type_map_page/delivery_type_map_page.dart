import 'package:moscow_pizza_client_mobile/controller/home/delivery_type_map_controller/delivery_typle_map_controller.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/delivery_type_map_page/widgets/delivery_type_map_body_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/map/map_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:yandex_mapkit/yandex_mapkit.dart';

class DeliveryTypeMapPage extends GetView<MapController> {
  const DeliveryTypeMapPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DeliveryTypeMapController>(
      builder: (ctr) {
        return AnnotatedRegion<SystemUiOverlayStyle>(
          value: const SystemUiOverlayStyle(
            statusBarColor: Colors.transparent,
          ),
          child: Scaffold(
            body: Obx(() {
              return ModalProgressHUD(
                inAsyncCall: ctr.isLoading.value,
                child: Stack(
                  children: [
                    Positioned.fill(
                      bottom: 300,
                      child: YandexMap(
                        mapObjects: ctr.mapObjects,
                        rotateGesturesEnabled: false,
                        tiltGesturesEnabled: false,
                        logoAlignment: const MapAlignment(
                          horizontal: HorizontalAlignment.center,
                          vertical: VerticalAlignment.top,
                        ),
                        onMapCreated: (yandexMapController) async {
                          ctr.setMapController(yandexMapController);
                          await ctr.getCurrentLocation();
                          await yandexMapController.toggleUserLayer(visible: false);
                        },
                        onMapTap: (point) async {
                          await ctr.setMapObject(point);
                          await ctr.getTheNearestBranches();
                        },
                        onCameraPositionChanged: (cameraPosition, _, finished) {
                          if (finished) {
                            ctr.setMapObject(cameraPosition.target);
                          }
                        },
                      ),
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: DeliveryTypeMapBodyWidget(),
                    ),
                  ],
                ),
              );
            }),
          ),
        );
      },
    );
  }
}
