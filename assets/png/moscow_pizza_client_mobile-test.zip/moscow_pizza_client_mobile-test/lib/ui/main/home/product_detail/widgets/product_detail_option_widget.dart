import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/product_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/radio_button_checked.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';

class ProductDetailOptionWidget extends StatelessWidget {
  const ProductDetailOptionWidget({
    Key? key,
    required this.properties,
    required this.indexProperty,
  }) : super(key: key);
  final Properties? properties;
  final int indexProperty;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) {
        return Container(
          padding: AppUtils.kHorizontal16Vertical12Padding,
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          margin: AppUtils.kTopMargin12,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                BaseFunctions.getTranslateLanguage(properties?.title),
                style: styProfileAppBarTitles.copyWith(color: AppColors.black6),
              ),
              ...List.generate(
                properties?.options?.length ?? 0,
                (index) {
                  bool isOptionSelected = false;
                  for (var element
                      in (ctr.productById?.variantProducts ?? [])) {
                    if (isOptionSelected) break;
                    element.productProperty?.forEach((element) {
                      if (isOptionSelected) return;
                      isOptionSelected =
                          element.optionId == properties?.options?[index].id;
                    });
                  }
                  if (isOptionSelected) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        InkWell(
                          highlightColor: AppColors.transparent,
                          onTap: () {
                            ctr
                              ..tabIndex(indexProperty, index)
                              ..choosingProductWithOption(indexProperty, index)
                              ..getOptionsList();
                            if (ctr.hasModifier) {
                              ctr.getProductModifierV2(ctr.productId);
                            }
                            ctr
                              ..priceOfSingleModifier = 0
                              ..priceOfGroupModifier = 0;
                          },
                          child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 16, 0, 16),
                            child: Row(
                              children: [
                                RadioButtonChecked(
                                  isChecked:
                                      (properties?.selectIndex ?? 0) == index,
                                ),
                                AppUtils.kBoxWidth8,
                                Text(
                                  BaseFunctions.getTranslateLanguage(
                                    properties?.options?[index].title,
                                  ),
                                  style: styProductDetailButton.copyWith(
                                    color: AppColors.black,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        if (index != (properties?.options?.length ?? 0) - 1)
                          AppUtils.kDivider1,
                      ],
                    );
                  }
                  return AppUtils.kBox;
                },
              ),
            ],
          ),
        );
      },
    );
  }
}
