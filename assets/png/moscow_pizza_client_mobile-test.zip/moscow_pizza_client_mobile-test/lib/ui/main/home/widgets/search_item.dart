import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';

import '../../../../data/models/products_v2_response.dart';

class SearchItem extends StatelessWidget {
  final Products? product;
  final Function()? onTap;

  const SearchItem({
    Key? key,
    this.product,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppUtils.kBottomPadding12,
      child: ClipRRect(
        borderRadius: AppUtils.kBorderRadius12,
        child: Material(
          color: AppColors.white,
          child: ListTile(
            onTap: onTap,
            contentPadding: const EdgeInsets.symmetric(
              vertical: 8,
              horizontal: 12,
            ),
            shape: const RoundedRectangleBorder(
              borderRadius: AppUtils.kBorderRadius12,
            ),
            leading: Container(
              height: 48,
              width: 48,
              decoration: BoxDecoration(
                borderRadius: AppUtils.kBorderRadius8,
                color: AppColors.white,
                border: Border.all(width: 0.5),
              ),
              child: ClipRRect(
                borderRadius: AppUtils.kBorderRadius8,
                child: CachedNetworkImage(
                  imageUrl: '${AppConstants.imageUrl}${product?.image}',
                  fit: BoxFit.cover,
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      const Center(child: CupertinoActivityIndicator()),
                  errorWidget: (context, url, error) =>
                      Image.asset('assets/png/place_holder.png'),
                ),
              ),
            ),
            title: Text(BaseFunctions.getTranslateLanguage(product?.title),
                style: stySearchItemTitle),
            trailing: Text(
              LocalSource.instance.locale == 'uz'
                  ? '${BaseFunctions.moneyFormat(
                      (product?.outPrice ?? 0).toDouble(),
                    )} ${'sum'.tr}${product?.type == 'origin' ? 'from'.tr : ''}'
                  : '${product?.type == 'origin' ? 'from'.tr : ''} ${BaseFunctions.moneyFormat(
                      (product?.outPrice ?? 0).toDouble(),
                    )} ${'sum'.tr}',
              style: stySearchItemPrice,
            ),
          ),
        ),
      ),
    );
  }
}
