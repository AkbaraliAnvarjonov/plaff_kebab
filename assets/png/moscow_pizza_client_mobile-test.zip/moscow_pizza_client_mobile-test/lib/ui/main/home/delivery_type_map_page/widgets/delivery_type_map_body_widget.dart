import 'package:moscow_pizza_client_mobile/controller/home/delivery_type_map_controller/delivery_typle_map_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/ui/main/basket/checkout_order/widgets/map_custom_button.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/delivery_type_map_page/widgets/delivery_type_mape_list_view_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/widgets/custom_tab_bar.dart';
import 'package:flutter/material.dart';

import '../../../../../base/base_controller.dart';
import '../../../../../core/custom_widgets/text_fields/always_disabled_focus_node.dart';
import '../../../../../core/custom_widgets/text_fields/custom_map_text_field.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_icons.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';

class DeliveryTypeMapBodyWidget extends StatelessWidget {
  final String? title;
  final GlobalKey<FormState> formKey = GlobalKey();

  DeliveryTypeMapBodyWidget({
    Key? key,
    this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<DeliveryTypeMapController>(
      builder: (ctr) {
        return Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            MapCustomButton(
              margin: const EdgeInsets.only(bottom: 16, right: 16),
              icon: AppIcons.map_pointer,
              onTap: () {
                ctr.findMyLocation();
              },
            ),
            DecoratedBox(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: AppUtils.kRadius12,
                  topRight: AppUtils.kRadius12,
                ),
                color: AppColors.white,
              ),
              child: SafeArea(
                top: false,
                minimum: AppUtils.kAllPadding12,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                         Expanded(
                          child: Text('select_the_receipt_method'.tr,
                              style: styMapTitle),
                        ),
                        IconButton(
                          icon: const Icon(Icons.clear, size: 28),
                          onPressed: Get.back,
                        )
                      ],
                    ),
                    Text('to_see_actual_menu'.tr),
                    AppUtils.kBoxHeight16,
                    CustomTabBar(
                      padding: AppUtils.kAllPadding0,
                      controller: ctr.tabController,
                      labels: ['delivery'.tr, 'self_pick_up'.tr],
                      onTap: (index) {
                        ctr.setDeliveryType(DeliveryType.values[index]);
                      },
                    ),
                    AppUtils.kBoxHeight12,
                    if (ctr.deliveryType == DeliveryType.delivery) ...[
                      CustomMapTextField(
                        suffixIcon: InkWell(
                          onTap: () {
                            ctr.clearPointedLocation();
                          },
                          child: const Icon(
                            Icons.close,
                          ),
                        ),
                        labelText: 'delivery_address'.tr,
                        hintTextStyle: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w400,
                          color: AppColors.darkGrey,
                        ),
                        hintText: 'please_select_delivery_address'.tr,
                        currentFocus: AlwaysDisabledFocusNode(),
                        controller: ctr.locationController,
                        errorText: 'choose_address'.tr,
                        showError: ctr.showLocationError ?? false,
                        keyboardType: TextInputType.text,
                        onTap: () async {},
                      ),
                      AppUtils.kBoxHeight16,
                    ],
                    if (ctr.deliveryType == DeliveryType.selfPickup)
                      ConstrainedBox(
                        constraints: BoxConstraints(
                          maxHeight: Get.height * 0.35,
                        ),
                        child: DeliveryTypeMapListViewWidget(
                          selectedBranch: ctr.selectedBranch,
                          branches: ctr.branches,
                          onTap: (index) async {
                            await ctr.setSelectedBranch(index);
                          },
                        ),
                      ),
                    AppUtils.kBoxHeight12,
                    SafeArea(
                      top: false,
                      child: CustomButton(
                        text: 'confirm'.tr,
                        onTap: () async {
                          await ctr.onConfirmButtonPressed();
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}
