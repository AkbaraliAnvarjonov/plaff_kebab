import 'package:moscow_pizza_client_mobile/ui/main/home/delivery_type_map_page/widgets/delivery_type_branch_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';

class DeliveryTypeMapListViewWidget extends StatelessWidget {
  final List<Branches> branches;
  final Function(int index) onTap;
  final Position? locationData;
  final Branches? selectedBranch;

  const DeliveryTypeMapListViewWidget({
    Key? key,
    this.branches = const [],
    required this.onTap,
    this.locationData,
    this.selectedBranch,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if (branches.isEmpty) return AppUtils.kBox;
    return ListView.separated(
      padding: AppUtils.kAllPadding0,
      itemCount: branches.length,
      itemBuilder: (_, index) {
        return DeliveryTypeBranchItemWidget(
          isSelected: selectedBranch == branches[index],
          branch: branches[index],
          onTap: () => onTap(index),
          locationData: locationData,
        );
      },
      separatorBuilder: (_, __) => AppUtils.kBoxHeight6,
    );
  }
}
