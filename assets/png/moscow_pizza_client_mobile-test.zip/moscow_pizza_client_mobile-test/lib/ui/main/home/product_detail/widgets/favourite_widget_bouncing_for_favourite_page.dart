import 'package:moscow_pizza_client_mobile/core/custom_widgets/bouncing_widget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';


class FavouriteWidgetBouncingForFavouritePage extends StatelessWidget {
  const FavouriteWidgetBouncingForFavouritePage({
    Key? key,
    required this.favorites,
    required this.index,
  }) : super(key: key);

  final List<Favourites>? favorites;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) => BouncingWidget(
        duration: const Duration(milliseconds: 100),
        scaleFactor: 1.5,
        onPressed: () async {
          if (favorites?[index].hasModifier ?? true) {
            await ctr.getProductDetailV2(favorites?[index].id ?? '');
            ctr.refreshPage();
          } else {
            await ctr.repository?.insertProduct(
              Products(
                id: favorites?[index].id ?? '',
                image: favorites?[index].image ?? '',
                name: favorites?[index].title?.parseTitle(),
                price: double.tryParse(
                    (favorites?[index].outPrice ?? 0.0).toString()) ??
                    0.0,
                quantity: 1,
                uniqueId: favorites?[index].id ?? '',
                modifiers: [],
              ),
            );
            Future.delayed(
              const Duration(milliseconds: 120),
                  () => ctr.changeSelected(
                index,
                true,
              ),
            );
          }
        },
        child: Container(
          margin: AppUtils.kAllPadding8,
          height: 36,
          decoration: const BoxDecoration(
            color: AppColors.white,
            borderRadius: AppUtils.kBorderRadius8,
            boxShadow: [
              BoxShadow(
                blurRadius: 10,
                color: Color.fromRGBO(0, 0, 0, 0.05),
              )
            ],
          ),
          child: Center(
            child: Text(
              "${favorites?[index].outPrice} ${"sum".tr}",
              style: styTabBarItemTitle,
            ),
          ),
        ),
      ),
    );
  }
}
