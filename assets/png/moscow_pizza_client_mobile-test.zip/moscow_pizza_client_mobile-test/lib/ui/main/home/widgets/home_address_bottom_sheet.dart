import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/bottom_sheet/bottom_sheet_addresses_item.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/bottom_sheet/custom_addresses_bottom_sheet.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';

import '../../../../core/theme/app_utils.dart';

class HomeAddressBottomSheet extends StatelessWidget {
  final List<CustomerAddresses> addresses;
  final Function()? onTap;
  final Function(int) onChanged;

  const HomeAddressBottomSheet({
    Key? key,
    required this.addresses,
    this.onTap,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomAddressesBottomSheet(
      onTap: onTap,
      child: ListView.separated(
        itemBuilder: (context, index) {
          return BottomSheetAddressesItem(
            onTap: () => onChanged(index),
            customerAddresses: addresses[index],
          );
        },
        physics: const BouncingScrollPhysics(),
        itemCount: addresses.length,
        shrinkWrap: true,
        padding: EdgeInsets.zero,
        separatorBuilder: (_, __) {
          return const Padding(
            padding: AppUtils.kRightPadding44,
            child: AppUtils.kDivider1,
          );
        },
      ),
    );
  }
}
