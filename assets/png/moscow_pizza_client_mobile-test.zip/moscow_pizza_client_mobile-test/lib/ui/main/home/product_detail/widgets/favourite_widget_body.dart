import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:moscow_pizza_client_mobile/routes/args/favourite_detail_page_arguments.dart';
import '../../../../../base/base_functions.dart';
import '../../../../../controller/home/product_detail_controller.dart';
import '../../../../../core/constants/constants.dart';
import '../../../../../core/keys/app_keys.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import '../../../../../data/models/product_by_id_response.dart';
import '../../../../../routes/app_pages.dart';
import 'favourite_widget_bouncing.dart';
import 'favourite_widget_without_bouncing.dart';

class FavouriteWidgetBody extends StatelessWidget {
  const FavouriteWidgetBody({
    Key? key,
    required this.favorites,
    required this.index,
  }) : super(key: key);

  final List<Favourites>? favorites;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) => Container(
        height: 240,
        width: 150,
        decoration: const BoxDecoration(borderRadius: AppUtils.kBorderRadius8),
        child: Material(
          color: AppColors.recommendBackground,
          borderRadius: AppUtils.kBorderRadius8,
          child: InkWell(
            borderRadius: AppUtils.kBorderRadius8,
            customBorder: const RoundedRectangleBorder(
              borderRadius: AppUtils.kBorderRadius8,
            ),
            onTap: () async {
              if (favorites?[index].hasModifier ?? true) {
                await Get.toNamed(
                  AppRoutes.favouritesDetail,
                  arguments: FavouriteDetailPageArguments(
                    product: ProductByIdResponse(
                      id: favorites?[index].id,
                      title: favorites?[index].title,
                      description: favorites?[index].description,
                      image: favorites?[index].image,
                    ),
                  ),
                );
              } else {
                if (favorites?[index].quantity == 1) {
                  await ctr.repository?.insertProduct(
                    Products(
                      id: favorites?[index].id ?? '',
                      image: favorites?[index].image ?? '',
                      name: favorites?[index].title?.parseTitle(),
                      price: double.tryParse(
                              ((favorites?[index].outPrice ?? 0.0) -
                                      (favorites?[index].discounts ?? 0))
                                  .toString()) ??
                          0.0,
                      quantity: 1,
                      uniqueId: favorites?[index].id ?? '',
                      modifiers: [],
                    ),
                  );
                }
                Future.delayed(
                  const Duration(milliseconds: 150),
                  () => ctr.changeSelected(
                    index,
                    true,
                  ),
                );
              }
            },
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: AppUtils.kBorderRadius8,
                  child: FadeInImage.assetNetwork(
                    imageCacheHeight: 108,
                    imageCacheWidth: 150,
                    height: 108,
                    image:
                        '${AppConstants.imageUrl}${favorites?[index].image ?? ''}',
                    fit: BoxFit.fill,
                    placeholder: 'assets/png/product_place_holder.png',
                    placeholderErrorBuilder: (_, __, ___) {
                      return const Center(
                        child: Image(
                          image: AssetImage(
                            'assets/png/product_place_holder.png',
                          ),
                        ),
                      );
                    },
                    imageErrorBuilder: (_, __, ___) {
                      return const Center(
                        child: Image(
                          image: AssetImage(
                            'assets/png/product_place_holder.png',
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        margin:
                            const EdgeInsets.only(left: 8, top: 8, right: 8),
                        child: Text(
                          BaseFunctions.getTranslateLanguage(
                              favorites?[index].title),
                          maxLines: 1,
                          style:
                              styProfileItemButtonText.copyWith(fontSize: 16),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.only(left: 8, right: 8),
                        child: Text(
                          BaseFunctions.getStringByLanguageDesc(
                              favorites?[index].description),
                          maxLines: 2,
                          style: styProductDetailDescription.copyWith(
                              fontSize: 14),
                        ),
                      ),
                      ValueListenableBuilder<Box<Products>>(
                        valueListenable:
                            Hive.box<Products>(AppKeys.productsHiveKey)
                                .listenable(),
                        builder: (_, snapshot, __) {
                          bool isBasket = false;
                          for (int i = 0; i < snapshot.length; i++) {
                            if (snapshot.getAt(i)?.uniqueId ==
                                favorites?[index].id) {
                              isBasket = true;
                              favorites?[index].quantity =
                                  snapshot.getAt(i)?.quantity ?? 1;
                            }
                          }
                          return isBasket
                              ? FavouriteWidgetWithoutBouncing(
                                  favorites: favorites,
                                  index: index,
                                )
                              : FavouriteWidgetBouncing(
                                  favorites: favorites,
                                  index: index,
                                );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
