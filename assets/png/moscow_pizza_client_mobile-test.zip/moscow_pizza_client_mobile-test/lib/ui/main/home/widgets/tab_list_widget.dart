import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class TabListWidget extends StatelessWidget {
  const TabListWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40,
      child: GetBuilder<HomeController>(
        builder: (controller) => ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: controller.categories.length,
          padding:AppUtils.kHorizontalPadding16,
          itemBuilder: (context, index) {
            var category = controller.categories[index];
            return RawMaterialButton(
              onPressed: () => controller.changeIsCheckedCategory(index),
              elevation: 0,
              padding:AppUtils.kHorizontalPadding8,
              fillColor: (category.isChecked ?? false)
                  ? AppColors.assets
                  : AppColors.grey300,
              shape: const RoundedRectangleBorder(
                borderRadius: AppUtils.kBorderRadius8,
              ),
              focusElevation: 0,
              highlightElevation: 0,
              child: Center(
                child: Text(
                  BaseFunctions.getTranslateLanguage(controller.categories[index].title),
                  semanticsLabel: controller.categories[index].id,
                  style: styTabBarItemTitle.copyWith(
                    color: (category.isChecked ?? false)
                        ? AppColors.white
                        : AppColors.black1,
                  ),
                ),
              ),
            );
          },
          separatorBuilder: (_,__)=>AppUtils.kBoxWidth8,
        ),
      ),
    );
  }
}
