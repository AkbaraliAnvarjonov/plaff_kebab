import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_circular_progress_indicator.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/banners_response.dart';

class BannerItem extends StatelessWidget {
  final Banners? banner;
  final Function()? onTap;

  const BannerItem({
    Key? key,
    this.banner,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final width = (Get.width - 44) / 1;
    return Container(
      width: width,
      height: width * 88 / 112,
      decoration: const BoxDecoration(
        borderRadius: AppUtils.kBorderRadius12,
        color: AppColors.white,
      ),
      margin: const EdgeInsets.only(right: 8),
      child: Stack(
        children: [
          Positioned.fill(
            child: ClipRRect(
              borderRadius: AppUtils.kBorderRadius12,
              child: Hero(
                tag: banner?.id ?? '',
                child: CachedNetworkImage(
                  imageUrl: banner?.image ?? '',
                  //'${AppConstants.imageUrl}${banner?.image ?? ''}' ,
                  fit: BoxFit.cover,
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      const Center(child: CustomCircularProgressIndicator()),
                  errorWidget: (context, url, error) => const Center(
                    child: Image(
                      image: AssetImage(
                        'assets/png/product_place_holder.png',
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
          Positioned.fill(
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: onTap,
                borderRadius: AppUtils.kBorderRadius12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
