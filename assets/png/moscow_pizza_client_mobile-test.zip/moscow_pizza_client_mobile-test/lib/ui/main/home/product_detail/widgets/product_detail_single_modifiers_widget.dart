import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/home/product_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/radio_button_checked.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_detail_single_modifier_pm_button.dart';

import '../../../../../core/theme/app_text_style.dart';

class ProductDetailSingleModifiersWidget extends StatelessWidget {
  final SingleModifiers? singleModifiers;
  final int? index;

  const ProductDetailSingleModifiersWidget({
    Key? key,
    required this.singleModifiers,
    this.index,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) {
        return Container(
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          margin: AppUtils.kTopMargin12,
          padding: AppUtils.kAllPadding16,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: AppUtils.kBottomMargin16,
                child: Text(
                  BaseFunctions.getStringSingleModifierName(
                    singleModifiers?.categoryName,
                  ),
                  style:
                      styProfileAppBarTitles.copyWith(color: AppColors.black6),
                ),
              ),
              InkWell(
                onTap: () {
                  if ((singleModifiers?.isCompulsory ?? false) == false) {
                    ctr.checkedSingleModifier(index ?? 0);
                  }
                },
                child: Row(
                  children: [
                    RadioButtonCheckChecked(
                      isChecked: singleModifiers?.isChecked ?? false,
                    ),
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.only(left: 10),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(
                              child: Text.rich(
                                TextSpan(
                                  text:
                                      BaseFunctions.getStringSingleModifierName(
                                    singleModifiers?.name,
                                  ),
                                  children: [
                                    (singleModifiers?.isCompulsory ?? false)
                                        ? const TextSpan(
                                            text: '*',
                                            style: TextStyle(
                                              color: AppColors.red,
                                            ),
                                          )
                                        : const TextSpan(text: ''),
                                  ],
                                ),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w400,
                                  fontSize: 15,
                                  color: Color.fromRGBO(20, 20, 20, 1),
                                ),
                                maxLines: 1,
                              ),
                            ),
                            Text(
                              ((singleModifiers?.price?.isNotEmpty ?? false) &&
                                      !(singleModifiers?.addToPrice ?? true))
                                  ? '+ ${singleModifiers?.price ?? 0}'
                                  : BaseFunctions.moneyFormatSymbol(0),
                              style: const TextStyle(
                                fontWeight: FontWeight.w400,
                                fontSize: 15,
                                color: Color.fromRGBO(133, 133, 133, 1),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              ProductDetailSingleModifierPMButton(
                index: index,
                singleModifiers: singleModifiers,
              ),
            ],
          ),
        );
      },
    );
  }
}
