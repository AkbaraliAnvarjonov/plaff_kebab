import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../controller/home/product_detail_controller.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';

class ProductDetailTitleDesc extends StatelessWidget {
  const ProductDetailTitleDesc({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) => Material(
        color: AppColors.white,
        borderRadius: AppUtils.kBorderBottomRadius12,
        child: Padding(
          padding: AppUtils.kPaddingHorizontal16,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                BaseFunctions.getTranslateLanguage(ctr.product.title),
                style: styProductDetailTitle,
              ),
              AppUtils.kBoxHeight12,
              Text(
                BaseFunctions.getStringByLanguageDesc(
                  ctr.product.description,
                ),
                style: styProductDetailDescription,
              ),
              AppUtils.kBoxHeight16,
            ],
          ),
        ),
      ),
    );
  }
}
