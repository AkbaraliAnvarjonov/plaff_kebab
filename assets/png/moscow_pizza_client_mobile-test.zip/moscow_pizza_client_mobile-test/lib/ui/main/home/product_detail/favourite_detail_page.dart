import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_combo_choice_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_detail_group_modifiers_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_detail_option_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_detail_single_modifiers_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/product_combo_basic_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_detail_banner.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_detail_bottom_navigation_bar.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_detail_title_desc.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/product_detail/widgets/favourite_widget_for_favourite_page.dart';
import '../../../../controller/home/favourite_detail_controller.dart';
import '../../../../core/custom_widgets/custom_circular_progress_indicator.dart';

class FavouriteDetailPage extends GetView<FavouriteDetailController> {
  const FavouriteDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    final size = MediaQuery.of(context).size;
    return Scaffold(
      body: GetBuilder<FavouriteDetailController>(
        builder: (ctr) => ListView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: EdgeInsets.zero,
          children: [
            FavouriteDetailBanner(size: size, top: top),
            const FavouriteDetailTitleDesc(),

            ...List.generate(ctr.products?.length ?? 0, (index) {
              return ctr.products?[index].type == 'combo_basic'
                  ? ProductComboBasicWidget(
                      product: ctr.products?[index],
                      index: index,
                    )
                  : FavouriteComboChoiceWidget(
                      product: ctr.products?[index],
                      index: index,
                    );
            }),

            //Options
            ...List.generate(
              controller.productById?.properties?.length ?? 0,
              (index) => FavouriteDetailOptionWidget(
                properties: controller.productById?.properties?[index],
                indexProperty: index,
              ),
            ),

            //Single Modifiers
            Visibility(
              visible:
                  ctr.singleModifiersLength > 0 && controller.hasModifier,
              child: ctr.isLoading.value
                  ? const Center(child: CustomCircularProgressIndicator())
                  : ListView.builder(
                      padding: EdgeInsets.zero,
                      itemCount: ctr.singleModifiersLength,
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        return FavouriteDetailSingleModifiersWidget(
                          index: index,
                          singleModifiers: controller
                              .productModifiers?.singleModifiers?[index],
                        );
                      },
                    ),
            ),

            //Group Modifiers
            Visibility(
              visible: ctr.groupModifiersLength > 0 && controller.hasModifier,
              child: ListView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: ctr.groupModifiersLength,
                itemBuilder: (context, index) {
                  return FavouriteDetailGroupModifiersWidget(
                    parentIndex: index,
                    groupModifiers:
                        controller.productModifiers?.groupModifiers?[index],
                  );
                },
              ),
            ),
            if (ctr.productById?.favorites?.isEmpty ?? false)
              AppUtils.kBoxHeight12,
            Visibility(
              visible: ctr.productById?.favorites?.isNotEmpty ?? false,
              child: FavouriteWidgetForFavouritePage(
                favorites: ctr.productById?.favorites,
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: const FavouriteDetailBottomNavigationBar(),
    );
  }
}
