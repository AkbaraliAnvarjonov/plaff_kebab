import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import '../../../../../base/base_functions.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';


class FavouriteDetailTitleDesc extends StatelessWidget {
  const FavouriteDetailTitleDesc({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) => Material(
        color: AppColors.white,
        borderRadius: AppUtils.kBorderBottomRadius12,
        child: Padding(
          padding: AppUtils.kPaddingHorizontal16,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                BaseFunctions.getTranslateLanguage(ctr.product.title),
                style: styProductDetailTitle,
              ),
              AppUtils.kBoxHeight12,
              Text(
                BaseFunctions.getStringByLanguageDesc(ctr.product.description),
                style: styProductDetailDescription,
              ),
              AppUtils.kBoxHeight16,
            ],
          ),
        ),
      ),
    );
  }
}
