import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/main/main_controller.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/routes/args/product_detail_page_arguments.dart';

import '../../../../data/data_sources/local/local_source.dart';
import '../../../../data/models/category_v2_response.dart' as cr;
import '../../../../data/models/product_by_id_response.dart';

class ProductItem extends StatelessWidget {
  const ProductItem({
    Key? key,
    this.product,
    this.isInStopList = false,
    this.isDeliveryTypeSelected = true,
  }) : super(key: key);
  final cr.Products1? product;
  final bool isInStopList;
  final bool isDeliveryTypeSelected;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      highlightColor: isInStopList ? AppColors.transparent : null,
      splashColor: isInStopList ? AppColors.transparent : null,
      borderRadius: AppUtils.kBorderRadius8,
      onTap: () async {
        if (isInStopList) {
          return;
        }
        if (!isDeliveryTypeSelected) {
          await Get.toNamed(AppRoutes.deliveryTypeMap);
          return;
        }
        final result = await Get.toNamed(
          AppRoutes.productDetail,
          arguments: ProductDetailPageArguments(
            product: ProductByIdResponse(
              discounts: product?.discounts,
              type: product?.type,
              id: product?.id,
              image: product?.image,
              title: product?.title,
              description: product?.description,
            ),
          ),
        );
        if (result != null) {
          await Get.find<MainController>().changeTabIndex(1);
        }
      },
      child: Stack(
        children: [
          Semantics(
            label: product?.id,
            child: Container(
              padding: AppUtils.kAllPadding16,
              width: Get.width,
              height: 120,
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          BaseFunctions.getTranslateLanguage(
                            product?.title,
                          ),
                          style: styProductTitle,
                          maxLines: 1,
                          textAlign: TextAlign.start,
                          overflow: TextOverflow.ellipsis,
                          semanticsLabel: '',
                        ),
                        Expanded(
                          child: SizedBox(
                            child: Text(
                              BaseFunctions.getStringByLanguageDesc(
                                product?.description,
                              ),
                              style: styProductDescription.copyWith(
                                color: AppColors.black3,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              semanticsLabel: '',
                            ),
                          ),
                        ),
                        if (product?.discounts != 0)
                          Text(
                            BaseFunctions.moneyFormatSymbol(
                              (product?.outPrice ?? 0).toDouble() +
                                  (product?.discounts ?? 0).toDouble(),
                            ),
                          ),
                        Row(
                          children: [
                            Text(
                              product?.type == 'origin'
                                  ? LocalSource.instance.locale == 'uz'
                                      ? '${BaseFunctions.moneyFormatSymbol(
                                          (product?.outPrice ?? 0).toDouble(),
                                        )}${'from'.tr}'
                                      : '${'from'.tr} ${BaseFunctions.moneyFormatSymbol(
                                          (product?.outPrice ?? 0).toDouble(),
                                        )}'
                                  : BaseFunctions.moneyFormatSymbol(
                                      (product?.outPrice ?? 0).toDouble(),
                                    ),
                              style: styBasketButtonTitle.copyWith(
                                decoration: product?.discounts != 0
                                    ? TextDecoration.lineThrough
                                    : null,
                                color: AppColors.assets,
                              ),
                              semanticsLabel: '',
                            ),
                            AppUtils.kBoxWidth8,
                            if (isInStopList)
                              const Text(
                                'Недоступно',
                                style: AppTextStyles.unAvailableText,
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    width: 88,
                    height: 88,
                    child: ClipRRect(
                      borderRadius: AppUtils.kBorderRadius8,
                      child: CachedNetworkImage(
                        fit: BoxFit.cover,
                        imageUrl: '${AppConstants.imageUrl}${product?.image}',
                        placeholder: (_, __) {
                          return const Center(
                            child: Image(
                              image: AssetImage(
                                'assets/png/product_place_holder.png',
                              ),
                              semanticLabel: '',
                            ),
                          );
                        },
                        errorWidget: (_, __, ___) {
                          return const Center(
                            child: Image(
                              image: AssetImage(
                                'assets/png/product_place_holder.png',
                              ),
                              semanticLabel: '',
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (isInStopList)
            Container(
              width: Get.width,
              height: 120,
              decoration: BoxDecoration(
                color: AppColors.white.withOpacity(
                  0.6,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
