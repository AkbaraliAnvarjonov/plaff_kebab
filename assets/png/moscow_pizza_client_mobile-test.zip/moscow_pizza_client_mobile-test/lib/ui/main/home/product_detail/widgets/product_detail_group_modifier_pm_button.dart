import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/product_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../core/custom_widgets/plus_minus_button.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';

class ProductDetailGroupModifierPMButton extends StatelessWidget {
  final Variants? variants;
  final int? parentIndex;
  final int? index;

  const ProductDetailGroupModifierPMButton(
      {Key? key, required this.variants, required this.index, required this.parentIndex})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProductDetailController>(
      builder: (ctr) {
        if (variants?.isChecked ?? false) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                margin:AppUtils.kTopMargin12,
                padding:
                const EdgeInsets.only(left: 6, top: 5, right: 6, bottom: 5),
                decoration: BoxDecoration(
                  color: AppColors.white,
                  borderRadius: AppUtils.kBorderRadius8,
                  border: Border.all(
                    color: AppColors.inactive,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    PlusMinusButton(
                      onTap: () {
                        ctr..decrementGroupModifier(parentIndex ?? 0, index ?? 0)
                        ..limitedGroupModifiers(parentIndex?? 0,index ?? 0);
                      },
                      size: 24,
                      isMinus: true,
                      borderRadius: AppUtils.kBorderRadius4,
                    ),
                    Padding(
                      padding: AppUtils.kHorizontalPadding12,
                      child: Text(
                        BaseFunctions.moneyFormat(variants?.quantity ?? 0),
                        style: styProductDetailQuantity,
                      ),
                    ),
                    PlusMinusButton(
                      onTap: () {
                        ctr..incrementGroupModifier(parentIndex ?? 0, index ?? 0)
                        ..limitedGroupModifiers(parentIndex?? 0, index ?? 0);
                      },
                      size: 24,
                      borderRadius:AppUtils.kBorderRadius4,
                    ),
                  ],
                ),
              ),
            ],
          );
        } else {
          return AppUtils.kBox;
        }
      },
    );
  }
}
