import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:moscow_pizza_client_mobile/controller/home/favourite_detail_controller.dart';
import '../../../../../base/base_functions.dart';
import '../../../../../core/constants/constants.dart';
import '../../../../../core/keys/app_keys.dart';
import '../../../../../core/theme/app_colors.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../../../../core/theme/app_utils.dart';
import '../../../../../data/hive/products.dart';
import '../../../../../data/models/product_by_id_response.dart';
import 'favourite_widget_bouncing_for_favourite_page.dart';
import 'favourite_widget_without_bouncing_for_favourite_page.dart';

class FavouriteWidgetBodyForFavouritePage extends StatelessWidget {
  const FavouriteWidgetBodyForFavouritePage({
    Key? key,
    required this.favorites,
    required this.index,
  }) : super(key: key);

  final List<Favourites>? favorites;
  final int index;

  @override
  Widget build(BuildContext context) {
    return GetBuilder<FavouriteDetailController>(
      builder: (ctr) => Container(
        height: 224,
        width: 148,
        decoration: const BoxDecoration(borderRadius: AppUtils.kBorderRadius8),
        child: Material(
          color: AppColors.recommendBackground,
          borderRadius: AppUtils.kBorderRadius8,
          child: InkWell(
            borderRadius: AppUtils.kBorderRadius8,
            customBorder: const RoundedRectangleBorder(
              borderRadius: AppUtils.kBorderRadius8,
            ),
            onTap: () async {
              if (favorites?[index].hasModifier ?? true) {
                await ctr.getProductDetailV2(favorites?[index].id ?? '');
                ctr.refreshPage();
              } else {
                if(favorites?[index].quantity == 1){
                  await ctr.repository?.insertProduct(
                    Products(
                      id: favorites?[index].id ?? '',
                      image: favorites?[index].image ?? '',
                      name: favorites?[index].title?.parseTitle(),
                      price: double.tryParse(
                              (favorites?[index].outPrice ?? 0.0).toString()) ??
                          0.0,
                      quantity: 1,
                      uniqueId: favorites?[index].id ?? '',
                      modifiers: [],
                    ),
                  );
                }
                Future.delayed(
                  const Duration(milliseconds: 150),
                  () => ctr.changeSelected(
                    index,
                    true,
                  ),
                );
              }
            },
            child: Column(
              children: [
                ClipRRect(
                  borderRadius: AppUtils.kBorderRadius8,
                  child: FadeInImage.assetNetwork(
                    imageCacheHeight: 114,
                    imageCacheWidth: 148,
                    height: 114,
                    image:
                        '${AppConstants.imageUrl}${favorites?[index].image ?? ''}',
                    fit: BoxFit.fill,
                    placeholder: 'assets/png/product_place_holder.png',
                    placeholderErrorBuilder: (_, __, ___) {
                      return const Center(
                        child: Image(
                          image: AssetImage(
                            'assets/png/product_place_holder.png',
                          ),
                        ),
                      );
                    },
                    imageErrorBuilder: (_, __, ___) {
                      return const Center(
                        child: Image(
                          image: AssetImage(
                            'assets/png/product_place_holder.png',
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        margin: AppUtils.kAllPadding8,
                        child: Text(
                          BaseFunctions.getTranslateLanguage(
                              favorites?[index].title),
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          style: styProfileAboutServiceText.copyWith(
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                      ValueListenableBuilder<Box<Products>>(
                        valueListenable:
                            Hive.box<Products>(AppKeys.productsHiveKey).listenable(),
                        builder: (_, snapshot, __) {
                          bool isBasket = false;
                          for (int i = 0; i < snapshot.length; i++) {
                            if (snapshot.getAt(i)?.uniqueId ==
                                favorites?[index].id) {
                              isBasket = true;
                              favorites?[index].quantity =
                                  snapshot.getAt(i)?.quantity ?? 1;
                            }
                          }
                          return isBasket
                              ? FavouriteWidgetWithoutBouncingForFavouritePage(
                                  favorites: favorites, index: index)
                              : FavouriteWidgetBouncingForFavouritePage(
                                  favorites: favorites, index: index);
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
