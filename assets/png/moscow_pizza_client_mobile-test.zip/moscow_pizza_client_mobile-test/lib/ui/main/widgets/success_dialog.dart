import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

import '../../../core/theme/app_utils.dart';

class SuccessDialog extends StatefulWidget {
  const SuccessDialog({Key? key}) : super(key: key);

  @override
  SuccessDialogState createState() => SuccessDialogState();
}

class SuccessDialogState extends State<SuccessDialog> {
  @override
  void initState() {
    super.initState();
    Future.delayed(
      const Duration(seconds: 2),
      Get.back,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: AppUtils.kBorderRadius16,
      ),
      child: Container(
        width: MediaQuery.of(context).size.width,
        padding: AppUtils.kAllPadding24,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 96,
              width: 96,
              padding: AppUtils.kAllPadding8,
              decoration: const BoxDecoration(
                color: AppColors.green,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.check_rounded,
                color: AppColors.white,
                size: 72,
              ),
            ),
            AppUtils.kBoxHeight24,
            Text(
              'your_review_been_accepted'.tr,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: AppColors.black,
                fontWeight: FontWeight.w400,
                fontSize: 24,
              ),
            ),
            AppUtils.kBoxHeight24,
          ],
        ),
      ),
    );
  }
}
