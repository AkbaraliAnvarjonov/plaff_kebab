import 'package:flutter/material.dart';
import 'package:hive_flutter/adapters.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import '../../../core/keys/app_keys.dart';
import '../../../data/hive/products.dart';

class CountNavigationBarItem extends StatelessWidget {
  final Widget icon;

  const CountNavigationBarItem({
    Key? key,
    required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<Box<Products>>(
      valueListenable: Hive.box<Products>(AppKeys.productsHiveKey).listenable(),
      builder: (_, snapshot, __) {
        List<Products> ls = [];
        if (snapshot.values.toList().isNotEmpty) {
          ls = snapshot.values.toList();
        }
        return Badge(
          backgroundColor: AppColors.red,
          isLabelVisible: ls.isNotEmpty,
          label: Text(
            ls.length.toString(),
            style: AppTextStyles.badge,
            semanticsLabel: '',
          ),
          child: icon,
        );
      },
    );
  }
}
