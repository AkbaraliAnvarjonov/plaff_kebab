import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import '../../../data/hive/products.dart' as basket_products;

import 'sum_item_widget.dart';

class SumWidget extends StatelessWidget {
  final num generalSum;
  final List<basket_products.Products> listOfBasketProducts;
  final List<String> listOfStopListIds;
  final bool isDelivery;
  final bool isCheckout;
  final String orderStatus;
  final num deliveryPrice;
  final List<String> discountNames;
  final num? sum;
  final num? sumDiscount;

  const SumWidget({
    Key? key,
    this.sum,
    this.sumDiscount,
    this.deliveryPrice = AppConstants.deliveryPrice,
    this.listOfStopListIds = const [],
    this.generalSum = 0,
    this.listOfBasketProducts = const [],
    this.isDelivery = false,
    this.isCheckout = false,
    this.orderStatus = '',
    this.discountNames = const [],
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppUtils.kAllPadding10,
      decoration: const BoxDecoration(
        borderRadius: AppUtils.kBorderRadius12,
        color: AppColors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'check'.tr,
            style: AppTextStyles.blackBoldText15,
          ),
          AppUtils.kBoxHeight16,
          ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: listOfBasketProducts.isNotEmpty
                ? listOfBasketProducts.length
                : 0,
            itemBuilder: (context, index) {
              return SumItemWidget(
                isInStopList:
                    listOfStopListIds.contains(listOfBasketProducts[index].id),
                product: listOfBasketProducts[index],
                countText:
                    '${BaseFunctions.moneyFormat(listOfBasketProducts[index].quantity)} x ',
                name: BaseFunctions.getTransLanguage(
                    listOfBasketProducts[index].name),
                discountSum:
                    '${BaseFunctions.moneyFormat(listOfBasketProducts[index].price + listOfBasketProducts[index].discounts)} ${'sum'.tr}',
              );
            },
            separatorBuilder: (context, index) => const Padding(
              padding: AppUtils.kBottomPadding6,
              child: AppUtils.kDivider1,
            ),
          ),
          Visibility(
            visible: orderStatus.isNotEmpty,
            child: SumItemWidget(
              name: 'status'.tr,
              discountSum: orderStatus == 'canceled'.tr
                  ? 'canceled'.tr
                  : 'successfully'.tr,
              sumStyle: TextStyle(
                color: orderStatus == 'canceled'.tr
                    ? AppColors.red
                    : AppColors.green,
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
          AppUtils.kBoxHeight12,
          isDelivery
              ? SumItemWidget(
                  name: 'shipping_amount'.tr,
                  discountSum:
                      '${BaseFunctions.moneyFormat(deliveryPrice)} ${'sum'.tr}',
                )
              : AppUtils.kBox,
          // AppUtils.kBoxHeight8,
          if (discountNames.isNotEmpty) ...[
            ...List.generate(
              discountNames.length,
              (index) => SumItemWidget(
                name: '',
                discountSum: discountNames[index],
              ),
            ),
            // AppUtils.kBoxHeight6,
          ],
          SumItemWidget(
            name: 'total_amount'.tr,
            nameStyle: AppTextStyles.blackBoldText17,
            discountSum: '${BaseFunctions.moneyFormat(generalSum + deliveryPrice)} ${'sum'.tr}',
            sumStyle: AppTextStyles.blackBoldText17,
            sum: sum?.toInt().toString(),
            sumDiscount: (sumDiscount ?? 0) > 0 && sumDiscount != sum
                ? BaseFunctions.moneyFormat(sumDiscount!)
                : null,
          ),
        ],
      ),
    );
  }
}
