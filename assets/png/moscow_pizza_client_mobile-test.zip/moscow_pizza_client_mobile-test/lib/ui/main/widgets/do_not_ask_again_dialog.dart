import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';

class DoNotAskAgainDialog extends StatefulWidget {
  final String title, subTitle, positiveButtonText, negativeButtonText;
  final Function onPositiveButtonClicked;
  final String doNotAskAgainText;
  final String dialogKeyName;

  const DoNotAskAgainDialog(
    this.dialogKeyName,
    this.title,
    this.subTitle,
    this.positiveButtonText,
    this.negativeButtonText,
    this.onPositiveButtonClicked, {
    Key? key,
    this.doNotAskAgainText = 'Never ask again',
  }) : super(key: key);

  @override
  DoNotAskAgainDialogState createState() => DoNotAskAgainDialogState();
}

class DoNotAskAgainDialogState extends State<DoNotAskAgainDialog> {
  bool doNotAskAgain = false;

  Future<void> _updateDoNotShowAgain() async {
    final sharedPreferences = LocalSource.instance;
    await sharedPreferences.setUpdateDialog(false);
  }

  @override
  Widget build(BuildContext context) {
    if (Platform.isIOS) {
      return CupertinoAlertDialog(
        title: Text(widget.title, style: styAppBarTitle),
        content: Text(widget.subTitle, style: styAppBarTitle),
        actions: <Widget>[
          CupertinoDialogAction(
            child: Text(
              widget.positiveButtonText,
              style: styAppBarTitle.copyWith(
                fontSize: 17,
                color: AppColors.assets,
              ),
            ),
            onPressed: () {
              widget.onPositiveButtonClicked();
            },
          ),
          CupertinoDialogAction(
            child: Text(
              widget.doNotAskAgainText,
              style: styAppBarTitle.copyWith(
                fontSize: 17,
              ),
            ),
            onPressed: () {
              Navigator.pop(context);
              _updateDoNotShowAgain();
            },
          ),
          CupertinoDialogAction(
            child: Text(
              widget.negativeButtonText,
              style: styAppBarTitle,
            ),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      );
    }
    return AlertDialog(
      backgroundColor: AppColors.assets,
      title: Text(
        '${widget.title} ${widget.subTitle}',
        style: styAppBarTitle.copyWith(
            fontWeight: FontWeight.w600, fontSize: 17, color: AppColors.white),
      ),
      shape: const RoundedRectangleBorder(
        borderRadius: AppUtils.kBorderRadius8,
      ),
      content: FittedBox(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              children: <Widget>[
                SizedBox(
                  width: 24,
                  height: 24,
                  child: Checkbox(
                    activeColor: AppColors.assets,
                    value: doNotAskAgain,
                    onChanged: (val) {
                      setState(() {
                        doNotAskAgain = val ?? false;
                      });
                    },
                  ),
                ),
                AppUtils.kBoxWidth8,
                GestureDetector(
                  onTap: () {
                    setState(() {
                      doNotAskAgain = doNotAskAgain == false;
                    });
                  },
                  child: Text(
                    widget.doNotAskAgainText,
                    style: styAppBarTitle.copyWith(
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        color: AppColors.white),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
      actions: <Widget>[
        MaterialButton(
          child: Text(
            widget.positiveButtonText,
            style: styAppBarTitle.copyWith(
                fontWeight: FontWeight.w500, color: AppColors.blue),
          ),
          onPressed: () {
            if (doNotAskAgain) {
              widget.onPositiveButtonClicked();
            }
          },
        ),
        MaterialButton(
          child: Text(
            widget.negativeButtonText,
            style: styAppBarTitle.copyWith(
                fontWeight: FontWeight.w500, color: AppColors.white),
          ),
          onPressed: () async {
            Navigator.pop(context);
            if (doNotAskAgain) {
              await _updateDoNotShowAgain();
            }
          },
        ),
      ],
    );
  }
}
