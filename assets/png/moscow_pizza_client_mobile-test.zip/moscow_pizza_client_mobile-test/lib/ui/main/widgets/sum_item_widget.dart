import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import '../../../data/hive/products.dart';

class SumItemWidget extends StatelessWidget {
  final String? name;
  final String discountSum;
  final String countText;
  final TextStyle nameStyle;
  final TextStyle sumStyle;
  final Products? product;
  final bool isInStopList;
  final String? sum;
  final String? sumDiscount;

  const SumItemWidget({
    Key? key,
    this.name,
    this.isInStopList = false,
    required this.discountSum,
    this.countText = '',
    this.nameStyle = AppTextStyles.greyText15,
    this.sumStyle = AppTextStyles.greyBoldText15,
    this.product,
    this.sum,
    this.sumDiscount,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(child: Text(name.toString(), style: nameStyle)),
            RichText(
              text: TextSpan(
                style: sumStyle,
                children: [
                  if (sum != null && sumDiscount != null) ...[
                    TextSpan(
                      text: '$sumDiscount  ',
                      style: AppTextStyles.greyText15
                          .copyWith(color: AppColors.black),
                    ),
                    TextSpan(
                      text: sum,
                      style: AppTextStyles.greyText15.copyWith(
                        decoration: TextDecoration.lineThrough,
                      ),
                    ),
                    TextSpan(
                      text: ' ${'sum'.tr}',
                      style: AppTextStyles.greyText15,
                    ),
                  ] else ...[
                    TextSpan(
                      text: countText,
                      style: AppTextStyles.greyText15,
                    ),
                    TextSpan(
                      text: discountSum,
                      style: AppTextStyles.greyText15,
                    ),
                  ]
                ],
              ),
            ),
            // Text(sum, style: sumStyle),
          ],
        ),
        Visibility(
          visible: product?.combos?.isNotEmpty ?? false,
          child: ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: product?.combos?.length ?? 0,
            itemBuilder: (ctx, i) {
              return Padding(
                padding: const EdgeInsets.only(left: 12, bottom: 12),
                child: RichText(
                  text: TextSpan(
                      text: BaseFunctions.getTransLanguage(
                          product?.combos?[i].variantName ?? ''),
                      style: AppTextStyles.greyText15),
                ),
              );
            },
          ),
        ),
        Visibility(
          visible: product?.modifiers?.isNotEmpty ?? true,
          child: Column(
            children: [
              AppUtils.kBoxHeight12,
              ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                itemCount: product?.modifiers?.length ?? 0,
                itemBuilder: (ctx, i) {
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        BaseFunctions.getTransLanguage(
                            product?.modifiers?[i].modifierName ?? ''),
                        style: AppTextStyles.greyText15,
                      ),
                      RichText(
                        text: TextSpan(
                          // text: BaseFunctions.getTransLanguage(
                          //     product?.modifiers?[i].modifierName ?? ''),
                          style: AppTextStyles.greyText15,
                          children: [
                            TextSpan(
                                text:
                                    '${product?.modifiers?[i].modifierQuantity.toString() ?? ''} x ',
                                style: AppTextStyles.greyText15),
                            TextSpan(
                                text:
                                    '${(product?.modifiers?[i].addModifierPrice ?? true) ? '0' : (product?.modifiers?[i].modifiersPrice ?? '0')} ${'sum'.tr}',
                                style: AppTextStyles.greyText15),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ],
          ),
        ),
        if (isInStopList) ...[
          AppUtils.kBoxHeight2,
          Text(
            'product_is_not_available_in_branch'.tr,
            style: AppTextStyles.redText13,
          ),
        ],
        AppUtils.kBoxHeight6,
      ],
    );
  }
}
