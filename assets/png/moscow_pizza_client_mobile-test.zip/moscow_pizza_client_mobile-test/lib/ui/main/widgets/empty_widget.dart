import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class EmptyWidget extends StatelessWidget {
  final String text;
  final bool value;

  const EmptyWidget({
    Key? key,
    required this.text,
    this.value = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        SizedBox(height: size.height / 5),
        const Center(
          child: Image(
            image: AssetImage('assets/png/is_empty.png'),
            height: 120,
            width: 120,
          ),
        ),
        AppUtils.kBoxHeight16,
        Text(
          text,
          textAlign: TextAlign.center,
          style: stySearchNotFound,
        ),
      ],
    );
  }
}
