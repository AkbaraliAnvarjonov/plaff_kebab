import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/controller/main/main_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/ui/main/home/home_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/main_my_orders_page.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/profile_page.dart';
import 'package:get/get.dart';
import '../../core/theme/app_utils.dart';
import 'basket/basket_page.dart';
import 'widgets/count_navigation_bar_item.dart';

class MainPage extends GetView<MainController> {
  const MainPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int tabIndex = 0;
    if (Get.arguments is int) tabIndex = Get.arguments as int;
    return GetBuilder<MainController>(
      initState: (state) async {
        controller.setDefaultTabIndex(tabIndex);
      },
      builder: (ctr) {
        return WillPopScope(
          onWillPop: () async {
            if (ctr.tabMenu != BottomMenu.home) {
              await ctr.changeTabIndex(0);
              return false;
            }
            return true;
          },
          child: Scaffold(
            body: IndexedStack(
              index: ctr.tabMenu.index,
              children: const [
                HomePage(),
                BasketPage(),
                MyOrdersPage(),
                ProfilePage(),
              ],
            ),
            bottomNavigationBar: BottomNavigationBar(
              onTap: ctr.changeTabIndex,
              currentIndex: ctr.tabMenu.index,
              items: [
                _bottomNavigationBarItem(
                  icon: AppIcons.home,
                  label: 'home'.tr,
                ),
                _bottomNavigationBarItemCount(
                  label: 'basket'.tr,
                ),
                _bottomNavigationBarItem(
                  icon: AppIcons.shopping_bag,
                  label: 'my_orders'.tr,
                ),
                _bottomNavigationBarItem(
                  icon: AppIcons.user,
                  label: 'profile'.tr,
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  BottomNavigationBarItem _bottomNavigationBarItem({
    required IconData icon,
    required String label,
  }) {
    return BottomNavigationBarItem(
      icon: Padding(
        padding: AppUtils.kBottomMargin4,
        child: Icon(
          icon,
          color: AppColors.black5,
          semanticLabel: '',
        ),
      ),
      activeIcon: Padding(
        padding: AppUtils.kBottomMargin4,
        child: Icon(
          icon,
          color: AppColors.assets,
          semanticLabel: '',
        ),
      ),
      label: label,
    );
  }

  BottomNavigationBarItem _bottomNavigationBarItemCount({
    required String label,
  }) {
    return BottomNavigationBarItem(
      icon: const Padding(
        padding: AppUtils.kBottomMargin4,
        child: CountNavigationBarItem(
          icon: Icon(
            AppIcons.shopping_cart,
            color: AppColors.black5,
            semanticLabel: '',
          ),
        ),
      ),
      activeIcon: const Padding(
        padding: AppUtils.kBottomMargin4,
        child: CountNavigationBarItem(
          icon: Icon(
            AppIcons.shopping_cart,
            color: AppColors.assets,
            semanticLabel: '',
          ),
        ),
      ),
      label: label,
    );
  }
}
