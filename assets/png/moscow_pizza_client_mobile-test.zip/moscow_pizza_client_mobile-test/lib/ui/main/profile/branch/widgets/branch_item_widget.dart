import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/image_network/custom_image_network.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';

class BranchItemWidget extends StatelessWidget {
  final Function()? onTap;
  final Branches branch;
  final bool isLast;
  final bool isFirst;

  const BranchItemWidget({
    Key? key,
    this.onTap,
    required this.branch,
    this.isLast = false,
    this.isFirst = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white,
      borderRadius: BorderRadius.only(
        topLeft: isFirst ? AppUtils.kRadius12 : Radius.zero,
        topRight: isFirst ? AppUtils.kRadius12 : Radius.zero,
        bottomLeft: isLast ? AppUtils.kRadius12 : Radius.zero,
        bottomRight: isLast ? AppUtils.kRadius12 : Radius.zero,
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.only(
          topLeft: isFirst ? AppUtils.kRadius12 : Radius.zero,
          topRight: isFirst ? AppUtils.kRadius12 : Radius.zero,
          bottomLeft: isLast ? AppUtils.kRadius12 : Radius.zero,
          bottomRight: isLast ? AppUtils.kRadius12 : Radius.zero,
        ),
        child: Semantics(
          label: branch.id,
          child: Ink(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.only(
                topLeft: isFirst ? AppUtils.kRadius12 : Radius.zero,
                topRight: isFirst ? AppUtils.kRadius12 : Radius.zero,
                bottomLeft: isLast ? AppUtils.kRadius12 : Radius.zero,
                bottomRight: isLast ? AppUtils.kRadius12 : Radius.zero,
              ),
              color: AppColors.white,
            ),
            child: Padding(
              padding: AppUtils.kAllPadding16,
              child: Row(
                children: [
                  CustomImageNetwork(
                    height: 56,
                    width: 56,
                    borderRadius: AppUtils.kBorderRadius8,
                    url: branch.image ?? '',
                    fit: BoxFit.cover,
                  ),
                  AppUtils.kBoxWidth16,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          branch.name.toString(),
                          style: AppTextStyles.blackText15,
                          maxLines: 1,
                          semanticsLabel: '',
                        ),
                        AppUtils.kBoxHeight4,
                        Text(
                          branch.destination.toString(),
                          style: AppTextStyles.greyText15,
                          maxLines: 2,
                          semanticsLabel: '',
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.black5,
                    semanticLabel: '',
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
