import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_about_service_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';

import '../../../../core/theme/app_colors.dart';
import 'widgets/about_service_item.dart';

class ProfileAboutServicePage extends GetView<ProfileAboutServiceController> {
  const ProfileAboutServicePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('about_service'.tr)),
      body: Padding(
        padding: AppUtils.kAllPadding12,
        child: ClipRRect(
          borderRadius: AppUtils.kBorderRadius12,
          child: Material(
            color: AppColors.white,
            child: AboutServiceItem(
              padding: const EdgeInsets.only(left: 12),
              text: 'about_us'.tr,
              onTap: () {
                Get.toNamed(AppRoutes.profileCondensationPolicy);
              },
            ),
          ),
        ),
      ),
    );
  }
}
