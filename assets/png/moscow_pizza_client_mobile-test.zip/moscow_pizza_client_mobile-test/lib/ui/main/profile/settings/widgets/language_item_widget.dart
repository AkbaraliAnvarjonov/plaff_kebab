import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class LanguageItemWidget extends StatelessWidget {
  final Function()? onTap;
  final String text;
  final bool check;
  final String assets;

  const LanguageItemWidget({
    Key? key,
    required this.text,
    this.check = false,
    required this.assets,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      child: InkWell(
        onTap: onTap,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Ink(
              width: 56,
              height: 56,
              padding: AppUtils.kAllPadding12,
              child: Image.asset(
                'assets/png/$assets.png',
                semanticLabel: '',
              ),
            ),
            Text(text, style: styProfileBottomSheetItemLang),
            const Spacer(),
            Visibility(
              visible: check,
              child: const Padding(
                padding: AppUtils.kAllPadding16,
                child: Icon(
                  Icons.check_rounded,
                  color: AppColors.assets,
                  size: 24,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
