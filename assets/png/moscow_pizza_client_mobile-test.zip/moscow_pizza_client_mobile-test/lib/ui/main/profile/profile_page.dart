import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/widgets/profile_item_button.dart';

class ProfilePage extends GetView<ProfileController> {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileController>(
      builder: (ctr) {
        return Scaffold(
          appBar: AppBar(
            centerTitle: true,
            title: Text('profile'.tr),
          ),
          body: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              AppUtils.kBoxHeight16,
              Material(
                color: AppColors.white,
                shape: const RoundedRectangleBorder(
                  borderRadius: AppUtils.kBorderRadius12,
                ),
                child: Padding(
                  padding: AppUtils.kAllPadding16,
                  child: Row(
                    children: [
                      Obx(
                        () => Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                controller.name.value,
                                style: AppTextStyles.profileUserName,
                              ),
                              AppUtils.kBoxHeight8,
                              Text(
                                BaseFunctions.phoneFormat(
                                  controller.phone.value,
                                ),
                                style: AppTextStyles.profileUserPhone,
                              )
                            ],
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'edit'.tr,
                        icon: const Icon(
                          AppIcons.edit,
                          color: AppColors.black5,
                        ),
                        onPressed: () => Get.toNamed(AppRoutes.profileEdit),
                      ),
                    ],
                  ),
                ),
              ),
              AppUtils.kBoxHeight12,
              ClipRRect(
                borderRadius: AppUtils.kBorderRadius12,
                child: Material(
                  color: AppColors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius: AppUtils.kBorderRadius12,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ProfileItemButton(
                        text: 'my_address'.tr,
                        onTap: () {
                          Get.toNamed(AppRoutes.myAddresses);
                        },
                        icon: AppIcons.ic_location,
                      ),
                      AppUtils.kDividerPadding16,
                      ProfileItemButton(
                        text: 'branches'.tr,
                        onTap: () {
                          Get.toNamed(AppRoutes.profileBranches);
                        },
                        icon: AppIcons.location_pin,
                      ),
                      AppUtils.kDividerPadding16,
                      ProfileItemButton(
                        text: 'settings'.tr,
                        onTap: () => Get.toNamed(AppRoutes.profileSettings),
                        icon: AppIcons.settings,
                      ),
                      AppUtils.kDividerPadding16,
                      ProfileItemButton(
                        text: 'about_service'.tr,
                        onTap: () =>
                            Get.toNamed(AppRoutes.profileAboutService),
                        icon: AppIcons.exclamation_mark,
                      ),
                    ],
                  ),
                ),
              ),
              AppUtils.kBoxHeight12,
            ],
          ),
          bottomNavigationBar: SafeArea(
            minimum: AppUtils.kAllPadding12,
            child: Text(
              '${'version'.tr} ${ctr.appVersion}',
              style: AppTextStyles.version,
              textAlign: TextAlign.center,
            ),
          ),
        );
      },
    );
  }
}
