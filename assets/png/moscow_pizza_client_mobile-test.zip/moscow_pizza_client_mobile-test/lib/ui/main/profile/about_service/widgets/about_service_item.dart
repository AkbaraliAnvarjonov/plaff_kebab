import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class AboutServiceItem extends StatelessWidget {
  final String text;
  final Function()? onTap;
  final EdgeInsets padding;

  const AboutServiceItem({
    Key? key,
    required this.text,
    this.onTap,
    this.padding = EdgeInsets.zero,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: padding,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                alignment: Alignment.center,
                height: 56,
                child: Text(
                  text,
                  style: styProfileAboutServiceText,
                ),
              ),
              const Padding(
                padding: AppUtils.kAllPadding16,
                child: Icon(Icons.chevron_right_rounded),
              )
            ],
          ),
        ),
      ),
    );
  }
}
