import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_edit_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_settings_controller.dart';

import '../../../../controller/home/home_controller.dart';
import '../../../../controller/main/main_controller.dart';
import '../../../../core/custom_widgets/buttons/custom_button.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_utils.dart';
import '../../widgets/log_out_dialog.dart';

class AccountManagementPage extends GetView<ProfileEditController> {
  const AccountManagementPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('account_management'.tr)),
      body: SingleChildScrollView(
        padding: AppUtils.kAllPadding16,
        physics: const BouncingScrollPhysics(),
        child: Container(
          padding: AppUtils.kAllPadding16,
          decoration: const BoxDecoration(
            color: AppColors.white,
            borderRadius: AppUtils.kBorderRadius12,
          ),
          child: Column(
            children: [
              Image.asset(
                "assets/png/moscowskaya_pizza.png",
                height: 150,
                width: 150,
                fit: BoxFit.cover,
              ),
              AppUtils.kBoxHeight24,
              Text(
                'account_management_text_1'.tr,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
              AppUtils.kBoxHeight16,
              Text(
                'account_management_text_2'.tr,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                ),
                textAlign: TextAlign.center,
              ),
              AppUtils.kBoxHeight16,
              Text(
                'account_management_text_3'.tr,
                textAlign: TextAlign.center,
              ),
              AppUtils.kBoxHeight16,
              Text(
                'account_management_text_4'.tr,
                textAlign: TextAlign.center,
              ),
              AppUtils.kBoxHeight16,
              Text(
                'account_management_text_5'.tr,
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: GetBuilder<ProfileEditController>(
        builder: (ctr) {
          return SafeArea(
            minimum: AppUtils.kAllPadding16,
            child: CustomButton(
              text: 'delete_account'.tr,
              backgroundColor: AppColors.white,
              fontColor: AppColors.red,
              onTap: () => showDialog(
                context: context,
                builder: (context) => LogOutDialog(
                  text: 'delete_account_text'.tr,
                  onDone: () async {
                    await ctr.deleteCustomerAccount();
                    Get.find<HomeController>().customerClear();
                    await Get.find<ProfileSettingsController>().removeProfile();
                    Get..back()
                    ..back()
                    ..back();
                    await Get.find<MainController>().changeTabIndex(0);
                  },
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
