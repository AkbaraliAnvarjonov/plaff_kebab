import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_branch_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/image_network/custom_image_network.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/args/profile_branch_detaail_page_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/branch/detail/widget/maps_sheet.dart';
import 'package:url_launcher/url_launcher.dart';

import 'widget/branch_category_item_widget.dart';

class ProfileBranchDetailPage extends GetView<ProfileBranchDetailController> {
  const ProfileBranchDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var branch = (Get.arguments as ProfileBranchDetailPageArguments).branch;
    return Scaffold(
      appBar: AppBar(title: Text('branches'.tr)),
      body: GetBuilder<ProfileBranchDetailController>(
        initState: (state) {
          controller.getBranches(branch.id ?? '');
        },
        builder: (controller) {
          return Obx(
            () => ModalProgressHUD(
              inAsyncCall: controller.isLoading.value,
              child: controller.branch == null
                  ? AppUtils.kBox
                  : ListView(
                      padding: AppUtils.kPaddingTop16,
                      physics: const BouncingScrollPhysics(),
                      children: <Widget>[
                        ClipRRect(
                          borderRadius: AppUtils.kBorderRadius12,
                          child: Material(
                            color: AppColors.white,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Padding(
                                  padding: AppUtils.kAllMargin16,
                                  child: CustomImageNetwork(
                                    borderRadius: AppUtils.kBorderRadius12,
                                    height: Get.width / (795 / 400),
                                    url: controller.branch?.image ?? '',
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(
                                    top: 12,
                                    bottom: 8,
                                    right: 12,
                                    left: 12,
                                  ),
                                  child: Text(
                                    controller.branch?.name ?? '',
                                    style: styProfileBranchesItemText,
                                  ),
                                ),
                                BranchCategoryItemWidget(
                                  assets: AppIcons.location,
                                  text: controller.branch?.address ?? '',
                                  labelText: 'address'.tr,
                                ),
                                BranchCategoryItemWidget(
                                  assets: AppIcons.location,
                                  text: controller.branch?.destination ?? '',
                                  onTap: () async {
                                    await MapsSheet.show(
                                      context: context,
                                      onMapTap: (map) async {
                                        await map.showDirections(
                                          destination: Coords(
                                            (controller.branch?.location?.lat ??
                                                    0)
                                                .toDouble(),
                                            (controller.branch?.location
                                                        ?.long ??
                                                    0)
                                                .toDouble(),
                                          ),
                                          destinationTitle:
                                              controller.branch?.address ?? '',
                                        );
                                        Get.back();
                                      },
                                    );
                                  },
                                  labelText: 'reference_point'.tr,
                                ),
                                BranchCategoryItemWidget(
                                  assets: Icons.access_time,
                                  text:
                                      '${controller.branch?.workHourStart ?? ''} - ${controller.branch?.workHourEnd}',
                                  labelText: 'working_hours'.tr,
                                ),
                                BranchCategoryItemWidget(
                                  divider: false,
                                  assets: AppIcons.call,
                                  text: controller.branch?.phone ?? '',
                                  onTap: () {
                                    if (controller.branch?.phone != null) {
                                      launchUrl(
                                        Uri(
                                          scheme: 'tel',
                                          path: controller.branch?.phone ?? '',
                                        ),
                                      );
                                    }
                                  },
                                  labelText: 'phone_number'.tr,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
            ),
          );
        },
      ),
    );
  }
}
