import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_branches_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/routes/args/profile_branch_detaail_page_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/empty_widget.dart';

import 'widgets/branch_item_widget.dart';

class ProfileBranchesPage extends GetView<ProfileBranchesController> {
  const ProfileBranchesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('branches'.tr)),
      body: Obx(
        () => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          child: GetBuilder<ProfileBranchesController>(
            builder: (controller) {
              if (controller.isLoading.value) return AppUtils.kBox;
              if (controller.branches.isEmpty) {
                return EmptyWidget(text: 'branches_do_not_exist'.tr);
              }
              return ListView.separated(
                padding: AppUtils.kPaddingVertical16,
                itemCount: controller.branches.length,
                itemBuilder: (context, index) => BranchItemWidget(
                  isFirst: index == 0,
                  isLast: index == controller.branches.length - 1,
                  branch: controller.branches[index],
                  onTap: () {
                    Get.toNamed(
                      AppRoutes.profileBranchDetail,
                      arguments: ProfileBranchDetailPageArguments(
                        branch: controller.branches[index],
                      ),
                    );
                  },
                ),
                separatorBuilder: (context, index) {
                  return const ColoredBox(
                    color: AppColors.white,
                    child: Padding(
                      padding: AppUtils.kPaddingHorizontal16,
                      child: Divider(height: 1),
                    ),
                  );
                },
              );
            },
          ),
        ),
      ),
    );
  }
}
