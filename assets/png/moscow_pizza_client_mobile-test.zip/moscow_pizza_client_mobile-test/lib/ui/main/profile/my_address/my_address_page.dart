import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/my_address_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/empty_widget.dart';
import '../../../../core/custom_widgets/buttons/custom_button.dart';
import 'widgets/custom_attention_dialog.dart';
import 'widgets/my_address_item.dart';

class MyAddressPage extends GetView<MyAddressController> {
  const MyAddressPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<MyAddressController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(title: Text('my_address'.tr)),
          body: Obx(
            () {
              return ModalProgressHUD(
                inAsyncCall: controller.isLoading.value,
                child: controller.customerAddresses.isNotEmpty
                    ? Padding(
                        padding: AppUtils.kPaddingTop16,
                        child: Material(
                          color: AppColors.white,
                          borderRadius: AppUtils.kBorderRadius12,
                          child: ListView.separated(
                            itemBuilder: (_, index) {
                              return MyAddressItem(
                                customerAddresses:
                                    controller.customerAddresses[index],
                                onDeleteTap: () {
                                  Get.dialog(AttentionCustomDialog(
                                    text: 'do_you_want_to_delete_address'.tr,
                                    onDone: () async {
                                      await controller.deleteAddress(
                                          controller.customerAddresses[index]);
                                      Get.back();
                                    },
                                  ));
                                },
                              );
                            },
                            separatorBuilder: (_, __) => const Padding(
                              padding: AppUtils.kPaddingLeft16,
                              child: AppUtils.kDivider1,
                            ),
                            physics: const BouncingScrollPhysics(),
                            itemCount: controller.customerAddresses.length,
                            shrinkWrap: true,
                          ),
                        ),
                      )
                    : controller.isLoading.value
                        ? AppUtils.kBox
                        : EmptyWidget(text: 'no_addresses'.tr),
              );
            },
          ),
          bottomNavigationBar: Material(
            color: AppColors.background,
            child: SafeArea(
              minimum: AppUtils.kAllPadding16,
              child: CustomButton(
                text: 'add_address'.tr,
                onTap: () async {
                  final result = await Get.toNamed(
                    AppRoutes.map,
                  );
                  if (result != null) {
                    await controller.getMyAddress();
                  }
                  await Get.find<HomeController>().getMyAddress();
                  /// Mashitga get back qo'yish kere bo'lshi mumkun
                },
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.add_rounded,
                      color: AppColors.white,
                    ),
                    AppUtils.kBoxWidth12,
                    Text(
                      'add_address'.tr,
                      style: AppTextStyles.blackBoldText15.copyWith(
                        color: AppColors.white,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
