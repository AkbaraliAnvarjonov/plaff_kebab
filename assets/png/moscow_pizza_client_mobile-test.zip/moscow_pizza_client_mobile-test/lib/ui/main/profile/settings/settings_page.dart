import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/main/main_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_settings_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/settings/widgets/language_bottom_sheet.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/widgets/profile_item_button.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/log_out_dialog.dart';

class SettingsPage extends GetView<ProfileSettingsController> {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('settings'.tr)),
      body: Padding(
        padding: AppUtils.kVerticalPadding16,
        child: ClipRRect(
          borderRadius: AppUtils.kBorderRadius12,
          child: Material(
            color: AppColors.white,
            shape: const RoundedRectangleBorder(
              borderRadius: AppUtils.kBorderRadius12,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                ProfileItemButton(
                  text: 'language'.tr,
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      backgroundColor: AppColors.transparent,
                      builder: (context) {
                        return GetBuilder<ProfileSettingsController>(
                          builder: (snapshot) => LanguageBottomSheet(
                            text: snapshot.lang.value,
                            onTap: (value) {
                              controller.setLang(value);
                              Get..updateLocale(Locale(value))
                              ..back();
                            },
                          ),
                        );
                      },
                    );
                  },
                  icon: AppIcons.world,
                ),
                AppUtils.kDividerPadding16,
                Obx(
                  () => ProfileItemButton(
                    text: 'notifications'.tr,
                    icon: AppIcons.notification,
                    rightWidget: CupertinoSwitch(
                      onChanged: (value) {
                        controller.setNotification(value);
                      },
                      value: controller.notification.value,
                      activeColor: AppColors.assets,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        minimum: AppUtils.kAllPadding16,
        child: CustomButton(
          text: 'log_out'.tr,
          backgroundColor: AppColors.white,
          fontColor: AppColors.red,
          onTap: () => showDialog(
            context: context,
            builder: (context) => LogOutDialog(
              text: 'log_out_text'.tr,
              onDone: () async {
                await controller.removeProfile();
                Get.find<HomeController>().customerClear();
                Get..back()
                ..back();
                await Get.find<MainController>().changeTabIndex(0);
              },
            ),
          ),
        ),
      ),
    );
  }
}
