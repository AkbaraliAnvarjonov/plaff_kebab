import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/bottom_sheet/custom_bottom_sheet.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import 'language_item_widget.dart';

class LanguageBottomSheet extends StatelessWidget {
  final Function(String value) onTap;
  final String text;

  const LanguageBottomSheet({
    Key? key,
    required this.onTap,
    this.text = '',
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomBottomSheet(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          AppUtils.kBoxHeight12,
          Padding(
            padding: AppUtils.kAllPadding12,
            child: Text(
              'language'.tr,
              style: styProfileBottomSheetLang,
            ),
          ),
          AppUtils.kDivider1,
          LanguageItemWidget(
            onTap: () => onTap('ru'),
            text: 'Русский',
            assets: 'ic_russian',
            check: 'ru' == text,
          ),
          AppUtils.kDivider1,
          LanguageItemWidget(
            onTap: () => onTap('uz'),
            text: 'O’zbekcha',
            assets: 'ic_uzbek',
            check: 'uz' == text,
          ),
          AppUtils.kDivider1,
          LanguageItemWidget(
            onTap: () => onTap('en'),
            text: 'English',
            assets: 'ic_united_kingdom',
            check: 'en' == text,
          ),
          const SafeArea(child: AppUtils.kBoxHeight8),
        ],
      ),
    );
  }
}
