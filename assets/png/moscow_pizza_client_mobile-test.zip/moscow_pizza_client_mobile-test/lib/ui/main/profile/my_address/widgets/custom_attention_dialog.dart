import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

import '../../../../../core/theme/app_text_style.dart';

class AttentionCustomDialog extends StatelessWidget {
  final Function()? onDone;
  final String text;

  const AttentionCustomDialog({
    Key? key,
    this.onDone,
    this.text = '',
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      shape: const RoundedRectangleBorder(
        borderRadius: AppUtils.kBorderRadius8,
      ),
      child: Padding(
        padding: AppUtils.kAllPadding12,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'attention'.tr,
              style: styCongratulationsDialogTitle,
            ),
            const SizedBox(height: 16),
            Text(
              text,
              textAlign: TextAlign.center,
              style: styCongratulationsDialogBodyText,
            ),
            AppUtils.kBoxHeight20,
            Row(
              children: <Widget>[
                Expanded(
                  child: CustomButton(
                    onTap: () {
                      Get.back();
                    },
                    backgroundColor: AppColors.lightTestGrey,
                    text: 'not'.tr,
                    fontColor: AppColors.black,
                  ),
                ),
                AppUtils.kBoxWidth8,
                Expanded(
                  child: CustomButton(
                    onTap: onDone,
                    text: 'yes'.tr,
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
