import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class MapsSheet {
  static Future<T?> show<T>({
    required BuildContext context,
    required Function(AvailableMap map) onMapTap,
  }) async {
    return MapLauncher.installedMaps.then(
      (availableMaps) {
        return showModalBottomSheet(
          context: context,
          backgroundColor: Colors.transparent,
          builder: (context) {
            return DecoratedBox(
              decoration: const BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(12),
                  topRight: Radius.circular(12),
                ),
                color: AppColors.white,
              ),
              child: SafeArea(
                minimum: const EdgeInsets.all(16),
                child: ListView(
                  shrinkWrap: true,
                  padding: EdgeInsets.zero,
                  children: <Widget>[
                    AppUtils.kBoxHeight8,
                    for (int index = 0; index < availableMaps.length; index++)
                      Column(
                        children: [
                          Material(
                            color: Colors.transparent,
                            child: ListTile(
                              onTap: () => onMapTap(availableMaps[index]),
                              title: Text(
                                availableMaps[index].mapName,
                                style: styAuthInfo,
                              ),
                              leading: SvgPicture.asset(
                                availableMaps[index].icon,
                                height: 30.0,
                                width: 30.0,
                              ),
                            ),
                          ),
                          Visibility(
                            visible: index != availableMaps.length - 1,
                            child: const Padding(
                              padding: EdgeInsets.only(left: 16, right: 16),
                              child: AppUtils.kDivider1,
                            ),
                          ),
                        ],
                      ),
                    AppUtils.kBoxHeight12,
                    ElevatedButton(
                      child: Text('cancel'.tr),
                      onPressed: () => Navigator.pop(context),
                    )
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
