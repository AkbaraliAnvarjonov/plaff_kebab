import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_edit_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/date_picker/time_picker.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/text_fields/custom_text_field.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/ui/main/profile/edit_profile/account_management_page.dart';

class ProfileEditPage extends GetView<ProfileEditController> {
  const ProfileEditPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('edit_profile'.tr)),
      body: Obx(
        () => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          child: ListView(
            padding: AppUtils.kVerticalPadding16,
            physics: const BouncingScrollPhysics(),
            children: <Widget>[
              ClipRRect(
                borderRadius: AppUtils.kBorderRadius12,
                child: Material(
                  color: AppColors.white,
                  shape: const RoundedRectangleBorder(
                    borderRadius: AppUtils.kBorderRadius12,
                  ),
                  child: Padding(
                    padding: AppUtils.kAllPadding16,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Obx(
                          () => CustomTextField(
                            autoFocus: false,
                            currentFocus: controller.nameFocus,
                            nextFocus: controller.phoneNumberFocus,
                            controller: controller.nameController,
                            onChanged: (s) => controller.setName(s),
                            keyboardType: TextInputType.text,
                            inputAction: TextInputAction.next,
                            labelText: 'name'.tr,
                            hintText: 'enter_your_name'.tr,
                            errorText: 'error_name'.tr,
                            showError: controller.errorName.value,
                          ),
                        ),
                        AppUtils.kBoxHeight16,
                        CustomTextField(
                          autoFocus: false,
                          readOnly: true,
                          currentFocus: controller.phoneNumberFocus,
                          nextFocus: controller.dateOfBirthFocus,
                          controller: controller.phoneNumberController,
                          labelText: 'phone_number'.tr,
                        ),
                        AppUtils.kBoxHeight16,
                        CustomTextField(
                          autoFocus: false,
                          readOnly: true,
                          onTap: () {
                            TimePicker.showDatePicker(
                              context,
                              title: 'your_date_of_birth'.tr,
                              onDateTimeChanged: (date) {
                                controller.dateController.text =
                                    '${date.day.toString().padLeft(2, '0')}.${date.month.toString().padLeft(2, '0')}.${date.year}';
                              },
                              isChooseTime: false,
                            );
                          },
                          suffixIcon: const Icon(AppIcons.date),
                          currentFocus: controller.dateOfBirthFocus,
                          controller: controller.dateController,
                          labelText: 'birth_of_data'.tr,
                          hintText: 'enter_birth_of_date'.tr,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              AppUtils.kBoxHeight16,
              Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                    InkWell(
                      borderRadius: AppUtils.kBorderRadius48,
                      onTap: () {
                        Get.to(()=>const AccountManagementPage());
                      },
                      child: Padding(
                        padding: AppUtils.kHorizontalPadding8,
                        child: Text(
                        'account_management'.tr,
                        style: const TextStyle(
                          color: AppColors.assets,
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ),
                  ),

                ],
              )
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        minimum: AppUtils.kAllPadding16,
        child: CustomButton(
          onTap: () async {
            final result = await controller.updateCustomer();
            if (result) {
              var ctr = Get.find<ProfileController>();
              // ignore: cascade_invocations
              ctr.getUpdate(controller.nameController.text.trim());
              Get.back();
            }
          },
          text: 'confirm'.tr,
        ),
      ),
    );
  }
}
