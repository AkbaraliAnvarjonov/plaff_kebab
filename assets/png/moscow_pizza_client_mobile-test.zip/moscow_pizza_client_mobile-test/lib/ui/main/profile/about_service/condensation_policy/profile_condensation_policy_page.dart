import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_condensation_policy_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class ProfileCondensationPolicyPage
    extends GetView<ProfileCondensationPolicyController> {
  const ProfileCondensationPolicyPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('about_us'.tr)),
      body: Container(
        margin: AppUtils.kAllPadding12,
        padding: AppUtils.kAllPadding12,
        decoration: const BoxDecoration(
          borderRadius: AppUtils.kBorderRadius12,
          color: AppColors.white,
        ),
        child: const Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              '''
Московская Пицца®
Пиццерия
☎️(78)1136633 доставка 24/7
🍕Основана в 2009
🏪ПЕРЕЕХАЛИ с Раката в⬇️
📍Кафе рядом с парком Ашхабад
📍Филиал мост Мукими
🏆Дважды Самая вкусная пицца года''',
              style: stySearchItem,
            ),
          ],
        ),
      ),
    );
  }
}
