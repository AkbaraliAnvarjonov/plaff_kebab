import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:url_launcher/url_launcher.dart';

class BranchCategoryItemWidget extends StatelessWidget {
  final String labelText;
  final String text;
  final IconData assets;
  final bool divider;
  final Function()? onTap;
  final bool? isLinkText;

  const BranchCategoryItemWidget({
    Key? key,
    required this.text,
    required this.assets,
    this.divider = true,
    this.onTap,
    required this.labelText,
    this.isLinkText = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Ink(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            AppUtils.kBoxHeight4,
            Padding(
              padding: AppUtils.kAllMargin16,
              child: Row(
                children: <Widget>[
                  Container(
                    height: 32,
                    width: 32,
                    alignment: Alignment.center,
                    child: Icon(assets),
                  ),
                  AppUtils.kBoxWidth16,
                  Expanded(
                      child: Text(
                    labelText,
                    style: AppTextStyles.greyText15,
                  )),
                  Expanded(
                    child: SizedBox(
                        child: isLinkText!
                            ? RichText(
                                text: TextSpan(children: [
                                TextSpan(
                                    text: 'https://yandex.uz/maps/10335',
                                    style: AppTextStyles.blueText15,
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () async {
                                        var url =
                                            'https://yandex.uz/maps/10335';
                                        if (await canLaunchUrl(
                                            Uri.parse(url))) {
                                          await launchUrl(Uri.parse(url));
                                        }
                                      })
                              ]))
                            : Text(
                                text,
                                style: styProfileItemButtonText,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              )),
                  )
                ],
              ),
            ),
            AppUtils.kBoxHeight4,
            Visibility(
              visible: divider,
              child: const Padding(
                padding: AppUtils.kPaddingHorizontal16,
                child: AppUtils.kDivider1,
              ),
            )
          ],
        ),
      ),
    );
  }
}
