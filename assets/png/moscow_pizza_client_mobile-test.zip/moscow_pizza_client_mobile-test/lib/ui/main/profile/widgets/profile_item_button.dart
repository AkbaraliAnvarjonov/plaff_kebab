import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class ProfileItemButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final Function()? onTap;
  final Widget? rightWidget;

  const ProfileItemButton({
    Key? key,
    this.onTap,
    required this.text,
    this.rightWidget,
    required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Ink(
        padding: AppUtils.kHorizontal16Vertical20Padding,
        decoration: const BoxDecoration(
          borderRadius: AppUtils.kBorderRadius12,
          color: AppColors.white,
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: AppColors.black,
            ),
            AppUtils.kBoxWidth12,
            Expanded(
              child: Text(
                text,
                style: AppTextStyles.profileItemButtonText,
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
            AppUtils.kBoxWidth12,
            rightWidget == null
                ? const Icon(
                    Icons.chevron_right_rounded,
                    color: AppColors.black5,
                  )
                : rightWidget!,
          ],
        ),
      ),
    );
  }
}
