import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';

class MyAddressItem extends StatelessWidget {
  final CustomerAddresses customerAddresses;
  final Function()? onDeleteTap;

  const MyAddressItem({
    Key? key,
    required this.customerAddresses,
    this.onDeleteTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Semantics(
        label: customerAddresses.id,
        child: Padding(
          padding: const EdgeInsets.symmetric(
            vertical: 14,
            horizontal: 16,
          ),
          child: Row(
            children: [
              Material(
                borderRadius: AppUtils.kBorderRadius12,
                child: Ink(
                  height: 25,
                  width: 25,
                  child: const Icon(
                    AppIcons.location,
                    semanticLabel: '',
                  ),
                ),
              ),
              AppUtils.kBoxWidth12,
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(
                      width: 260,
                      child: Text(
                        customerAddresses.name ?? '',
                        style: styMyAddress,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 1,
                        semanticsLabel: '',
                      ),
                    ),
                    AppUtils.kBoxHeight4,
                    SizedBox(
                      width: 260,
                      child: Text(
                        customerAddresses.address ?? '',
                        style: stySubMyAddress,
                        overflow: TextOverflow.ellipsis,
                        maxLines: 3,
                        semanticsLabel: '',
                      ),
                    ),
                  ],
                ),
              ),
              InkWell(
                onTap: onDeleteTap,
                child: const Icon(
                  Icons.delete_outline,
                  size: 22,
                  color: AppColors.baseText,
                  semanticLabel: '',
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
