import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import '../../../../../../core/theme/app_utils.dart';

class HistoryOrdersDetailItemWidget extends StatelessWidget {
  final String name;
  final String sum;
  final TextStyle nameStyle;
  final TextStyle sumStyle;

  const HistoryOrdersDetailItemWidget({
    Key? key,
    required this.name,
    required this.sum,
    this.nameStyle = styHistoryOrdersDetailItemProductName,
    this.sumStyle = styHistoryOrdersDetailItemProductSum,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppUtils.kBottomPadding12,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(name, style: nameStyle),
          Text(sum, style: sumStyle),
        ],
      ),
    );
  }
}
