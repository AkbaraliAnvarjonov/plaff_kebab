import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/reviews_response.dart';

import 'choose_reason_item_widget.dart';

class ChooseReasonBottomSheet extends StatefulWidget {
  final String title;
  final Function()? onAddComment;
  final Function()? onDone;
  final List<Reviews> list;

  final String? value;
  final Function(int)? onTap;

  const ChooseReasonBottomSheet({
    Key? key,
    this.title = '',
    this.onAddComment,
    this.onDone,
    this.value = '',
    this.onTap,
    this.list = const [],
  }) : super(key: key);

  @override
  ChooseReasonBottomSheetState createState() => ChooseReasonBottomSheetState();
}

class ChooseReasonBottomSheetState extends State<ChooseReasonBottomSheet> {
  String _value = '';
  final LocalSource _localeSource = LocalSource.instance;

  @override
  void initState() {
    _value = widget.value ?? '';
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      physics: const BouncingScrollPhysics(),
      shrinkWrap: true,
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.only(top: 24, right: 12, left: 12),
          child: Text(
            'choose_a_reason'.tr,
            style: styChooseReasonTitle,
          ),
        ),
        ListView.separated(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemBuilder: (_, index) {
            String? text = (_localeSource.locale == 'ru'
                ? widget.list[index].message?.ru
                : widget.list[index].message?.uz);
            return ChooseReasonItemWidget(
              onTap: () {
                widget.onTap!(index);
                setState(() => _value = text ?? '');
                debugPrint(_value);
              },
              checked: _value == text,
              text: text ?? '',
            );
          },
          separatorBuilder: (_, __) => AppUtils.kDivider1,
          itemCount: widget.list.length,
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 12, left: 12, right: 12),
          child: CustomButton(
            onTap: widget.onAddComment,
            height: 48,
            backgroundColor: AppColors.divider,
            child: Text(
              'add_comments...'.tr,
              style: styChooseReasonAddCommentText,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(bottom: 24, left: 12, right: 12),
          child: CustomButton(
            onTap: widget.onDone,
            height: 48,
            child: Text(
              'confirm'.tr,
              style: styChooseReasonDoneText,
            ),
          ),
        )
      ],
    );
  }
}
