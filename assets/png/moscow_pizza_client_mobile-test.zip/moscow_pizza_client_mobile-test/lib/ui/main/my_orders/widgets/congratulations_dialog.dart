import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class CongratulationsDialog extends StatelessWidget {
  final Function()? onCancel;
  final Function()? onDone;

  const CongratulationsDialog({
    Key? key,
    this.onCancel,
    this.onDone,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Dialog(
      elevation: 0,
      shape: const RoundedRectangleBorder(borderRadius: AppUtils.kBorderRadius8),
      child: Padding(
        padding: AppUtils.kAllPadding12,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Text(
              'congratulations'.tr,
              textAlign: TextAlign.center,
              style: styCongratulationsDialogTitle,
            ),
            AppUtils.kBoxHeight16,
            Text(
              'your_order_has_been_successfully_delivered'.tr,
              textAlign: TextAlign.center,
              style: styCongratulationsDialogBodyText,
            ),
            AppUtils.kBoxHeight20,
            Row(
              children: [
                Flexible(
                  child: CustomButton(
                    width: Get.width/2,
                    height: 42,
                    onTap: onCancel,
                    backgroundColor: AppColors.lightTestGrey,
                    child: Text(
                      '${'not'.tr} 👎',
                      style: styCongratulationsDialogNot,
                    ),
                  ),
                ),
                AppUtils.kBoxWidth8,
                Flexible(
                  child: CustomButton(
                    width: Get.width/2,
                    height: 42,
                    onTap: onDone,
                    child: Text(
                      '${'yes'.tr} 👍',
                      style: styCongratulationsDialogYes,
                    ),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
