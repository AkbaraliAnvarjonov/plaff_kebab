import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/order_status.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/current_orders/widgets/circle_svg_item_widget.dart';
import 'package:get/get.dart';
import '../../widgets/order_status_widget.dart';
import 'container_status_widget.dart';

class CurrentOrderStatusItemWidget extends StatelessWidget {
  final Function(Orders? value)? onTap;
  final Orders? order;

  const CurrentOrderStatusItemWidget({
    Key? key,
    this.onTap,
    this.order,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          padding: AppUtils.kPaddingHorizontal16Vertical12,
          decoration: const BoxDecoration(
            borderRadius: AppUtils.kBorderRadius12,
            color: AppColors.white,
          ),
          child: Semantics(
            label: order?.id,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        '${'order'.tr} №${order?.externalOrderId ?? ''}',
                        style: styCurrentOrdersStatusItemTitle,
                        semanticsLabel: '',
                      ),
                    ),
                    AppUtils.kBoxWidth8,
                    OrderStatusWidget(
                      text: order?.deliveryType == 'delivery'
                          ? BaseFunctions.getDeliveryText(order?.statusId ?? '')
                          : BaseFunctions.getSelfPickUpText(
                              order?.statusId ?? ''),
                      color: AppColors.lightBlue,
                      textColor: AppColors.blue,
                    ),
                  ],
                ),
                AppUtils.kBoxHeight24,
                if (order?.deliveryType == 'delivery')
                  Row(
                    children: <Widget>[
                      /// First status
                      const CircleItemSvgWidget(
                        assets: Icons.check_rounded,
                      ),
                      const Expanded(child: ContainerStatusWidget()),

                      /// Second status
                      CircleItemSvgWidget(
                        assets: AppIcons.chef,
                        status: BaseFunctions.getDeliveryStatus(
                                    order?.statusId) ==
                                OrderStatus.courierPickUp ||
                            BaseFunctions.getDeliveryStatus(order?.statusId) ==
                                OrderStatus.vendorReady ||
                            BaseFunctions.getDeliveryStatus(order?.statusId) ==
                                OrderStatus.vendorAccepted,
                      ),
                      Expanded(
                        child: ContainerStatusWidget(
                          status: BaseFunctions.getDeliveryStatus(
                                      order?.statusId) ==
                                  OrderStatus.courierPickUp ||
                              BaseFunctions.getDeliveryStatus(
                                      order?.statusId) ==
                                  OrderStatus.vendorReady ||
                              BaseFunctions.getDeliveryStatus(
                                      order?.statusId) ==
                                  OrderStatus.vendorAccepted,
                        ),
                      ),

                      /// Third status    COURIER_PICKUP
                      CircleItemSvgWidget(
                        assets: AppIcons.fast_delivery,
                        status:
                            BaseFunctions.getDeliveryStatus(order?.statusId) ==
                                OrderStatus.courierPickUp,
                      ),
                      Expanded(
                        child: ContainerStatusWidget(
                          status: BaseFunctions.getDeliveryStatus(
                                  order?.statusId) ==
                              OrderStatus.courierPickUp,
                        ),
                      ),
                      const CircleItemSvgWidget(
                        assets: AppIcons.finish,
                        status: false,
                      ),
                    ],
                  )
                else
                  Row(
                    children: <Widget>[
                      /// First Status
                      const CircleItemSvgWidget(
                        assets: Icons.check_rounded,
                      ),
                      const Expanded(
                        child: ContainerStatusWidget(),
                      ),

                      /// Second Status
                      CircleItemSvgWidget(
                          assets: AppIcons.chef,
                          status: BaseFunctions.getSelfPickUpStatus(
                                      order?.statusId) ==
                                  OrderStatus.vendorReady ||
                              BaseFunctions.getSelfPickUpStatus(
                                      order?.statusId) ==
                                  OrderStatus.vendorAccepted),
                      Expanded(
                        child: ContainerStatusWidget(
                            status: BaseFunctions.getSelfPickUpStatus(
                                        order?.statusId) ==
                                    OrderStatus.vendorReady ||
                                BaseFunctions.getSelfPickUpStatus(
                                        order?.statusId) ==
                                    OrderStatus.vendorAccepted),
                      ),

                      /// Third Status
                      CircleItemSvgWidget(
                        assets: AppIcons.finish,
                        status: BaseFunctions.getSelfPickUpStatus(
                                order?.statusId) ==
                            OrderStatus.vendorReady,
                      )
                    ],
                  )
              ],
            ),
          ),
        ),
        Positioned.fill(
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => onTap!(order),
              borderRadius: AppUtils.kBorderRadius12,
              splashColor: Colors.black12,
            ),
          ),
        ),
      ],
    );
  }
}
