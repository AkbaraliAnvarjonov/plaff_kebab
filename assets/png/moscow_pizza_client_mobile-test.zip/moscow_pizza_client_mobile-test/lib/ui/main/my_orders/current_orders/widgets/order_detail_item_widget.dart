import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class OrderDetailItemWidget extends StatelessWidget {
  final String labelText;
  final String text;
  final IconData assets;
  final bool? isLinkText;

  const OrderDetailItemWidget({
    Key? key,
    required this.text,
    required this.assets,
    required this.labelText,
    this.isLinkText = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: AppUtils.kPaddingTop8,
      child: Row(
        children: <Widget>[
          Icon(assets,color: AppColors.black3,size: 20,),
          AppUtils.kBoxWidth8,
          Text(
            labelText,
            style: AppTextStyles.greyText15,
          ),
          AppUtils.kBoxWidth12,
          Expanded(
            child: Text(
              text == 'cash' ? ('cash'.tr) : text,
              style: styProfileItemButtonText,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.end,
            ),
          )
        ],
      ),
    );
  }
}
