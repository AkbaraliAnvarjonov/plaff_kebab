import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/widgets/order_status_widget.dart';

class HistoryOrderItemWidget extends StatelessWidget {
  final Function()? onTap;
  final Orders orders;

  const HistoryOrderItemWidget({
    Key? key,
    this.onTap,
    required this.orders,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    debugPrint(orders.statusId ?? '');
    return Material(
      borderRadius: AppUtils.kBorderRadius12,
      color: AppColors.white,
      child: InkWell(
        onTap: onTap,
        borderRadius: AppUtils.kBorderRadius12,
        child: Ink(
          padding: AppUtils.kHorizontal16Vertical12Padding,
          color: AppColors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: [
              Semantics(
                label: orders.id,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(
                      child: Text(
                        '${'order'.tr} №${orders.externalOrderId ?? ''}',
                        style: styCurrentOrdersStatusItemTitle,
                        semanticsLabel: '',
                      ),
                    ),
                    Padding(
                      padding: AppUtils.kLeftPadding8,
                      child: OrderStatusWidget(
                        textColor: AppColors.blue,
                        color: AppColors.lightBlue,
                        text: orders.deliveryType == 'delivery'
                            ? BaseFunctions.getDeliveryText(
                                orders.statusId ?? '',
                              )
                            : BaseFunctions.getSelfPickUpText(
                                orders.statusId ?? '',
                              ),
                      ),
                    ),
                  ],
                ),
              ),
              AppUtils.kBoxHeight16,
              Row(
                children: [
                  Expanded(
                    child: Text(
                      BaseFunctions.moneyFormatSymbol(
                          (orders.orderAmount ?? 0) +
                              (orders.deliveryPrice ?? 0)),
                      style: styHistoryOrdersCategoryItemSum,
                      semanticsLabel: '',
                    ),
                  ),
                  const Icon(
                    AppIcons.date,
                    size: 16,
                    color: AppColors.black3,
                  ),
                  AppUtils.kBoxWidth2,
                  Text(
                    BaseFunctions.dateFormatter(orders.createdAt ?? ''),
                    style: styHistoryOrdersCategoryItemDate,
                    semanticsLabel: '',
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
