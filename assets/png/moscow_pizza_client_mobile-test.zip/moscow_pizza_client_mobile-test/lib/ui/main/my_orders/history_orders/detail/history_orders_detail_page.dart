import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/history_orders_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/routes/args/history_orders_detail_page_arguments.dart';

import '../../../../../base/base_functions.dart';
import '../../../../../core/theme/app_icons.dart';
import '../../../../../core/theme/app_text_style.dart';
import '../../current_orders/widgets/check_widget.dart';
import '../../current_orders/widgets/courier_detail_widget.dart';
import '../../current_orders/widgets/order_detail_item_widget.dart';
import '../../widgets/order_status_widget.dart';

class HistoryOrdersDetailPage extends GetView<HistoryOrdersDetailController> {
  const HistoryOrdersDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Orders order =
        (Get.arguments as HistoryOrdersDetailPageArguments).order;
    return Scaffold(
      appBar: AppBar(
        title: Text('${'order'.tr} № ${order.externalOrderId ?? ''}'),
      ),
      body: GetX<HistoryOrdersDetailController>(
        initState: (state) {
          Get.find<HistoryOrdersDetailController>().getHistoryItemOrder(
            order.id ?? '',
          );
        },
        builder: (ctr) => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          child: !controller.ordersShow.value
              ? AppUtils.kBox
              : ListView(
            padding: AppUtils.kPaddingTop16,
            physics: const BouncingScrollPhysics(),
            children: <Widget>[
              Padding(
                padding: AppUtils.kBottomPadding12,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 16,
                  ),
                  decoration: const BoxDecoration(
                    borderRadius: AppUtils.kBorderRadius12,
                    color: AppColors.white,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Flexible(
                            child: Text(
                              '${'order'.tr} №${ctr.orders?.externalOrderId ?? ''}',
                              style: styCurrentOrdersStatusItemTitle,
                            ),
                          ),
                          Padding(
                            padding: AppUtils.kLeftPadding8,
                            child: OrderStatusWidget(
                              text: ctr.orders?.deliveryType == 'delivery'
                                  ? BaseFunctions.getDeliveryText(
                                  ctr.orders?.statusId ?? '')
                                  : BaseFunctions.getSelfPickUpText(
                                  ctr.orders?.statusId ?? ''),
                              color: AppColors.lightBlue,
                              textColor: AppColors.blue,
                            ),
                          ),
                        ],
                      ),
                      AppUtils.kBoxHeight4,
                      OrderDetailItemWidget(
                        text: BaseFunctions.addressFormatter(
                            ctr.orders?.toAddress ?? ''),
                        assets: AppIcons.location,
                        labelText: 'address'.tr,
                      ),
                      OrderDetailItemWidget(
                        text: BaseFunctions.timeFormatter(
                            ctr.orders?.createdAt ?? ''),
                        assets: Icons.access_time,
                        labelText: 'time'.tr,
                      ),
                      OrderDetailItemWidget(
                        text: BaseFunctions.dateFormatter(
                            ctr.orders?.createdAt ?? ''),
                        assets: AppIcons.date,
                        labelText: 'date'.tr,
                      ),
                      OrderDetailItemWidget(
                        text: ctr.orders?.paymentType ?? '',
                        assets: AppIcons.credit_card,
                        labelText: 'payment_method'.tr,
                      ),
                    ],
                  ),
                ),
              ),
              CourierDetailWidget(courier: ctr.orders?.courier),
              AppUtils.kBoxHeight12,
              CheckWidget(
                isCheckout: true,
                isDelivery: ctr.orders?.deliveryType == 'delivery',
                deliveryPrice: ctr.orders?.deliveryType == 'delivery' ? controller.orders?.deliveryPrice ?? 0 : 0,
                products: controller.orders?.steps[0].products ?? [],
                generalSum: controller.getAllPrice,
                totalDiscountSum: controller.totalDiscountSum,
                discounts: controller.discountName,
              )
            ],
          ),
        ),
      ),
      bottomNavigationBar: Obx(
            () => Visibility(
          visible: !controller.isLoading.value,
          child: Material(
            color: AppColors.white,
            child: SafeArea(
              minimum: AppUtils.kAllPadding16,
              child: CustomButton(
                text: 'repeat_order'.tr,
                onTap: () async {
                  bool result = await controller.addOnDemandOrder();
                  if (result) {
                    Get.back();
                  }
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
