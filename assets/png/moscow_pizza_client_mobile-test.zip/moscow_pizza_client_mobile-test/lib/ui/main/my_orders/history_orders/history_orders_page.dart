import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/history_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_android_ios_indicator.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_circular_progress_indicator.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/infinite_scrolling_pagination.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/empty_widget.dart';

import '../../../../routes/args/history_orders_detail_page_arguments.dart';
import 'widgets/history_order_item_widget.dart';

class HistoryOrdersPage extends GetView<HistoryOrdersController> {
  const HistoryOrdersPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HistoryOrdersController>(
      initState: (_) {
        controller.getOrdersHistory();
      },
      builder: (controller) {
        return Obx(
          () => ModalProgressHUD(
            inAsyncCall: controller.isLoading.value,
            child: controller.isLoading.value
                ? AppUtils.kBox
                : controller.orders.isEmpty
                    ? EmptyWidget(text: 'order_unavailable'.tr)
                    : Obx(
                        () => InfiniteScrollingPagination(
                          isCallLoading: controller.isPaginationLoading.value,
                          onPagination: () async {
                            if (controller.orders.length >=
                                controller.page * 10) {
                              await controller.pagination();
                            }
                          },
                          child: CustomScrollView(
                            keyboardDismissBehavior:
                                ScrollViewKeyboardDismissBehavior.onDrag,
                            physics: const BouncingScrollPhysics(),
                            slivers: [
                              CustomAndroidIosIndicator(
                                onRefreshAndroid: () async {
                                  await controller.refreshOrdersHistory();
                                  return;
                                },
                                onRefreshIos: () async {
                                  await controller.refreshOrdersHistory();
                                  return;
                                },
                              ),
                              SliverList(
                                delegate: SliverChildBuilderDelegate(
                                  (_, index) => AppUtils.kBoxHeight12,
                                  childCount: 1,
                                ),
                              ),
                              SliverList(
                                delegate: SliverChildBuilderDelegate(
                                  (_, index) {
                                    if (index < controller.orders.length) {
                                      return Padding(
                                        padding: AppUtils.kBottomMargin12,
                                        child: HistoryOrderItemWidget(
                                          orders: controller.orders[index],
                                          onTap: () {
                                            Get.toNamed(
                                              AppRoutes.historyOrdersDetail,
                                              arguments:
                                                  HistoryOrdersDetailPageArguments(
                                                      order: controller
                                                          .orders[index]),
                                            );
                                          },
                                        ),
                                      );
                                    } else {
                                      return CustomCircularProgressIndicator(
                                        isCalling: controller
                                            .isPaginationLoading.value,
                                        isPagination: true,
                                      );
                                    }
                                  },
                                  childCount: controller.orders.length +
                                      (controller.isPaginationLoading.value
                                          ? 1
                                          : 0),
                                ),
                              ),
                            ],
                          ),
                          // ListView.separated(
                          //   shrinkWrap: true,
                          //   padding: AppUtils.kVerticalPadding16,
                          //   itemCount: controller.orders.length +
                          //       (controller.isPaginationLoading.value
                          //           ? 1
                          //           : 0),
                          //   itemBuilder: (_, index) {
                          //     if (index < controller.orders.length) {
                          //       return HistoryOrderItemWidget(
                          //         orders: controller.orders[index],
                          //         onTap: () {
                          //           Get.toNamed(
                          //             AppRoutes.HISTORY_ORDERS_DETAIL,
                          //             arguments:
                          //                 HistoryOrdersDetailPageArguments(
                          //                     order:
                          //                         controller.orders[index]),
                          //           );
                          //         },
                          //       );
                          //     } else {
                          //       return CustomCircularProgressIndicator(
                          //         isCalling:
                          //             controller.isPaginationLoading.value,
                          //         isPagination: true,
                          //       );
                          //     }
                          //   },
                          //   separatorBuilder: (_, __) =>
                          //       AppUtils.kBoxHeight12,
                          // ),
                        ),
                      ),
          ),
        );
      },
    );
  }
}
