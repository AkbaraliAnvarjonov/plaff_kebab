import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class CheckItemWidget extends StatelessWidget {
  final String? name;
  final String sum;
  final String countText;
  final TextStyle nameStyle;
  final TextStyle sumStyle;
  final bool? needPadding;
  final String? totalDiscountSum;
  final String? totalSum;

  const CheckItemWidget({
    Key? key,
    required this.sum,
    this.name,
    this.countText = '',
    this.nameStyle = AppTextStyles.greyText15,
    this.sumStyle = AppTextStyles.greyBoldText15,
    this.needPadding = true,
    this.totalDiscountSum,
    this.totalSum,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: needPadding! ? AppUtils.kBottomPadding12 : EdgeInsets.zero,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(child: Text(name.toString(), style: nameStyle)),
          RichText(
            text: TextSpan(
              style: nameStyle,
              children: [
                if (totalDiscountSum != null && totalSum != null) ...[
                  TextSpan(
                    text: '$totalDiscountSum  ',
                    style: AppTextStyles.greyText15
                        .copyWith(color: AppColors.black),
                  ),
                  TextSpan(
                    text: totalSum,
                    style: AppTextStyles.greyText15.copyWith(
                      decoration: TextDecoration.lineThrough,
                    ),
                  ),
                  TextSpan(
                    text: ' ${'sum'.tr}',
                    style: AppTextStyles.greyText15,
                  ),
                ] else ...[
                  TextSpan(
                    text: (name == null || (name ?? '').contains('Доставка'))
                        ? ''
                        : countText,
                    style: AppTextStyles.greyText15,
                  ),
                  TextSpan(text: sum, style: AppTextStyles.greyText15),
                ]
              ],
            ),
          ),
          // Text(sum, style: sumStyle),
        ],
      ),
    );
  }
}
