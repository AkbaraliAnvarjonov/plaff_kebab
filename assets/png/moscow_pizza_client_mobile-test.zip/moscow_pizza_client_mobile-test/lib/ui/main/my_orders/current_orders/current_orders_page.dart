import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/current_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/custom_android_ios_indicator.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:moscow_pizza_client_mobile/routes/args/current_order_detail_page_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/widgets/empty_widget.dart';
import 'widgets/current_order_status_item_widget.dart';

class CurrentOrdersPage extends GetView<CurrentOrdersController> {
  const CurrentOrdersPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GetBuilder<CurrentOrdersController>(
      initState: (_) {
        controller.getCurrentOrders();
      },
      builder: (controller) {
        return Obx(
          () => ModalProgressHUD(
            inAsyncCall: controller.isLoading.value,
            child: controller.isLoading.value
                ? AppUtils.kBox
                : controller.orders.isEmpty
                    ? EmptyWidget(text: 'order_unavailable'.tr)
                    : CustomScrollView(
                        keyboardDismissBehavior:
                            ScrollViewKeyboardDismissBehavior.onDrag,
                        physics: const BouncingScrollPhysics(),
                        slivers: [
                          CustomAndroidIosIndicator(
                            onRefreshAndroid: () async {
                              await controller.refreshCurrentOrders();
                              return;
                            },
                            onRefreshIos: () async {
                              await controller.refreshCurrentOrders();
                              return;
                            },
                          ),
                          SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (_, index) => AppUtils.kBoxHeight12,
                              childCount: 1,
                            ),
                          ),
                          SliverList(
                            delegate: SliverChildBuilderDelegate(
                              (context, index) => Padding(
                                padding: AppUtils.kBottomMargin12,
                                child: CurrentOrderStatusItemWidget(
                                  order: controller.orders[index],
                                  onTap: (value) {
                                    Get.toNamed(
                                      AppRoutes.currentOrdersDetail,
                                      arguments:
                                          CurrentOrderDetailPageArguments(
                                              id: value?.id ?? ''),
                                    );
                                  },
                                ),
                              ),
                              childCount: controller.orders.length,
                            ),
                          ),
                        ],
                      ),
          ),
        );
      },
    );
  }
}
