import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class CircleItemSvgWidget extends StatelessWidget {
  final bool status;
  final IconData assets;

  const CircleItemSvgWidget({
    Key? key,
    this.status = true,
    required this.assets,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: Ink(
        height: 56,
        width: 56,
        decoration: BoxDecoration(
          color: status ? AppColors.assets : AppColors.lightTestGrey,
          shape: BoxShape.circle,
        ),
        child: Center(
          child: Icon(
            assets,
            size: 24,
            color: status ? AppColors.white : AppColors.assets,
          ),
        ),
      ),
    );
  }
}
