import 'package:flutter/material.dart';

import '../../../../core/theme/app_utils.dart';

class OrderStatusWidget extends StatelessWidget {
  final String text;
  final Color textColor;
  final Color color;

  const OrderStatusWidget({
    Key? key,
    required this.textColor,
    required this.color,
    required this.text,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      borderRadius: AppUtils.kBorderRadius12,
      color: Colors.transparent,
      child: Ink(
        padding: AppUtils.kPaddingHorizontal16Vertical5,
        decoration: BoxDecoration(
          borderRadius: AppUtils.kBorderRadius12,
          color: color,
        ),
        child: Semantics(
          child: Text(
            text,
            semanticsLabel: '',
            style: TextStyle(fontSize: 15, color: textColor),
            maxLines: 2,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ),
    );
  }
}
