import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/current_orders/widgets/check_item_widget.dart';

class CheckWidget extends StatelessWidget {
  final num generalSum;
  final List<OrdersProducts> products;
  final bool isDelivery;
  final bool isCheckout;
  final String orderStatus;
  final int deliveryPrice;
  final num? totalDiscountSum;
  final List<String> discounts;

  const CheckWidget({
    Key? key,
    this.discounts = const [],
    this.totalDiscountSum,
    this.deliveryPrice = 0,
    this.generalSum = 0,
    this.isDelivery = false,
    this.isCheckout = false,
    this.products = const [],
    this.orderStatus = '',
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: AppUtils.kPaddingHorizontal16Vertical12,
      decoration: const BoxDecoration(
        borderRadius: AppUtils.kBorderRadius12,
        color: AppColors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'check'.tr,
            style: AppTextStyles.blackBoldText15,
          ),
          AppUtils.kBoxHeight16,
          ListView.separated(
            padding: EdgeInsets.zero,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: products.length,
            itemBuilder: (context, index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisSize: MainAxisSize.min,
                children: [
                  CheckItemWidget(
                    countText: '${products[index].quantity} x ',
                    name: products[index].name ?? 'delivery'.tr,
                    sum:
                        // ignore: unnecessary_parenthesis
                        '${BaseFunctions.moneyFormat(
                      int.tryParse(((((products[index].quantity ?? 0) *
                                          (products[index].price ?? 0)) +
                                      (products[index].discountPrice ?? 0)) ~/
                                  (products[index].quantity ?? 0))
                              .toString()) ??
                          0,
                    )} ${'sum'.tr}',
                  ),
                  if ((products[index].variants ?? []).isNotEmpty)
                    ...List.generate(
                      (products[index].variants ?? []).length,
                      (i) => (products[index].variants?[i].variantName?.ru ??
                                  '')
                              .isEmpty
                          ? AppUtils.kBox
                          : Padding(
                              padding:
                                  const EdgeInsets.only(left: 12, bottom: 12),
                              child: RichText(
                                text: TextSpan(
                                    text: BaseFunctions.getTranslateVariantName(
                                        products[index]
                                            .variants?[i]
                                            .variantName),
                                    style: AppTextStyles.greyText15),
                              ),
                            ),
                    ),
                  if ((products[index].modifiers ?? []).isNotEmpty)
                    ...List.generate(
                      (products[index].modifiers ?? []).length,
                      (i) => Padding(
                        padding: AppUtils.kBottomPadding12,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            RichText(
                              text: TextSpan(
                                text: BaseFunctions.getModifierNameTranslate(
                                    products[index].modifiers?[i].modifierName),
                                style: AppTextStyles.greyText15,
                                children: [
                                  TextSpan(
                                      text:
                                          ' x${products[index].modifiers?[i].modifierQuantity.toString() ?? ''}',
                                      style: AppTextStyles.greyText15),
                                ],
                              ),
                            ),
                            AppUtils.kBoxWidth8,
                            Text(
                                '${products[index].modifiers?[i].modifiersPrice ?? '0'} ${'sum'.tr}',
                                style: AppTextStyles.greyBoldText15),
                          ],
                        ),
                      ),
                    ),
                ],
              );
            },
            separatorBuilder: (_, __) => const Padding(
              padding: AppUtils.kBottomPadding12,
              child: AppUtils.kDivider1,
            ),
          ),
          Visibility(
            visible: orderStatus.isNotEmpty,
            child: CheckItemWidget(
              name: 'status'.tr,
              sum: orderStatus == 'canceled'.tr
                  ? 'canceled'.tr
                  : 'successfully'.tr,
              sumStyle: TextStyle(
                color: orderStatus == 'canceled'.tr
                    ? AppColors.red
                    : AppColors.green,
                fontSize: 15,
                fontWeight: FontWeight.w400,
              ),
            ),
          ),
          isDelivery
              ? CheckItemWidget(
                  name: 'shipping_amount'.tr,
                  sum: '${getPrice()} ${'sum'.tr}',
                )
              : AppUtils.kBox,
          if (discounts.isNotEmpty)
            ...List.generate(
              discounts.length,
              (index) => CheckItemWidget(
                name: '',
                sum: discounts[index],
              ),
            ),
          AppUtils.kBoxHeight8,
          CheckItemWidget(
            needPadding: false,
            name: 'total_amount'.tr,
            nameStyle: AppTextStyles.blackBoldText17,
            sum: "${BaseFunctions.moneyFormat(generalSum + (isDelivery ? deliveryPrice : 0))} ${"sum".tr}",
            sumStyle: AppTextStyles.blackBoldText17,
            totalDiscountSum: (totalDiscountSum ?? 0) > 0 &&
                    totalDiscountSum !=
                        generalSum + (isDelivery ? deliveryPrice : 0)
                ? BaseFunctions.moneyFormat(totalDiscountSum ?? 0)
                : null,
            totalSum: BaseFunctions.moneyFormat(generalSum + (isDelivery ? deliveryPrice : 0)),
          ),
        ],
      ),
    );
  }

  String getPrice() {
    return BaseFunctions.moneyFormat(
        isCheckout ? deliveryPrice : AppConstants.deliveryPrice);
  }
}
