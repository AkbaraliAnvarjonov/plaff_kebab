import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/current_orders_detail_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/args/current_order_detail_page_arguments.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/current_orders/widgets/courier_detail_widget.dart';
import 'package:moscow_pizza_client_mobile/ui/main/my_orders/current_orders/widgets/order_detail_item_widget.dart';

import '../../../../../core/theme/app_colors.dart';
import '../../../../../data/models/order_status.dart';
import '../../widgets/order_status_widget.dart';
import '../widgets/check_widget.dart';
import '../widgets/circle_svg_item_widget.dart';
import '../widgets/container_status_widget.dart';

class CurrentOrdersDetailPage extends GetView<CurrentOrdersDetailController> {
  const CurrentOrdersDetailPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final id = (Get.arguments as CurrentOrderDetailPageArguments).id;
    return Scaffold(
      appBar: AppBar(title: Text('current_order'.tr)),
      body: GetX<CurrentOrdersDetailController>(
        initState: (state) {
          Get.find<CurrentOrdersDetailController>().getCurrentItemOrder(id);
        },
        builder: (ctr) => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          child: !controller.ordersShow.value
              ? AppUtils.kBox
              : ListView(
            padding: AppUtils.kPaddingTop16,
            physics: const BouncingScrollPhysics(),
            children: <Widget>[
              Padding(
                padding: AppUtils.kBottomPadding12,
                child: Stack(
                  children: [
                    Container(
                      padding: AppUtils.kHorizontal12Vertical16Padding,
                      decoration: const BoxDecoration(
                        borderRadius: AppUtils.kBorderRadius12,
                        color: AppColors.white,
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  '${'order'.tr} №${ctr.orders?.externalOrderId ?? ''}',
                                  style: styCurrentOrdersStatusItemTitle,
                                ),
                              ),
                              OrderStatusWidget(
                                text:
                                ctr.orders?.deliveryType == 'delivery'
                                    ? BaseFunctions.getDeliveryText(
                                    ctr.orders?.statusId ?? '')
                                    : BaseFunctions.getSelfPickUpText(
                                    ctr.orders?.statusId ?? ''),
                                color: AppColors.lightBlue,
                                textColor: AppColors.blue,
                              )
                            ],
                          ),
                          AppUtils.kBoxHeight24,
                          if (ctr.orders?.deliveryType == 'delivery')
                            Row(
                              children: <Widget>[
                                const CircleItemSvgWidget(
                                  assets: Icons.check_rounded,
                                ),
                                const Expanded(
                                    child: ContainerStatusWidget()),
                                CircleItemSvgWidget(
                                  assets: AppIcons.chef,
                                  status: BaseFunctions.getDeliveryStatus(
                                      ctr.orders?.statusId) ==
                                      OrderStatus.courierPickUp ||
                                      BaseFunctions.getDeliveryStatus(
                                          ctr.orders?.statusId) ==
                                          OrderStatus.vendorAccepted ||
                                      BaseFunctions.getDeliveryStatus(
                                          ctr.orders?.statusId) ==
                                          OrderStatus.vendorReady,
                                ),
                                Expanded(
                                  child: ContainerStatusWidget(
                                    status: BaseFunctions
                                        .getDeliveryStatus(ctr
                                        .orders?.statusId) ==
                                        OrderStatus.courierPickUp ||
                                        BaseFunctions.getDeliveryStatus(
                                            ctr.orders?.statusId) ==
                                            OrderStatus.vendorReady ||
                                        BaseFunctions.getDeliveryStatus(
                                            ctr.orders?.statusId) ==
                                            OrderStatus.vendorAccepted,
                                  ),
                                ),
                                CircleItemSvgWidget(
                                  assets: AppIcons.fast_delivery,
                                  status: BaseFunctions.getDeliveryStatus(
                                      ctr.orders?.statusId) ==
                                      OrderStatus.courierPickUp,
                                ),
                                Expanded(
                                  child: ContainerStatusWidget(
                                    status:
                                    BaseFunctions.getDeliveryStatus(
                                        ctr.orders?.statusId) ==
                                        OrderStatus.courierPickUp,
                                  ),
                                ),
                                const CircleItemSvgWidget(
                                  assets: AppIcons.finish,
                                  status: false,
                                ),
                              ],
                            )
                          else
                            Row(
                              children: <Widget>[
                                const CircleItemSvgWidget(
                                  assets: Icons.check_rounded,
                                ),
                                const Expanded(
                                  child: ContainerStatusWidget(

                                  ),
                                ),
                                CircleItemSvgWidget(
                                  assets: AppIcons.chef,
                                  status: BaseFunctions
                                      .getSelfPickUpStatus(
                                      ctr.orders?.statusId) ==
                                      OrderStatus.vendorReady ||
                                      BaseFunctions.getSelfPickUpStatus(
                                          ctr.orders?.statusId) ==
                                          OrderStatus.vendorAccepted,
                                ),
                                Expanded(
                                  child: ContainerStatusWidget(
                                    status: BaseFunctions
                                        .getSelfPickUpStatus(ctr
                                        .orders?.statusId) ==
                                        OrderStatus.vendorReady ||
                                        BaseFunctions.getSelfPickUpStatus(
                                            ctr.orders?.statusId) ==
                                            OrderStatus.vendorAccepted,
                                  ),
                                ),
                                CircleItemSvgWidget(
                                  assets: AppIcons.finish,
                                  status:
                                  BaseFunctions.getSelfPickUpStatus(
                                      ctr.orders?.statusId) ==
                                      OrderStatus.vendorReady,
                                ),
                              ],
                            ),
                          AppUtils.kBoxHeight24,
                          OrderDetailItemWidget(
                            text: BaseFunctions.addressFormatter(ctr
                                .orders?.deliveryType ==
                                'delivery'
                                ? ctr.orders?.toAddress ?? ''
                                : ctr.orders?.steps.isNotEmpty ?? false
                                ? ctr.orders?.steps[0].branchName ??
                                ''
                                : ''),
                            assets: AppIcons.location,
                            labelText:
                            (ctr.orders?.deliveryType == 'delivery')
                                ? 'address'.tr
                                : 'branch'.tr,
                          ),
                          OrderDetailItemWidget(
                              text: BaseFunctions.timeFormatter(
                                  ctr.orders?.createdAt ?? ''),
                              assets: Icons.access_time,
                              labelText: 'time'.tr),
                          OrderDetailItemWidget(
                              text: BaseFunctions.dateFormatter(
                                  ctr.orders?.createdAt ?? ''),
                              assets: AppIcons.date,
                              labelText: 'date'.tr),
                          OrderDetailItemWidget(
                              text: ctr.orders?.paymentType ?? '',
                              assets: AppIcons.credit_card,
                              labelText: 'payment_method'.tr),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              CourierDetailWidget(courier: ctr.orders?.courier),
              if (ctr.orders?.courier?.phone != null)
                AppUtils.kBoxHeight12,
              CheckWidget(
                isCheckout: true,
                isDelivery: ctr.orders?.deliveryType == 'delivery',
                deliveryPrice: ctr.orders?.deliveryType == 'delivery' ? controller.orders?.deliveryPrice ?? 0 : 0,
                products: controller.orders?.steps[0].products ?? [],
                generalSum: controller.getAllPrice,
                totalDiscountSum: controller.totalDiscountSum,
                discounts: controller.discountName,
              )
            ],
          ),
        ),
      ),
    );
  }
}
