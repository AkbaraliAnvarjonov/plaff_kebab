import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';

class ContainerStatusWidget extends StatelessWidget {
  final bool status;

  const ContainerStatusWidget({
    Key? key,
    this.status = true,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 2,
      decoration: BoxDecoration(
        color: status? AppColors.assets: AppColors.lightTestGrey,
      ),
    );
  }
}
