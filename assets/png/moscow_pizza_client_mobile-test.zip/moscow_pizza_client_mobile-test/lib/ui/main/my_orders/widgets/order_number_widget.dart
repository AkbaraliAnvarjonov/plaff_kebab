import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/image_network/custom_image_network.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class OrderNumberWidget extends StatelessWidget {
  final int orderAmount;
  final String orderNumber;
  final String date;

  const OrderNumberWidget({
    Key? key,
    required this.orderAmount,
    required this.orderNumber,
    required this.date,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        const Material(
          color: Colors.transparent,
          child: CustomImageNetwork(
            borderRadius: AppUtils.kBorderRadius12,
            height: 88,
            padding: EdgeInsets.symmetric(
              horizontal: 40,
              vertical: 8,
            ),
            backgroundColor: Colors.black12,
          ),
        ),
        Padding(
          padding: AppUtils.kLeftMargin12,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                "${'order'.tr} № $orderNumber",
                style:
                    styHistoryOrdersCategoryItemOrder.copyWith(color: AppColors.white),
              ),
             AppUtils.kBoxHeight2,
              Text(
                "${BaseFunctions.moneyFormat(orderAmount)} ${'sum'.tr}",
                style:
                    styHistoryOrdersCategoryItemSum.copyWith(color: AppColors.white),
              ),
              AppUtils.kBoxHeight2,
              Text(
                date,
                style:
                    styHistoryOrdersCategoryItemDate.copyWith(color: AppColors.white),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
