import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';

import '../../../../core/theme/app_utils.dart';

class ChooseReasonItemWidget extends StatelessWidget {
  final Function()? onTap;
  final String text;
  final bool checked;

  const ChooseReasonItemWidget({
    Key? key,
    this.onTap,
    required this.text,
    this.checked = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.white,
      child: InkWell(
        onTap: onTap,
        child: Ink(
          height: 55,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: AppUtils.kLeftMargin12,
                child: Text(
                  text,
                  style: styChooseReasonItemText,
                ),
              ),
              Visibility(
                visible: checked,
                child: const Padding(
                  padding: AppUtils.kAllPadding16,
                  child: Icon(
                    Icons.check_rounded,
                    color: AppColors.assets,
                    size: 24,
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
