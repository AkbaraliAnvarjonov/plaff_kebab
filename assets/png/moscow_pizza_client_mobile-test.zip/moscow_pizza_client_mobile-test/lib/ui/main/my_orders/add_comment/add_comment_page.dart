import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/add_comment_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/args/add_comment_page_arguments.dart';

class AddCommentPage extends GetView<AddCommentController> {
  const AddCommentPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var data = Get.arguments as AddCommentPageArguments;
    return GetBuilder<AddCommentController>(
      builder: (controller) {
        return Scaffold(
          appBar: AppBar(title: Text('add_comments'.tr)),
          body: ModalProgressHUD(
            inAsyncCall: controller.isLoading1,
            child: ListView(
              padding: AppUtils.kAllPadding12,
              physics: const BouncingScrollPhysics(),
              children: <Widget>[
                TextField(
                  maxLines: 10,
                  controller: controller.commentController,
                  onChanged: (v) {
                    if (controller.isError) controller.setError(false);
                  },
                  decoration: InputDecoration(
                    contentPadding: AppUtils.kHorizontal12Vertical14Padding,
                    filled: true,
                    hintText: 'add_comments'.tr,
                    fillColor: AppColors.white,
                    hintStyle: const TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w400,
                      color: AppColors.darkGrey,
                    ),
                    focusedBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.assets, width: 1),
                      borderRadius: AppUtils.kBorderRadius12,
                    ),
                    enabledBorder: const UnderlineInputBorder(
                      borderSide: BorderSide(
                        color: AppColors.white,
                        width: 1,
                      ),
                      borderRadius: AppUtils.kBorderRadius12,
                    ),
                    errorBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.red, width: 1),
                      borderRadius: AppUtils.kBorderRadius12,
                    ),
                    focusedErrorBorder: const OutlineInputBorder(
                      borderSide: BorderSide(color: AppColors.red, width: 1),
                      borderRadius: AppUtils.kBorderRadius12,
                    ),
                    errorText: controller.isError ? 'error'.tr : null,
                  ),
                )
              ],
            ),
          ),
          bottomNavigationBar: SafeArea(
            minimum: AppUtils.kAllPadding12,
            child: CustomButton(
              onTap: () async {
                HomeController ctr = Get.find<HomeController>();
                if (controller.commentController.text.trim().isNotEmpty) {
                  controller.setLoading1(true);
                  final result = await ctr.createUserReview(
                    data.order,
                    type: data.type,
                    message: controller.commentController.text.trim(),
                  );
                  controller.setLoading1(false);
                  if (result) Get.back(result: true);
                } else {
                  controller.setError(true);
                }
              },
              text: "send_message".tr,
            ),
          ),
        );
      },
    );
  }
}
