import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_icons.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:url_launcher/url_launcher.dart';

class CourierDetailWidget extends StatelessWidget {
  final Courier? courier;
  final bool? hasIcon;

  const CourierDetailWidget({
    Key? key,
    required this.courier,
    this.hasIcon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    if(courier?.phone == null) return AppUtils.kBox;
    return Material(
      borderRadius: AppUtils.kBorderRadius12,
      color: AppColors.white,
      child: InkWell(
        borderRadius: AppUtils.kBorderRadius12,
        onTap: courier?.phone == null
            ? null
            : () {
                if ((courier?.phone ?? '').isNotEmpty) {
                  launchUrl(
                    Uri(
                      scheme: 'tel',
                      path: courier?.phone ?? '',
                    ),
                  );
                }
              },
        child: Padding(
          padding: AppUtils.kHorizontal16Vertical12Padding,
          child: Row(
            children: <Widget>[
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                     Text(
                      'courier'.tr,
                      style: AppTextStyles.blackBoldText15,
                    ),
                    AppUtils.kBoxHeight4,
                    Text(
                      '${courier?.firstName ?? ''} ${courier?.lastName ?? ''}',
                      style: AppTextStyles.greyText15,
                    )
                  ],
                ),
              ),
              Ink(
                width: 48,
                height: 48,
                decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.background,
                ),
                child: const Icon(AppIcons.call),
              )
            ],
          ),
        ),
      ),
    );
  }
}
