import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/my_orders_controller.dart';
import 'current_orders/current_orders_page.dart';
import 'history_orders/history_orders_page.dart';
import 'widgets/custom_tab_bar.dart';

class MyOrdersPage extends GetView<MyOrdersController> {
  const MyOrdersPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('my_orders'.tr),
        centerTitle: true,
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(56),
          child: CustomTabBar(
            controller: controller.tabController,
            labels: ['current_orders'.tr, 'history_of_orders'.tr],
          ),
        ),
      ),
      body: TabBarView(
        controller: controller.tabController,
        children: const [
          CurrentOrdersPage(),
          HistoryOrdersPage(),
        ],
      ),
    );
  }
}
