import 'dart:async';

import 'package:moscow_pizza_client_mobile/base/base_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({Key? key}) : super(key: key);

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> with TickerProviderStateMixin {
  late final AnimationController _scaleController;
  late final AnimationController _opacityController;
  late final Animation<double> _scaleAnimation;
  late final Animation<double> _opacityAnimation;

  @override
  void initState() {
    super.initState();
    _scaleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..addListener(() {
        setState(() {});
      });
    _scaleAnimation = TweenSequence<double>([
      TweenSequenceItem<double>(
        tween: Tween<double>(begin: 1, end: 0.95),
        weight: 1,
      ),
      TweenSequenceItem<double>(
        tween: Tween<double>(begin: 0.95, end: 1.5),
        weight: 2,
      ),
    ]).animate(_scaleController);
    _opacityController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    )..addListener(() {
        setState(() {});
      });
    _opacityAnimation = CurveTween(curve: Curves.easeIn).animate(
      _opacityController,
    );
    _scaleController.forward();
    Future.delayed(
      const Duration(milliseconds: 1500),
      () {
        _opacityController.forward();
      },
    );
    Future.delayed(
      const Duration(milliseconds: 2000),
      () {
        if (LocalSource.instance.hasLocale) {
          Get.offAndToNamed(AppRoutes.language);
        } else {
          Get.offAndToNamed(AppRoutes.main);
        }
      },
    );
  }

  @override
  void dispose() {
    _scaleController.removeListener(() {});
    _opacityController.removeListener(() {});
    _scaleController.dispose();
    _opacityController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.white,
        statusBarBrightness: Brightness.light,
        statusBarIconBrightness: Brightness.dark,
        systemNavigationBarColor: Colors.white,
        systemNavigationBarIconBrightness: Brightness.dark,
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: Stack(
          children: [
            Positioned(
              left: 0,
              right: 0,
              bottom: 84,
              child: Center(
                child: FadeTransition(
                  opacity: AlwaysStoppedAnimation(
                    1 - _opacityAnimation.value,
                  ),
                  child: const CircularProgressIndicator(
                    color: AppColors.assets,
                  ),
                ),
              ),
            ),
            Positioned.fill(
              child: Center(
                child: Transform.scale(
                  scale: _scaleAnimation.value,
                  child: FadeTransition(
                    opacity: AlwaysStoppedAnimation(
                      1 - _opacityAnimation.value,
                    ),
                    child: const Image(
                      image: AssetImage(
                        'assets/png/moscowskaya_pizza.png',
                      ),
                      width: 180,
                      height: 180,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
