import 'dart:async';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';

class InternetConnectionPage extends StatefulWidget {
  const InternetConnectionPage({Key? key}) : super(key: key);

  @override
  InternetConnectionPageState createState() => InternetConnectionPageState();
}

class InternetConnectionPageState extends State<InternetConnectionPage> {
  bool _isLoading = false;
  final Connectivity _connectivity = Connectivity();
  late StreamSubscription<ConnectivityResult> _connectivitySubscription;

  @override
  void initState() {
    super.initState();
    _connectivitySubscription =
        _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
  }

  Future<void> _updateConnectionStatus(ConnectivityResult result) async {
    if (result != ConnectivityResult.none) {
      Get.back();
    }
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        backgroundColor: AppColors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.all(36),
              child: Image(
                image: const AssetImage('assets/png/ic_no_internet.png'),
                height: Get.height * 310 / 812,
                width: Get.width * 306 / 375,
              ),
            ),
            Text('internet_title'.tr, style: styNoInternetTitle),
            AppUtils.kBoxHeight12,
            Text(
              'internet_subtitle'.tr,
              style: styNoInternetSubTitle,
            ),
          ],
        ),
        bottomNavigationBar: SafeArea(
          minimum: AppUtils.kAllPadding12,
          child: CustomButton(
            onTap: () async {
              setState(() {
                _isLoading = true;
              });
              await Future.delayed(const Duration(milliseconds: 300));
              var connectivityResult = await Connectivity().checkConnectivity();
              setState(() {
                _isLoading = false;
              });
              if (connectivityResult != ConnectivityResult.none) {
                Get.back();
              }
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Visibility(
                  visible: _isLoading,
                  child: Padding(
                    padding: const EdgeInsets.only(left: 12),
                    child: Theme(
                      data: ThemeData(
                        cupertinoOverrideTheme: const CupertinoThemeData(
                          brightness: Brightness.dark,
                        ),
                      ),
                      child: const CircularProgressIndicator.adaptive(
                        valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Center(
                    child: Padding(
                      padding: EdgeInsets.only(right: _isLoading ? 36 : 0),
                      child: Text(
                        'try_again'.tr,
                        style: AppTextStyles.profileItemButtonText
                            .copyWith(color: AppColors.white),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
