import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/auth/auth_confirm_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/timer/count_down_timer_widget.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/timer/count_down_timer_controller.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:sms_autofill/sms_autofill.dart';

import '../../../routes/args/auth_confirm_page_arguments.dart';

class AuthConfirmPage extends GetView<AuthConfirmController> {
  const AuthConfirmPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var arguments = Get.arguments as AuthConfirmPageArguments;
    var timerController = Get.put(CountDownTimerController());
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: AppColors.white,
      body: GetBuilder<AuthConfirmController>(
        builder: (controller) {
          return Obx(
            () => ModalProgressHUD(
              inAsyncCall: controller.isLoading.value,
              child: SafeArea(
                minimum: AppUtils.kAllPadding16,
                child: Stack(
                  children: [
                    Positioned(
                      left: 0,
                      right: 0,
                      top: 0,
                      child: Text(
                        'confirmation_code'.tr,
                        style: AppTextStyles.appBarTitle,
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        PinFieldAutoFill(
                          enableInteractiveSelection: false,
                          inputFormatters: [
                            FilteringTextInputFormatter.allow(
                              RegExp('[0-9]'),
                            ),
                          ],
                          decoration: BoxLooseDecoration(
                            textStyle: const TextStyle(
                              fontSize: 20,
                              color: Colors.black,
                            ),
                            bgColorBuilder: controller.showErrorCode.value
                                ? const FixedColorBuilder(
                                    Color.fromRGBO(247, 102, 89, 0.03),
                                  )
                                : PinListenColorBuilder(
                                    AppColors.white,
                                    AppColors.grey300,
                                  ),
                            strokeColorBuilder: controller.showErrorCode.value
                                ? const FixedColorBuilder(AppColors.red)
                                : PinListenColorBuilder(
                                    AppColors.assets,
                                    Colors.transparent,
                                  ),
                          ),
                          currentCode: controller.currentCode,
                          autoFocus: true,
                          onCodeSubmitted: (code) {},
                          onCodeChanged: (code) async {
                            final result = await controller.changeCode(
                              code ?? '',
                              arguments.isLogin,
                              arguments.phone,
                            );
                            if (result) {
                              Get.back(result: true);
                            }
                          },
                        ),
                        AppUtils.kBoxHeight8,
                        Obx(
                          () => Visibility(
                            visible: controller.showErrorCode.value,
                            child: Text(
                              'error_code'.tr,
                              style: styConfirmCodeErrorText,
                            ),
                          ),
                        ),
                      ],
                    ),
                    Align(
                      alignment: Alignment.bottomCenter,
                      child: GetBuilder<AuthConfirmController>(
                        builder: (controller) => Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Obx(
                              () => CountDownTimerWidget(
                                onTap: () async {
                                  final result =
                                      await controller.resetCode(arguments);
                                  if (result) timerController.startTimer();
                                },
                                isDone: timerController.isDone.value,
                                text: timerController.timerText.value,
                              ),
                            ),
                            CustomButton(
                              text: 'proceed'.tr,
                              onTap: controller.isLoading.value
                                  ? null
                                  : () async {
                                      final result = await controller.checkCode(
                                        controller.currentCode,
                                        arguments.isLogin,
                                        arguments.phone,
                                        true,
                                      );
                                      if (result) {
                                        Get.back(result: true);
                                      }
                                    },
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
