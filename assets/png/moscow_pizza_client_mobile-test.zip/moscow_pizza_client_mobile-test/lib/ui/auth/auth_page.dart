import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/controller/auth/auth_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/home/home_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/main/main_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/my_orders/history_orders_controller.dart';
import 'package:moscow_pizza_client_mobile/controller/profile/profile_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/text_fields/custom_mask_text_field.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';

import '../../routes/args/auth_confirm_page_arguments.dart';
import '../../routes/args/register_page_arguments.dart';

class AuthPage extends GetView<AuthController> {
  const AuthPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: AppColors.white,
      body: Obx(
        () => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          child: SafeArea(
            minimum: AppUtils.kAllPadding16,
            child: Stack(
              children: [
                Positioned(
                  left: 0,
                  right: 0,
                  top: 0,
                  child: Text(
                    'phone_number'.tr,
                    style: AppTextStyles.appBarTitle,
                  ),
                ),
                Align(
                  child: CustomMaskTextField(
                    prefixText: '+998 ',
                    autoFocus: true,
                    labelText: 'phone_number'.tr,
                    errorText: 'login_failed'.tr,
                    controller: controller.phoneController,
                    showError: controller.phoneError.value,
                    onChanged: controller.changePhoneNumber,
                    keyboardType: TextInputType.number,
                    inputAction: TextInputAction.done,
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: GetBuilder<AuthController>(
                    builder: (controller) => CustomButton(
                      text: 'proceed'.tr,
                      onTap: controller.isLoading.value
                          ? null
                          : () async {
                              var result = await controller.checkCustomer();
                              if (result != null) {
                                if (result) {
                                  final result = await Get.toNamed(
                                    AppRoutes.authConfirm,
                                    arguments: AuthConfirmPageArguments(
                                      phone: controller.phone,
                                      isLogin: true,
                                      isProfile: BaseFunctions.isProfile,
                                    ),
                                  );
                                  checkResult(result);
                                } else {
                                  final result = await Get.toNamed(
                                    AppRoutes.register,
                                    arguments: RegisterPageArguments(
                                      phone: controller.phone,
                                      isProfile: BaseFunctions.isProfile,
                                    ),
                                  );
                                  checkResult(result);
                                }
                              }
                            },
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void checkResult(dynamic result) {
    if (result != null && result) {
      if (!BaseFunctions.isProfile) {
        Get.back();
        Get.find<MainController>().changeTabIndex(1);
      } else {
        Get.back(result: true);
      }
      Get.find<ProfileController>().getCustomers();
      Get.find<HomeController>().getMyAddress();
      Get.find<HistoryOrdersController>().getOrdersHistory();
    }
  }
}
