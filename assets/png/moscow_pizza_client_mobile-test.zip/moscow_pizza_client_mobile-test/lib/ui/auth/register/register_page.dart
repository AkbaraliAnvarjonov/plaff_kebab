import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moscow_pizza_client_mobile/controller/auth/register_controller.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/buttons/custom_button.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/modal_progress_hud.dart';
import 'package:moscow_pizza_client_mobile/core/custom_widgets/text_fields/custom_text_field.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_colors.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_text_style.dart';
import 'package:moscow_pizza_client_mobile/core/theme/app_utils.dart';
import 'package:moscow_pizza_client_mobile/routes/app_pages.dart';

import '../../../routes/args/auth_confirm_page_arguments.dart';
import '../../../routes/args/register_page_arguments.dart';

class RegisterPage extends GetView<RegisterController> {
  const RegisterPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var arguments = Get.arguments as RegisterPageArguments;
    return Scaffold(
      appBar: AppBar(),
      backgroundColor: AppColors.white,
      body: Obx(
        () => ModalProgressHUD(
          inAsyncCall: controller.isLoading.value,
          child: SafeArea(
            minimum: AppUtils.kAllPadding16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'first_name_last_name'.tr,
                  style: AppTextStyles.appBarTitle,
                ),
                const Spacer(),
                CustomTextField(
                  autoFocus: true,
                  labelText: 'first_name_last_name'.tr,
                  errorText: 'error_name'.tr,
                  onChanged: (value) => controller.changeName(value),
                  showError: controller.nameError.value,
                  hintText: 'enter_name'.tr,
                ),
                const Spacer(),
                GetBuilder<RegisterController>(
                  builder: (controller) => Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      CustomButton(
                        text: 'proceed'.tr,
                        onTap: controller.isLoading.value
                            ? null
                            : () async {
                                var result =
                                    await controller.register(arguments.phone);
                                if (result) {
                                  final result = await Get.toNamed(
                                    AppRoutes.authConfirm,
                                    arguments: AuthConfirmPageArguments(
                                      phone: arguments.phone,
                                      isProfile: arguments.isProfile,
                                      name: controller.name,
                                      tag: controller.tag,
                                    ),
                                  );
                                  if (result != null && result) {
                                    Get.back(result: true);
                                  }
                                }
                              },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
