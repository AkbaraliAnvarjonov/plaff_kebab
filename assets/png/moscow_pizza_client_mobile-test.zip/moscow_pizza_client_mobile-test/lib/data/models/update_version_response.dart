class UpdateVersionResponse {
  String? appName;
  String? iosVersion;
  String? androidVersion;
  bool? isForce;

  UpdateVersionResponse({
    this.appName,
    this.iosVersion,
    this.androidVersion,
    this.isForce,
  });

  UpdateVersionResponse.fromJson(Map<String, dynamic> json) {
    appName = json['app_name'];
    iosVersion = json['ios_version'];
    androidVersion = json['android_version'];
    isForce = json['is_force'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['app_name'] = appName;
    data['ios_version'] = iosVersion;
    data['android_version'] = androidVersion;
    data['is_force'] = isForce;
    return data;
  }
}
