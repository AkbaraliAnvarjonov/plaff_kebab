import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:dio/dio.dart';

class YandexHelper {
  YandexHelper(this.url);

  final String url;

  Future getData() async {
    final localSource = LocalSource.instance;
    Dio dio = Dio()
      ..options = BaseOptions(
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
      );
    Response response = await dio.get(url);
    if (response.statusCode == 200) {
      return response.data;
    } else if (response.statusCode == 403) {
      if (localSource.getYandexKey() == AppConstants.yandexApiKey) {
        await localSource.setYandexKey(AppConstants.yandexApiKey1);
      } else if (localSource.getYandexKey() == AppConstants.yandexApiKey1) {
        await localSource.setYandexKey(AppConstants.yandexApiKey2);
      } else {
        await localSource.setYandexKey(AppConstants.yandexApiKey);
      }
      return '';
    } else {
      return null;
    }
  }
}
