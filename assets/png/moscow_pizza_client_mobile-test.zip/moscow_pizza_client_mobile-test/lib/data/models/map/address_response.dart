class AddressResponse {
  Response? response;

  AddressResponse({this.response});

  AddressResponse.fromJson(Map<String, dynamic> json) {
    response = json['response'] != null
        ? Response.fromJson(json['response'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (response != null) {
      data['response'] = response?.toJson();
    }
    return data;
  }
}

class Response {
  GeoObjectCollection? geoObjectCollection;

  Response({this.geoObjectCollection});

  Response.fromJson(Map<String, dynamic> json) {
    geoObjectCollection = json['GeoObjectCollection'] != null
        ? GeoObjectCollection.fromJson(json['GeoObjectCollection'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (geoObjectCollection != null) {
      data['GeoObjectCollection'] = geoObjectCollection?.toJson();
    }
    return data;
  }
}

class GeoObjectCollection {
  MetaDataProperty? metaDataProperty;
  List<FeatureMember>? featureMember;

  GeoObjectCollection({this.metaDataProperty, this.featureMember});

  GeoObjectCollection.fromJson(Map<String, dynamic> json) {
    metaDataProperty = json['metaDataProperty'] != null
        ?  MetaDataProperty.fromJson(json['metaDataProperty'])
        : null;
    featureMember = [];
    if (json['featureMember'] != null) {
      json['featureMember'].forEach((v) {
        featureMember?.add( FeatureMember.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (metaDataProperty != null) {
      data['metaDataProperty'] = metaDataProperty?.toJson();
    }
    if (featureMember != null) {
      data['featureMember'] =
          featureMember?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class MetaDataProperty {
  GeocoderResponseMetaData? geocoderResponseMetaData;

  MetaDataProperty({this.geocoderResponseMetaData});

  MetaDataProperty.fromJson(Map<String, dynamic> json) {
    geocoderResponseMetaData = json['GeocoderResponseMetaData'] != null
        ?  GeocoderResponseMetaData.fromJson(
        json['GeocoderResponseMetaData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (geocoderResponseMetaData != null) {
      data['GeocoderResponseMetaData'] = geocoderResponseMetaData?.toJson();
    }
    return data;
  }
}

class GeocoderResponseMetaData {
  Pointy? point;
  String? request;
  String? results;
  String? found;

  GeocoderResponseMetaData(
      {this.point, this.request, this.results, this.found});

  GeocoderResponseMetaData.fromJson(Map<String, dynamic> json) {
    point = json['Point'] != null ?  Pointy.fromJson(json['Point']) : null;
    request = json['request'];
    results = json['results'];
    found = json['found'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (point != null) {
      data['Point'] = point?.toJson();
    }
    data['request'] = request;
    data['results'] = results;
    data['found'] = found;
    return data;
  }
}

class Pointy {
  String? pos;

  Pointy({this.pos});

  Pointy.fromJson(Map<String, dynamic> json) {
    pos = json['pos'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['pos'] = pos;
    return data;
  }
}

class FeatureMember {
  GeoObject? geoObject;

  FeatureMember({this.geoObject});

  FeatureMember.fromJson(Map<String, dynamic> json) {
    geoObject = json['GeoObject'] != null
        ?  GeoObject.fromJson(json['GeoObject'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (geoObject != null) {
      data['GeoObject'] = geoObject?.toJson();
    }
    return data;
  }
}

class GeoObject {
  MetaDataProperties? metaDataProperty;
  String? name;
  String? description;
  BoundedBy? boundedBy;
  Pointy? point;

  GeoObject(
      {this.metaDataProperty,
        this.name,
        this.description,
        this.boundedBy,
        this.point});

  GeoObject.fromJson(Map<String, dynamic> json) {
    metaDataProperty = json['metaDataProperty'] != null
        ?  MetaDataProperties.fromJson(json['metaDataProperty'])
        : null;
    name = json['name'];
    description = json['description'];
    boundedBy = json['boundedBy'] != null
        ?  BoundedBy.fromJson(json['boundedBy'])
        : null;
    point = json['Point'] != null ?  Pointy.fromJson(json['Point']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (metaDataProperty != null) {
      data['metaDataProperty'] = metaDataProperty?.toJson();
    }
    data['name'] = name;
    data['description'] = description;
    if (boundedBy != null) {
      data['boundedBy'] = boundedBy?.toJson();
    }
    if (point != null) {
      data['Point'] = point?.toJson();
    }
    return data;
  }
}

class MetaDataProperties {
  GeocoderMetaData? geocoderMetaData;

  MetaDataProperties({this.geocoderMetaData});

  MetaDataProperties.fromJson(Map<String, dynamic> json) {
    geocoderMetaData = json['GeocoderMetaData'] != null
        ? GeocoderMetaData.fromJson(json['GeocoderMetaData'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (geocoderMetaData != null) {
      data['GeocoderMetaData'] = geocoderMetaData?.toJson();
    }
    return data;
  }
}

class GeocoderMetaData {
  String? precision;
  String? text;
  String? kind;
  Address? address;
  AddressDetails? addressDetails;

  GeocoderMetaData(
      {this.precision,
        this.text,
        this.kind,
        this.address,
        this.addressDetails});

  GeocoderMetaData.fromJson(Map<String, dynamic> json) {
    precision = json['precision'];
    text = json['text'];
    kind = json['kind'];
    address =
    json['Address'] != null ?  Address.fromJson(json['Address']) : null;
    addressDetails = json['AddressDetails'] != null
        ?  AddressDetails.fromJson(json['AddressDetails'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['precision'] = precision;
    data['text'] = text;
    data['kind'] = kind;
    if (address != null) {
      data['Address'] = address?.toJson();
    }
    if (addressDetails != null) {
      data['AddressDetails'] = addressDetails?.toJson();
    }
    return data;
  }
}

class Address {
  String? countryCode;
  String? formatted;
  List<Components>? components;

  Address({this.countryCode, this.formatted, this.components});

  Address.fromJson(Map<String, dynamic> json) {
    countryCode = json['country_code'];
    formatted = json['formatted'];
    components = [];
    if (json['Components'] != null) {
      json['Components'].forEach((v) {
        components?.add( Components.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['country_code'] = countryCode;
    data['formatted'] = formatted;
    if (components != null) {
      data['Components'] = components?.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Components {
  String? kind;
  String? name;

  Components({this.kind, this.name});

  Components.fromJson(Map<String, dynamic> json) {
    kind = json['kind'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['kind'] = kind;
    data['name'] = name;
    return data;
  }
}

class AddressDetails {
  Country? country;

  AddressDetails({this.country});

  AddressDetails.fromJson(Map<String, dynamic> json) {
    country =
    json['Country'] != null ?  Country.fromJson(json['Country']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (country != null) {
      data['Country'] = country?.toJson();
    }
    return data;
  }
}

class Country {
  String? addressLine;
  String? countryNameCode;
  String? countryName;
  AdministrativeArea? administrativeArea;

  Country(
      {this.addressLine,
        this.countryNameCode,
        this.countryName,
        this.administrativeArea});

  Country.fromJson(Map<String, dynamic> json) {
    addressLine = json['AddressLine'];
    countryNameCode = json['CountryNameCode'];
    countryName = json['CountryName'];
    administrativeArea = json['AdministrativeArea'] != null
        ?  AdministrativeArea.fromJson(json['AdministrativeArea'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['AddressLine'] = addressLine;
    data['CountryNameCode'] = countryNameCode;
    data['CountryName'] = countryName;
    if (administrativeArea != null) {
      data['AdministrativeArea'] = administrativeArea?.toJson();
    }
    return data;
  }
}

class AdministrativeArea {
  String? administrativeAreaName;
  Locality? locality;

  AdministrativeArea({this.administrativeAreaName, this.locality});

  AdministrativeArea.fromJson(Map<String, dynamic> json) {
    administrativeAreaName = json['AdministrativeAreaName'];
    locality = json['Locality'] != null
        ?  Locality.fromJson(json['Locality'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['AdministrativeAreaName'] = administrativeAreaName;
    if (locality != null) {
      data['Locality'] = locality?.toJson();
    }
    return data;
  }
}

class Locality {
  String? localityName;
  DependentLocality? dependentLocality;

  Locality({this.localityName, this.dependentLocality});

  Locality.fromJson(Map<String, dynamic> json) {
    localityName = json['LocalityName'];
    dependentLocality = json['DependentLocality'] != null
        ?  DependentLocality.fromJson(json['DependentLocality'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['LocalityName'] = localityName;
    if (dependentLocality != null) {
      data['DependentLocality'] = dependentLocality?.toJson();
    }
    return data;
  }
}

class DependentLocality {
  String? dependentLocalityName;
  DependentLocality? dependentLocality;
  Premise? premise;

  DependentLocality(
      { this.dependentLocalityName, this.dependentLocality, this.premise});

  DependentLocality.fromJson(Map<String, dynamic> json) {
    dependentLocalityName = json['DependentLocalityName'];
    dependentLocality = json['DependentLocality'] != null
        ?  DependentLocality.fromJson(json['DependentLocality'])
        : null;
    premise =
    json['Premise'] != null ?  Premise.fromJson(json['Premise']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['DependentLocalityName'] = dependentLocalityName;
    if (dependentLocality != null) {
      data['DependentLocality'] = dependentLocality?.toJson();
    }
    if (premise != null) {
      data['Premise'] = premise?.toJson();
    }
    return data;
  }
}

class DependentLocalities {
  String? dependentLocalityName;
  Premise? premise;

  DependentLocalities({this.dependentLocalityName, this.premise});

  DependentLocalities.fromJson(Map<String, dynamic> json) {
    dependentLocalityName = json['DependentLocalityName'];
    premise =
    json['Premise'] != null ?  Premise.fromJson(json['Premise']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['DependentLocalityName'] = dependentLocalityName;
    if (premise != null) {
      data['Premise'] = premise?.toJson();
    }
    return data;
  }
}

class Premise {
  String? premiseNumber;

  Premise({this.premiseNumber});

  Premise.fromJson(Map<String, dynamic> json) {
    premiseNumber = json['PremiseNumber'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['PremiseNumber'] = premiseNumber;
    return data;
  }
}

class BoundedBy {
  Envelope? envelope;

  BoundedBy({this.envelope});

  BoundedBy.fromJson(Map<String, dynamic> json) {
    envelope = json['Envelope'] != null
        ?  Envelope.fromJson(json['Envelope'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    if (envelope != null) {
      data['Envelope'] = envelope?.toJson();
    }
    return data;
  }
}

class Envelope {
  String? lowerCorner;
  String? upperCorner;

  Envelope({this.lowerCorner, this.upperCorner});

  Envelope.fromJson(Map<String, dynamic> json) {
    lowerCorner = json['lowerCorner'];
    upperCorner = json['upperCorner'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['lowerCorner'] = lowerCorner;
    data['upperCorner'] = upperCorner;
    return data;
  }
}
