class ComputePriceRequest {
  String? branchId;
  double? lat;
  double? long;
  double? orderPrice;

  ComputePriceRequest({this.branchId, this.lat, this.long, this.orderPrice});

  ComputePriceRequest.fromJson(Map<String, dynamic> json) {
    branchId = json['branch_id'];
    lat = json['lat'];
    long = json['long'];
    orderPrice = json['order_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['branch_id'] = branchId;
    data['lat'] = lat;
    data['long'] = long;
    data['order_price'] = orderPrice;
    return data;
  }
}
