class UserReviewsRequest {
  String? branchId;
  String? branchName;
  String? clientId;
  String? clientName;
  String? clientPhone;
  String? courierId;
  String? courierName;
  String? id;
  String? lang;
  String? operatorId;
  String? operatorName;
  String? orderNum;
  String? relatedSubject;
  String? reviewId;
  String? reviewMessage;
  String? type;

  UserReviewsRequest({
    this.branchId,
    this.branchName,
    this.clientId,
    this.clientName,
    this.clientPhone,
    this.courierId,
    this.courierName,
    this.id,
    this.lang,
    this.operatorId,
    this.operatorName,
    this.orderNum,
    this.relatedSubject,
    this.reviewId,
    this.reviewMessage,
    this.type,
  });

  UserReviewsRequest.fromJson(Map<String, dynamic> json) {
    branchId = json['branch_id'];
    branchName = json['branch_name'];
    clientId = json['client_id'];
    clientName = json['client_name'];
    clientPhone = json['client_phone'];
    courierId = json['courier_id'];
    courierName = json['courier_name'];
    id = json['id'];
    lang = json['lang'];
    operatorId = json['operator_id'];
    operatorName = json['operator_name'];
    orderNum = json['order_num'];
    relatedSubject = json['related_subject'];
    reviewId = json['review_id'];
    reviewMessage = json['review_message'];
    type = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['branch_id'] = branchId;
    data['branch_name'] = branchName;
    data['client_id'] = clientId;
    data['client_name'] = clientName;
    data['client_phone'] = clientPhone;
    data['courier_id'] = courierId;
    data['courier_name'] = courierName;
    data['id'] = id;
    data['lang'] = lang;
    data['operator_id'] = operatorId;
    data['operator_name'] = operatorName;
    data['order_num'] = orderNum;
    data['related_subject'] = relatedSubject;
    data['review_id'] = reviewId;
    data['review_message'] = reviewMessage;
    data['type'] = type;
    return data;
  }
}
