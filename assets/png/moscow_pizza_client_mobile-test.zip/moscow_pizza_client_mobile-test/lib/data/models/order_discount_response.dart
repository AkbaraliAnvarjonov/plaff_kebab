import 'package:moscow_pizza_client_mobile/data/models/discount_with_order_price_response.dart';

class OrderDiscountResponse {
  List<OrderDiscounts>? discounts;
  num? allDiscountPrice;

  OrderDiscountResponse({this.discounts, this.allDiscountPrice});

  OrderDiscountResponse.fromJson(Map<String, dynamic> json) {
    if (json['discounts'] != null) {
      discounts = <OrderDiscounts>[];
      json['discounts'].forEach((v) {
        discounts!.add(OrderDiscounts.fromJson(v));
      });
    }
    allDiscountPrice = json['all_discount_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (discounts != null) {
      data['discounts'] = discounts!.map((v) => v.toJson()).toList();
    }
    data['all_discount_price'] = allDiscountPrice;
    return data;
  }
}

class OrderDiscounts {
  DiscountTitle? discountTitle;
  String? discountId;
  String? discountMode;
  num? discountAmount;
  num? discountPriceForOrder;
  String? discountType;

  OrderDiscounts(
      {this.discountTitle,
      this.discountId,
      this.discountMode,
      this.discountAmount,
      this.discountPriceForOrder,
      this.discountType});

  OrderDiscounts.fromJson(Map<String, dynamic> json) {
    discountTitle = json['discount_title'] != null
        ? DiscountTitle.fromJson(json['discount_title'])
        : null;
    discountId = json['discount_id'];
    discountMode = json['discount_mode'];
    discountAmount = json['discount_amount'];
    discountPriceForOrder = json['discount_price_for_order'];
    discountType = json['discount_type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (discountTitle != null) {
      data['discount_title'] = discountTitle!.toJson();
    }
    data['discount_id'] = discountId;
    data['discount_mode'] = discountMode;
    data['discount_amount'] = discountAmount;
    data['discount_price_for_order'] = discountPriceForOrder;
    data['discount_type'] = discountType;
    return data;
  }
}
