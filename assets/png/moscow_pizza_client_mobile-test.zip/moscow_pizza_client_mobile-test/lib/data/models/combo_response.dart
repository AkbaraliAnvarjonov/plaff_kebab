import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';

class ComboResponse {
  List<Groups>? groups;

  ComboResponse({this.groups});

  ComboResponse.fromJson(Map<String, dynamic> json) {
    if (json['groups'] != null) {
      groups = <Groups>[];
      json['groups'].forEach((v) {
        groups!.add(Groups.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (groups != null) {
      data['groups'] = groups!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Groups {
  String? comboId;
  String? id;
  int? order;
  int? quantity;
  String? shipperId;
  String? slug;
  Title? title;
  String? type;
  List<Variants>? variants;
  int? selectedIndex = 0;
  Groups(
      {
        this.selectedIndex,
        this.comboId,
        this.id,
        this.order,
        this.quantity,
        this.shipperId,
        this.slug,
        this.title,
        this.type,
        this.variants});

  Groups.fromJson(Map<String, dynamic> json) {
    comboId = json['combo_id'];
    id = json['id'];
    order = json['order'];
    quantity = json['quantity'];
    shipperId = json['shipper_id'];
    slug = json['slug'];
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
    type = json['type'];
    if (json['variants'] != null) {
      variants = <Variants>[];
      json['variants'].forEach((v) {
        variants!.add( Variants.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['combo_id'] = comboId;
    data['id'] = id;
    data['order'] = order;
    data['quantity'] = quantity;
    data['shipper_id'] = shipperId;
    data['slug'] = slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    data['type'] = type;
    if (variants != null) {
      data['variants'] = variants!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Variants {
  bool? active;
  Brand? brand;
  List<Categories>? categories;
  String? code;
  String? count;
  String? createdAt;
  String? currency;
  Title? description;
  List<Favourites>? favourites;
  List<String>? gallery;
  bool? hasModifier;
  String? id;
  String? iikoId;
  String? image;
  int? inPrice;
  bool? isDivisible;
  String? jowiId;
  Measurement? measurement;
  String? order;
  int? outPrice;
  String? parentId;
  List<PriceChangers>? priceChangers;
  List<ProductProperty>? productProperty;
  List<Properties>? properties;
  Rate? rate;
  String? shipperId;
  String? slug;
  List<Tags>? tags;
  Title? title;
  String? type;
  List<VariantProducts>? variantProducts;
  Variants(
      {
        this.active,
        this.brand,
        this.categories,
        this.code,
        this.count,
        this.createdAt,
        this.currency,
        this.description,
        this.favourites,
        this.gallery,
        this.hasModifier,
        this.id,
        this.iikoId,
        this.image,
        this.inPrice,
        this.isDivisible,
        this.jowiId,
        this.measurement,
        this.order,
        this.outPrice,
        this.parentId,
        this.priceChangers,
        this.productProperty,
        this.properties,
        this.rate,
        this.shipperId,
        this.slug,
        this.tags,
        this.title,
        this.type,
        this.variantProducts});

  Variants.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    brand = json['brand'] != null ? Brand.fromJson(json['brand']) : null;
    if (json['categories'] != null) {
      categories = <Categories>[];
      json['categories'].forEach((v) {
        categories!.add(Categories.fromJson(v));
      });
    }
    code = json['code'];
    count = json['count'];
    createdAt = json['created_at'];
    currency = json['currency'];
    description = json['description'] != null
        ? Title.fromJson(json['description'])
        : null;
    if (json['favourites'] != null) {
      favourites = <Favourites>[];
      json['favourites'].forEach((v) {
        favourites!.add(Favourites.fromJson(v));
      });
    }
    gallery = json['gallery'].cast<String>();
    hasModifier = json['has_modifier'];
    id = json['id'];
    iikoId = json['iiko_id'];
    image = json['image'];
    inPrice = json['in_price'];
    isDivisible = json['is_divisible'];
    jowiId = json['jowi_id'];
    measurement = json['measurement'] != null
        ? Measurement.fromJson(json['measurement'])
        : null;
    order = json['order'];
    outPrice = json['out_price'];
    parentId = json['parent_id'];
    if (json['price_changers'] != null) {
      priceChangers = <PriceChangers>[];
      json['price_changers'].forEach((v) {
        priceChangers!.add( PriceChangers.fromJson(v));
      });
    }
    if (json['product_property'] != null) {
      productProperty = <ProductProperty>[];
      json['product_property'].forEach((v) {
        productProperty!.add(ProductProperty.fromJson(v));
      });
    }
    if (json['properties'] != null) {
      properties = <Properties>[];
      json['properties'].forEach((v) {
        properties!.add(Properties.fromJson(v));
      });
    }
    rate = json['rate'] != null ? Rate.fromJson(json['rate']) : null;
    shipperId = json['shipper_id'];
    slug = json['slug'];
    if (json['tags'] != null) {
      tags = <Tags>[];
      json['tags'].forEach((v) {
        tags!.add(Tags.fromJson(v));
      });
    }
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
    type = json['type'];
    if (json['variant_products'] != null) {
      variantProducts = <VariantProducts>[];
      json['variant_products'].forEach((v) {
        variantProducts!.add(VariantProducts.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['active'] = active;
    if (brand != null) {
      data['brand'] = brand!.toJson();
    }
    if (categories != null) {
      data['categories'] = categories!.map((v) => v.toJson()).toList();
    }
    data['code'] = code;
    data['count'] = count;
    data['created_at'] = createdAt;
    data['currency'] = currency;
    if (description != null) {
      data['description'] = description!.toJson();
    }
    if (favourites != null) {
      data['favourites'] = favourites!.map((v) => v.toJson()).toList();
    }
    data['gallery'] = gallery;
    data['has_modifier'] = hasModifier;
    data['id'] = id;
    data['iiko_id'] = iikoId;
    data['image'] = image;
    data['in_price'] = inPrice;
    data['is_divisible'] = isDivisible;
    data['jowi_id'] = jowiId;
    if (measurement != null) {
      data['measurement'] = measurement!.toJson();
    }
    data['order'] = order;
    data['out_price'] = outPrice;
    data['parent_id'] = parentId;
    if (priceChangers != null) {
      data['price_changers'] = priceChangers!.map((v) => v.toJson()).toList();
    }
    if (productProperty != null) {
      data['product_property'] =
          productProperty!.map((v) => v.toJson()).toList();
    }
    if (properties != null) {
      data['properties'] = properties!.map((v) => v.toJson()).toList();
    }
    if (rate != null) {
      data['rate'] = rate!.toJson();
    }
    data['shipper_id'] = shipperId;
    data['slug'] = slug;
    if (tags != null) {
      data['tags'] = tags!.map((v) => v.toJson()).toList();
    }
    if (title != null) {
      data['title'] = title!.toJson();
    }
    data['type'] = type;
    if (variantProducts != null) {
      data['variant_products'] =
          variantProducts!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class PriceChangers {
  String? amount;
  String? base;
  String? changeType;
  String? id;
  String? slug;
  Title? title;

  PriceChangers(
      {this.amount,
        this.base,
        this.changeType,
        this.id,
        this.slug,
        this.title});

  PriceChangers.fromJson(Map<String, dynamic> json) {
    amount = json['amount'];
    base = json['base'];
    changeType = json['change_type'];
    id = json['id'];
    slug = json['slug'];
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['amount'] =amount;
    data['base'] = base;
    data['change_type'] = changeType;
    data['id'] = id;
    data['slug'] = slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}

class Properties {
  bool? active;
  String? createdAt;
  Title? description;
  String? id;
  List<Options>? options;
  int? orderNo;
  String? shipperId;
  String? slug;
  Title? title;

  Properties(
      {this.active,
        this.createdAt,
        this.description,
        this.id,
        this.options,
        this.orderNo,
        this.shipperId,
        this.slug,
        this.title});

  Properties.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    createdAt = json['created_at'];
    description = json['description'] != null
        ? Title.fromJson(json['description'])
        : null;
    id = json['id'];
    if (json['options'] != null) {
      options = <Options>[];
      json['options'].forEach((v) {
        options!.add(Options.fromJson(v));
      });
    }
    orderNo = json['order_no'];
    shipperId = json['shipper_id'];
    slug = json['slug'];
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['active'] = active;
    data['created_at'] = createdAt;
    if (description != null) {
      data['description'] = description!.toJson();
    }
    data['id'] = id;
    if (options != null) {
      data['options'] = options!.map((v) => v.toJson()).toList();
    }
    data['order_no'] = orderNo;
    data['shipper_id'] = shipperId;
    data['slug'] =slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}

class ComOptions {
  String? id;
  Title? title;

  ComOptions({this.id, this.title});

  ComOptions.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}

class Rate {
  String? code;
  String? createdAt;
  String? id;
  int? rateAmount;
  String? shipperId;
  String? slug;
  String? title;

  Rate(
      {this.code,
        this.createdAt,
        this.id,
        this.rateAmount,
        this.shipperId,
        this.slug,
        this.title});

  Rate.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    createdAt = json['created_at'];
    id = json['id'];
    rateAmount = json['rate_amount'];
    shipperId = json['shipper_id'];
    slug = json['slug'];
    title = json['title'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['code'] = code;
    data['created_at'] = createdAt;
    data['id'] = id;
    data['rate_amount'] = rateAmount;
    data['shipper_id'] = shipperId;
    data['slug'] = slug;
    data['title'] = title;
    return data;
  }
}

class Tags {
  String? color;
  String? createdAt;
  String? icon;
  String? id;
  String? shipperId;
  String? slug;
  Title? title;

  Tags(
      {this.color,
        this.createdAt,
        this.icon,
        this.id,
        this.shipperId,
        this.slug,
        this.title});

  Tags.fromJson(Map<String, dynamic> json) {
    color = json['color'];
    createdAt = json['created_at'];
    icon = json['icon'];
    id = json['id'];
    shipperId = json['shipper_id'];
    slug = json['slug'];
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['color'] = color;
    data['created_at'] = createdAt;
    data['icon'] = icon;
    data['id'] = id;
    data['shipper_id'] = shipperId;
    data['slug'] = slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}




// import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
//
// import 'modifier_response.dart';
//
// class ComboResponse {
//   List<Products>? products;
//
//   ComboResponse({this.products});
//
//   ComboResponse.fromJson(Map<String, dynamic> json) {
//     if (json['products'] != null) {
//       products = <Products>[];
//       json['products'].forEach((v) {
//         products!.add(new Products.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.products != null) {
//       data['products'] = this.products!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Products {
//   String? comboId;
//   String? id;
//   int? order;
//   Product? product;
//   String? shipperId;
//   String? slug;
//   String? type;
//   List<Variants>? variants;
//   int? quantity;
//   int? selectedIndex = 0;
//
//   Products({
//     this.comboId,
//     this.id,
//     this.order,
//     this.product,
//     this.shipperId,
//     this.slug,
//     this.type,
//     this.variants,
//     this.selectedIndex,
//     this.quantity,
//   });
//
//   Products.fromJson(Map<String, dynamic> json) {
//     comboId = json['combo_id'];
//     id = json['id'];
//     order = json['order'];
//     product =
//         json['product'] != null ? new Product.fromJson(json['product']) : null;
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     type = json['type'];
//     if (json['variants'] != null) {
//       variants = <Variants>[];
//       json['variants'].forEach((v) {
//         variants!.add(new Variants.fromJson(v));
//       });
//     }
//     quantity = json['quantity'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['combo_id'] = this.comboId;
//     data['id'] = id;
//     data['order'] = order;
//     if (product != null) {
//       data['product'] = product!.toJson();
//     }
//     data['shipper_id'] = shipperId;
//     data['slug'] = slug;
//     data['type'] = type;
//     if (variants != null) {
//       data['variants'] = variants!.map((v) => v.toJson()).toList();
//     }
//     data['quantity'] = quantity;
//     return data;
//   }
// }
//
// class Product {
//   bool? active;
//   Brand? brand;
//   List<Categories>? categories;
//   String? code;
//   String? count;
//   String? createdAt;
//   String? currency;
//   Title? description;
//   List<Favourites>? favourites;
//   List<String>? gallery;
//   bool? hasModifier;
//   String? id;
//   String? iikoId;
//   String? image;
//   int? inPrice;
//   bool? isDivisible;
//   String? jowiId;
//   Measurement? measurement;
//   int? order;
//   int? outPrice;
//   String? parentId;
//   List<PriceChangers>? priceChangers;
//   List<ProductProperty>? productProperty;
//   List<Properties>? properties;
//   Rate? rate;
//   String? shipperId;
//   String? slug;
//   List<Tags>? tags;
//   Title? title;
//   String? type;
//   List<VariantProducts>? variantProducts;
//
//   Product(
//       {this.active,
//       this.brand,
//       this.categories,
//       this.code,
//       this.count,
//       this.createdAt,
//       this.currency,
//       this.description,
//       this.favourites,
//       this.gallery,
//       this.hasModifier,
//       this.id,
//       this.iikoId,
//       this.image,
//       this.inPrice,
//       this.isDivisible,
//       this.jowiId,
//       this.measurement,
//       this.order,
//       this.outPrice,
//       this.parentId,
//       this.priceChangers,
//       this.productProperty,
//       this.properties,
//       this.rate,
//       this.shipperId,
//       this.slug,
//       this.tags,
//       this.title,
//       this.type,
//       this.variantProducts});
//
//   Product.fromJson(Map<String, dynamic> json) {
//     active = json['active'];
//     brand = json['brand'] != null ? new Brand.fromJson(json['brand']) : null;
//     if (json['categories'] != null) {
//       categories = <Categories>[];
//       json['categories'].forEach((v) {
//         categories!.add(new Categories.fromJson(v));
//       });
//     }
//     code = json['code'];
//     count = json['count'];
//     createdAt = json['created_at'];
//     currency = json['currency'];
//     description = json['description'] != null
//         ? new Title.fromJson(json['description'])
//         : null;
//     if (json['favourites'] != null) {
//       favourites = <Favourites>[];
//       json['favourites'].forEach((v) {
//         favourites!.add(new Favourites.fromJson(v));
//       });
//     }
//     gallery = json['gallery'].cast<String>();
//     hasModifier = json['has_modifier'];
//     id = json['id'];
//     iikoId = json['iiko_id'];
//     image = json['image'];
//     inPrice = json['in_price'];
//     isDivisible = json['is_divisible'];
//     jowiId = json['jowi_id'];
//     measurement = json['measurement'] != null
//         ? new Measurement.fromJson(json['measurement'])
//         : null;
//     order = int.tryParse(json['order'].toString());
//     outPrice = json['out_price'];
//     parentId = json['parent_id'];
//     if (json['price_changers'] != null) {
//       priceChangers = <PriceChangers>[];
//       json['price_changers'].forEach((v) {
//         priceChangers!.add(new PriceChangers.fromJson(v));
//       });
//     }
//     if (json['product_property'] != null) {
//       productProperty = <ProductProperty>[];
//       json['product_property'].forEach((v) {
//         productProperty!.add(new ProductProperty.fromJson(v));
//       });
//     }
//     if (json['properties'] != null) {
//       properties = <Properties>[];
//       json['properties'].forEach((v) {
//         properties!.add(new Properties.fromJson(v));
//       });
//     }
//     rate = json['rate'] != null ? new Rate.fromJson(json['rate']) : null;
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     if (json['tags'] != null) {
//       tags = <Tags>[];
//       json['tags'].forEach((v) {
//         tags!.add(new Tags.fromJson(v));
//       });
//     }
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//     type = json['type'];
//     if (json['variant_products'] != null) {
//       variantProducts = <VariantProducts>[];
//       json['variant_products'].forEach((v) {
//         variantProducts!.add(new VariantProducts.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['active'] = this.active;
//     if (this.brand != null) {
//       data['brand'] = this.brand!.toJson();
//     }
//     if (this.categories != null) {
//       data['categories'] = this.categories!.map((v) => v.toJson()).toList();
//     }
//     data['code'] = this.code;
//     data['count'] = this.count;
//     data['created_at'] = this.createdAt;
//     data['currency'] = this.currency;
//     if (this.description != null) {
//       data['description'] = this.description!.toJson();
//     }
//     if (this.favourites != null) {
//       data['favourites'] = this.favourites!.map((v) => v.toJson()).toList();
//     }
//     data['gallery'] = this.gallery;
//     data['has_modifier'] = this.hasModifier;
//     data['id'] = this.id;
//     data['iiko_id'] = this.iikoId;
//     data['image'] = this.image;
//     data['in_price'] = this.inPrice;
//     data['is_divisible'] = this.isDivisible;
//     data['jowi_id'] = this.jowiId;
//     if (this.measurement != null) {
//       data['measurement'] = this.measurement!.toJson();
//     }
//     data['order'] = this.order;
//     data['out_price'] = this.outPrice;
//     data['parent_id'] = this.parentId;
//     if (this.priceChangers != null) {
//       data['price_changers'] =
//           this.priceChangers!.map((v) => v.toJson()).toList();
//     }
//     if (this.productProperty != null) {
//       data['product_property'] =
//           this.productProperty!.map((v) => v.toJson()).toList();
//     }
//     if (this.properties != null) {
//       data['properties'] = this.properties!.map((v) => v.toJson()).toList();
//     }
//     if (this.rate != null) {
//       data['rate'] = this.rate!.toJson();
//     }
//     data['shipper_id'] = this.shipperId;
//     data['slug'] = this.slug;
//     if (this.tags != null) {
//       data['tags'] = this.tags!.map((v) => v.toJson()).toList();
//     }
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     data['type'] = this.type;
//     if (this.variantProducts != null) {
//       data['variant_products'] =
//           this.variantProducts!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Brand {
//   Title? description;
//   String? id;
//   String? image;
//   bool? isActive;
//   String? orderNo;
//   String? parentId;
//   String? slug;
//   Title? title;
//
//   Brand(
//       {this.description,
//       this.id,
//       this.image,
//       this.isActive,
//       this.orderNo,
//       this.parentId,
//       this.slug,
//       this.title});
//
//   Brand.fromJson(Map<String, dynamic> json) {
//     description = json['description'] != null
//         ? new Title.fromJson(json['description'])
//         : null;
//     id = json['id'];
//     image = json['image'];
//     isActive = json['is_active'];
//     orderNo = json['order_no'];
//     parentId = json['parent_id'];
//     slug = json['slug'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     if (this.description != null) {
//       data['description'] = this.description!.toJson();
//     }
//     data['id'] = this.id;
//     data['image'] = this.image;
//     data['is_active'] = this.isActive;
//     data['order_no'] = this.orderNo;
//     data['parent_id'] = this.parentId;
//     data['slug'] = this.slug;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class Categories {
//   bool? active;
//   String? createdAt;
//   Title? description;
//   String? id;
//   String? iikoId;
//   String? image;
//   String? jowiId;
//   int? orderNo;
//   String? parentId;
//   List<String>? propertyIds;
//   String? shipperId;
//   String? slug;
//   Title? title;
//
//   Categories(
//       {this.active,
//       this.createdAt,
//       this.description,
//       this.id,
//       this.iikoId,
//       this.image,
//       this.jowiId,
//       this.orderNo,
//       this.parentId,
//       this.propertyIds,
//       this.shipperId,
//       this.slug,
//       this.title});
//
//   Categories.fromJson(Map<String, dynamic> json) {
//     active = json['active'];
//     createdAt = json['created_at'];
//     description = json['description'] != null
//         ? new Title.fromJson(json['description'])
//         : null;
//     id = json['id'];
//     iikoId = json['iiko_id'];
//     image = json['image'];
//     jowiId = json['jowi_id'];
//     orderNo = json['order_no'];
//     parentId = json['parent_id'];
//     propertyIds = json['property_ids'].cast<String>();
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['active'] = this.active;
//     data['created_at'] = this.createdAt;
//     if (this.description != null) {
//       data['description'] = this.description!.toJson();
//     }
//     data['id'] = this.id;
//     data['iiko_id'] = this.iikoId;
//     data['image'] = this.image;
//     data['jowi_id'] = this.jowiId;
//     data['order_no'] = this.orderNo;
//     data['parent_id'] = this.parentId;
//     data['property_ids'] = this.propertyIds;
//     data['shipper_id'] = this.shipperId;
//     data['slug'] = this.slug;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class Favourites {
//   bool? active;
//   String? brand;
//   List<String>? categories;
//   String? code;
//   int? count;
//   String? createdAt;
//   String? currency;
//   Title? description;
//   List<String>? favourites;
//   List<String>? gallery;
//   bool? hasModifier;
//   String? id;
//   String? iikoId;
//   String? image;
//   int? inPrice;
//   bool? isDivisible;
//   String? jowiId;
//   String? measurementId;
//   int? order;
//   int? outPrice;
//   String? parentId;
//   List<String>? priceChangers;
//   List<ProductProperty>? productProperty;
//   List<String>? propertyIds;
//   String? rateId;
//   String? relationType;
//   String? shipperId;
//   String? slug;
//   List<String>? tags;
//   Title? title;
//   String? type;
//
//   Favourites(
//       {this.active,
//       this.brand,
//       this.categories,
//       this.code,
//       this.count,
//       this.createdAt,
//       this.currency,
//       this.description,
//       this.favourites,
//       this.gallery,
//       this.hasModifier,
//       this.id,
//       this.iikoId,
//       this.image,
//       this.inPrice,
//       this.isDivisible,
//       this.jowiId,
//       this.measurementId,
//       this.order,
//       this.outPrice,
//       this.parentId,
//       this.priceChangers,
//       this.productProperty,
//       this.propertyIds,
//       this.rateId,
//       this.relationType,
//       this.shipperId,
//       this.slug,
//       this.tags,
//       this.title,
//       this.type});
//
//   Favourites.fromJson(Map<String, dynamic> json) {
//     active = json['active'];
//     brand = json['brand'];
//     categories = json['categories'].cast<String>();
//     code = json['code'];
//     count = json['count'];
//     createdAt = json['created_at'];
//     currency = json['currency'];
//     description = json['description'] != null
//         ? new Title.fromJson(json['description'])
//         : null;
//     favourites = json['favourites'].cast<String>();
//     gallery = json['gallery'].cast<String>();
//     hasModifier = json['has_modifier'];
//     id = json['id'];
//     iikoId = json['iiko_id'];
//     image = json['image'];
//     inPrice = json['in_price'];
//     isDivisible = json['is_divisible'];
//     jowiId = json['jowi_id'];
//     measurementId = json['measurement_id'];
//     order = json['order'];
//     outPrice = json['out_price'];
//     parentId = json['parent_id'];
//     priceChangers = json['price_changers'].cast<String>();
//     if (json['product_property'] != null) {
//       productProperty = <ProductProperty>[];
//       json['product_property'].forEach((v) {
//         productProperty!.add(new ProductProperty.fromJson(v));
//       });
//     }
//     propertyIds = json['property_ids'].cast<String>();
//     rateId = json['rate_id'];
//     relationType = json['relation_type'];
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     tags = json['tags'].cast<String>();
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//     type = json['type'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['active'] = this.active;
//     data['brand'] = this.brand;
//     data['categories'] = this.categories;
//     data['code'] = this.code;
//     data['count'] = this.count;
//     data['created_at'] = this.createdAt;
//     data['currency'] = this.currency;
//     if (this.description != null) {
//       data['description'] = this.description!.toJson();
//     }
//     data['favourites'] = this.favourites;
//     data['gallery'] = this.gallery;
//     data['has_modifier'] = this.hasModifier;
//     data['id'] = this.id;
//     data['iiko_id'] = this.iikoId;
//     data['image'] = this.image;
//     data['in_price'] = this.inPrice;
//     data['is_divisible'] = this.isDivisible;
//     data['jowi_id'] = this.jowiId;
//     data['measurement_id'] = this.measurementId;
//     data['order'] = this.order;
//     data['out_price'] = this.outPrice;
//     data['parent_id'] = this.parentId;
//     data['price_changers'] = this.priceChangers;
//     if (this.productProperty != null) {
//       data['product_property'] =
//           this.productProperty!.map((v) => v.toJson()).toList();
//     }
//     data['property_ids'] = this.propertyIds;
//     data['rate_id'] = this.rateId;
//     data['relation_type'] = this.relationType;
//     data['shipper_id'] = this.shipperId;
//     data['slug'] = this.slug;
//     data['tags'] = this.tags;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     data['type'] = this.type;
//     return data;
//   }
// }
//
// class ProductProperty {
//   String? optionId;
//   String? propertyId;
//   Title? title;
//
//   ProductProperty({this.optionId, this.propertyId, this.title});
//
//   ProductProperty.fromJson(Map<String, dynamic> json) {
//     optionId = json['option_id'];
//     propertyId = json['property_id'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['option_id'] = this.optionId;
//     data['property_id'] = this.propertyId;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class Measurement {
//   int? accuracy;
//   String? createdAt;
//   String? id;
//   String? shipperId;
//   String? shortName;
//   String? slug;
//   Title? title;
//
//   Measurement(
//       {this.accuracy,
//       this.createdAt,
//       this.id,
//       this.shipperId,
//       this.shortName,
//       this.slug,
//       this.title});
//
//   Measurement.fromJson(Map<String, dynamic> json) {
//     accuracy = json['accuracy'];
//     createdAt = json['created_at'];
//     id = json['id'];
//     shipperId = json['shipper_id'];
//     shortName = json['short_name'];
//     slug = json['slug'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['accuracy'] = this.accuracy;
//     data['created_at'] = this.createdAt;
//     data['id'] = this.id;
//     data['shipper_id'] = this.shipperId;
//     data['short_name'] = this.shortName;
//     data['slug'] = this.slug;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class PriceChangers {
//   String? amount;
//   String? base;
//   String? changeType;
//   String? id;
//   String? slug;
//   Title? title;
//
//   PriceChangers(
//       {this.amount,
//       this.base,
//       this.changeType,
//       this.id,
//       this.slug,
//       this.title});
//
//   PriceChangers.fromJson(Map<String, dynamic> json) {
//     amount = json['amount'];
//     base = json['base'];
//     changeType = json['change_type'];
//     id = json['id'];
//     slug = json['slug'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['amount'] = this.amount;
//     data['base'] = this.base;
//     data['change_type'] = this.changeType;
//     data['id'] = this.id;
//     data['slug'] = this.slug;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class Properties {
//   bool? active;
//   String? createdAt;
//   Title? description;
//   String? id;
//   List<Options>? options;
//   int? orderNo;
//   String? shipperId;
//   String? slug;
//   Title? title;
//
//   Properties(
//       {this.active,
//       this.createdAt,
//       this.description,
//       this.id,
//       this.options,
//       this.orderNo,
//       this.shipperId,
//       this.slug,
//       this.title});
//
//   Properties.fromJson(Map<String, dynamic> json) {
//     active = json['active'];
//     createdAt = json['created_at'];
//     description = json['description'] != null
//         ? new Title.fromJson(json['description'])
//         : null;
//     id = json['id'];
//     if (json['options'] != null) {
//       options = <Options>[];
//       json['options'].forEach((v) {
//         options!.add(new Options.fromJson(v));
//       });
//     }
//     orderNo = json['order_no'];
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['active'] = this.active;
//     data['created_at'] = this.createdAt;
//     if (this.description != null) {
//       data['description'] = this.description!.toJson();
//     }
//     data['id'] = this.id;
//     if (this.options != null) {
//       data['options'] = this.options!.map((v) => v.toJson()).toList();
//     }
//     data['order_no'] = this.orderNo;
//     data['shipper_id'] = this.shipperId;
//     data['slug'] = this.slug;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class ComboOptions {
//   String? id;
//   Title? title;
//
//   ComboOptions({this.id, this.title});
//
//   ComboOptions.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['id'] = this.id;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
//
// class Rate {
//   String? code;
//   String? createdAt;
//   String? id;
//   int? rateAmount;
//   String? shipperId;
//   String? slug;
//   String? title;
//
//   Rate(
//       {this.code,
//       this.createdAt,
//       this.id,
//       this.rateAmount,
//       this.shipperId,
//       this.slug,
//       this.title});
//
//   Rate.fromJson(Map<String, dynamic> json) {
//     code = json['code'];
//     createdAt = json['created_at'];
//     id = json['id'];
//     rateAmount = json['rate_amount'];
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     title = json['title'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['code'] = this.code;
//     data['created_at'] = this.createdAt;
//     data['id'] = this.id;
//     data['rate_amount'] = this.rateAmount;
//     data['shipper_id'] = this.shipperId;
//     data['slug'] = this.slug;
//     data['title'] = this.title;
//     return data;
//   }
// }
//
// class Tags {
//   String? color;
//   String? createdAt;
//   String? icon;
//   String? id;
//   String? shipperId;
//   String? slug;
//   Title? title;
//
//   Tags(
//       {this.color,
//       this.createdAt,
//       this.icon,
//       this.id,
//       this.shipperId,
//       this.slug,
//       this.title});
//
//   Tags.fromJson(Map<String, dynamic> json) {
//     color = json['color'];
//     createdAt = json['created_at'];
//     icon = json['icon'];
//     id = json['id'];
//     shipperId = json['shipper_id'];
//     slug = json['slug'];
//     title = json['title'] != null ? new Title.fromJson(json['title']) : null;
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = new Map<String, dynamic>();
//     data['color'] = this.color;
//     data['created_at'] = this.createdAt;
//     data['icon'] = this.icon;
//     data['id'] = this.id;
//     data['shipper_id'] = this.shipperId;
//     data['slug'] = this.slug;
//     if (this.title != null) {
//       data['title'] = this.title!.toJson();
//     }
//     return data;
//   }
// }
