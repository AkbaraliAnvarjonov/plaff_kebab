class DiscountWithOrderPriceResponse {
  DiscountWithOrderPriceResponse({
      this.allDiscountPrice, 
      this.discounts,});

  DiscountWithOrderPriceResponse.fromJson(dynamic json) {
    allDiscountPrice = json['all_discount_price'];
    if (json['discounts'] != null) {
      discounts = [];
      json['discounts'].forEach((v) {
        discounts?.add(Discounts.fromJson(v));
      });
    }
  }
  num? allDiscountPrice;
  List<Discounts>? discounts;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['all_discount_price'] = allDiscountPrice;
    if (discounts != null) {
      map['discounts'] = discounts?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Discounts {
  Discounts({
      this.discountAmount, 
      this.discountId, 
      this.discountMode, 
      this.discountPriceForOrder, 
      this.discountTitle, 
      this.discountType,});

  Discounts.fromJson(dynamic json) {
    discountAmount = json['discount_amount'];
    discountId = json['discount_id'];
    discountMode = json['discount_mode'];
    discountPriceForOrder = json['discount_price_for_order'];
    discountTitle = json['discount_title'] != null ? DiscountTitle.fromJson(json['discount_title']) : null;
    discountType = json['discount_type'];
  }
  num? discountAmount;
  String? discountId;
  String? discountMode;
  num? discountPriceForOrder;
  DiscountTitle? discountTitle;
  String? discountType;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['discount_amount'] = discountAmount;
    map['discount_id'] = discountId;
    map['discount_mode'] = discountMode;
    map['discount_price_for_order'] = discountPriceForOrder;
    if (discountTitle != null) {
      map['discount_title'] = discountTitle?.toJson();
    }
    map['discount_type'] = discountType;
    return map;
  }

}

class DiscountTitle {
  DiscountTitle({
      this.en, 
      this.ru, 
      this.uz,});

  DiscountTitle.fromJson(dynamic json) {
    en = json['en'];
    ru = json['ru'];
    uz = json['uz'];
  }
  String? en;
  String? ru;
  String? uz;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['en'] = en;
    map['ru'] = ru;
    map['uz'] = uz;
    return map;
  }

}
