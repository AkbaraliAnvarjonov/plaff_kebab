enum OrderStatus {
  newStatus,
  vendorAccepted,
  vendorReady,
  courierPickUp,
  finished,
  delivered,
  serverCancelled,
  operatorCancelled,
  futureTime,
  operatorAccepted,
}
