class ShipperResponse {
  String? futureOrderTime;

  ShipperResponse({this.futureOrderTime});

  ShipperResponse.fromJson(Map<String, dynamic> json) {
    futureOrderTime = json['future_order_time'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['future_order_time'] = futureOrderTime;
    return data;
  }
}
