class BranchesResponse {
  List<Branches> branches = [];
  String? count;

  BranchesResponse({this.branches = const [], this.count});

  BranchesResponse.fromJson(Map<String, dynamic> json) {
    branches = <Branches>[];
    if (json['branches'] != null) {
      json['branches'].forEach((v) {
        branches.add(Branches.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['branches'] = branches.map((v) => v.toJson()).toList();
    data['count'] = count;
    return data;
  }
}

class Branches {
  bool? checked;
  String? id;
  String? menuId;
  String? shipperId;
  String? name;
  String? image;
  String? phone;
  bool? isActive;
  String? address;
  BranchLocation? location;
  String? createdAt;
  String? updatedAt;
  String? destination;
  String? workHourStart;
  String? workHourEnd;
  String? jowiId;
  String? iikoId;
  String? iikoTerminalId;
  String? fareId;
  String? tgChatId;
  num? distance;

  Branches({
    this.id,
    this.shipperId,
    this.name,
    this.image,
    this.phone,
    this.isActive,
    this.address,
    this.location,
    this.createdAt,
    this.updatedAt,
    this.destination,
    this.workHourStart,
    this.workHourEnd,
    this.jowiId,
    this.distance,
    this.iikoId,
    this.iikoTerminalId,
    this.fareId,
    this.tgChatId,
    this.checked = false,
  });

  Branches.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    menuId = json['menu_id'];
    shipperId = json['shipper_id'];
    name = json['name'];
    image = json['image'];
    phone = json['phone'];
    isActive = json['is_active'];
    address = json['address'];
    location = json['location'] != null
        ? BranchLocation.fromJson(json['location'])
        : null;
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    destination = json['destination'];
    workHourStart = json['work_hour_start'];
    workHourEnd = json['work_hour_end'];
    jowiId = json['jowi_id'];
    iikoId = json['iiko_id'];
    iikoTerminalId = json['iiko_terminal_id'];
    fareId = json['fare_id'];
    tgChatId = json['tg_chat_id'];
    distance = json['distance'] ?? 0.0;
    checked = false;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['shipper_id'] = shipperId;
    data['name'] = name;
    data['image'] = image;
    data['phone'] = phone;
    data['is_active'] = isActive;
    data['address'] = address;
    if (location != null) {
      data['location'] = location?.toJson();
    }
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['destination'] = destination;
    data['distance'] = distance;
    data['work_hour_start'] = workHourStart;
    data['work_hour_end'] = workHourEnd;
    data['jowi_id'] = jowiId;
    data['iiko_id'] = iikoId;
    data['iiko_terminal_id'] = iikoTerminalId;
    data['fare_id'] = fareId;
    data['tg_chat_id'] = tgChatId;
    return data;
  }
}

class BranchLocation {
  num? long;
  num? lat;

  BranchLocation({this.long, this.lat});

  BranchLocation.fromJson(Map<String, dynamic> json) {
    long = json['long'];
    lat = json['lat'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['long'] = long;
    data['lat'] = lat;
    return data;
  }
}
