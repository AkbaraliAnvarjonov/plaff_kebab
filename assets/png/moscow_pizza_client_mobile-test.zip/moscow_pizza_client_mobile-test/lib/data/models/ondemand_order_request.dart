
import 'orders_response.dart';

enum PaymentType {
  cash,
  click,
  payMe,
}

enum DeliveryType {
  delivery,
  selfPickup,
}
//qo'shish kere
//bool? isCourierCall;

//qayta qilnvotkan zakazmi check qlsh kere
//bool? isCancelOldOrder;

enum DeliveryTime {
  fastDelivery,
  scheduledDelivery,
}

class OnDemandOrderRequest {
  String? aggregatorId;
  String? apartment;
  String? building;
  String? clientId;
  int? coDeliveryPrice;
  String? deliveryTime;
  String? deliveryType;
  String? description;
  String? extraPhoneNumber;
  String? floor;
  bool? paid;
  String? paymentType;
  String? source;
  String? statusId;
  List<Steps> steps =  [];
  String? toAddress;
  bool? isCourierCall;
  ToLocation? toLocation;
  String? futureTime;

  OnDemandOrderRequest({
    this.aggregatorId,
    this.apartment,
    this.building,
    this.clientId,
    this.coDeliveryPrice,
    this.deliveryTime,
    this.deliveryType,
    this.description,
    this.extraPhoneNumber,
    this.floor,
    this.paid,
    this.isCourierCall,
    this.paymentType,
    this.source,
    this.statusId,
    this.steps = const [],
    this.toAddress,
    this.toLocation,
    this.futureTime,
  });

  OnDemandOrderRequest.fromJson(Map<String, dynamic> json) {
    // apartment = json['aggregator_id'];
    apartment = json['apartment'];
    building = json['building'];
    clientId = json['client_id'];
    coDeliveryPrice = json['co_delivery_price'];
    deliveryTime = json['delivery_time'];
    deliveryType = json['delivery_type'];
    description = json['description'];
    isCourierCall = json['is_courier_call'];
    extraPhoneNumber = json['extra_phone_number'];
    floor = json['floor'];
    paid = json['paid'];
    paymentType = json['payment_type'];
    source = json['source'];
    statusId = json['status_id'];
    steps = <Steps>[];
    if (json['steps'] != null) {
      json['steps'].forEach((v) {
        steps.add(Steps.fromJson(v));
      });
    }
    toAddress = json['to_address'];
    toLocation = json['to_location'] != null
        ? ToLocation.fromJson(json['to_location'])
        : null;
    futureTime = json['future_time'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    // data['aggregator_id'] = this.aggregatorId;
    data['apartment'] = apartment;
    data['building'] = building;
    data['client_id'] = clientId;
    data['co_delivery_price'] = coDeliveryPrice;
    data['delivery_time'] = deliveryTime;
    data['delivery_type'] = deliveryType;
    data['description'] = description;
    data['is_courier_call'] = isCourierCall;
    data['extra_phone_number'] = extraPhoneNumber;
    data['floor'] = floor;
    data['paid'] = paid;
    data['payment_type'] = paymentType;
    data['source'] = source;
    data['status_id'] = statusId;
    data['steps'] = steps.map((v) => v.toJson()).toList();
    data['to_address'] = toAddress;
    if (toLocation != null) {
      data['to_location'] = toLocation?.toJson();
    }
    data['future_time'] = futureTime;

    return data;
  }
}

// class Steps {
//   String? id;
//   String? branchName;
//   ToLocation? location;
//   String? address;
//   String? destinationAddress;
//   String? phoneNumber;
//   List<OrdersProducts> products = [];
//   String? description;
//   String? orderNo;
//   String? status;
//   int? stepAmount;
//   dynamic externalStepId;
//   String? branchId;
//
//   Steps({
//     this.id,
//     this.branchName,
//     this.location,
//     this.address,
//     this.destinationAddress,
//     this.phoneNumber,
//     this.products = const [],
//     this.description,
//     this.orderNo,
//     this.status,
//     this.stepAmount,
//     this.externalStepId,
//     this.branchId,
//   });
//
//   Steps.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     branchName = json['branch_name'];
//     location = json['location'] != null
//         ? new ToLocation.fromJson(json['location'])
//         : null;
//     address = json['address'];
//     destinationAddress = json['destination_address'];
//     phoneNumber = json['phone_number'];
//     products = <OrdersProducts>[];
//     if (json['products'] != null) {
//       json['products'].forEach((v) {
//         products.add(OrdersProducts.fromJson(v));
//       });
//     }
//     description = json['description'];
//     orderNo = json['order_no'];
//     status = json['status'];
//     stepAmount = json['step_amount'];
//     externalStepId = json['external_step_id'];
//     branchId = json['branch_id'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = Map<String, dynamic>();
//     data['branch_id'] = this.branchId;
//     data['description'] = this.description;
//     if (this.products != null) {
//       data['products'] = this.products.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class Modifiers {
//   String? modifierId;
//   String? modifierName;
//   String? modifierQuantity;
//   String? modifiersPrice;
//   String? parentId;
//
//   Modifiers(
//       {this.modifierId,
//         this.modifierName,
//         this.modifierQuantity,
//         this.modifiersPrice,
//         this.parentId});
//
//   Modifiers.fromJson(Map<String, dynamic> json) {
//     modifierId = json['modifier_id'];
//     modifierName = json['modifier_name'];
//     modifierQuantity = json['modifier_quantity'];
//     modifiersPrice = json['modifier_price'];
//     parentId = json['parent_id'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['modifier_id'] = modifierId;
//     data['modifier_name'] = modifierName;
//     data['modifier_quantity'] = modifierQuantity;
//     data['modifier_price'] = modifiersPrice;
//     data['parent_id'] = parentId;
//     return data;
//   }
// }
//
//
// class OrdersProducts {
//   String? id;
//   String? name;
//   num? quantity;
//   dynamic price;
//   int? totalAmount;
//   String? productId;
//   String? externalProductId;
//   String? description;
//   List<Modifiers>? modifiers;
//
//   OrdersProducts({
//     this.modifiers,
//     this.id,
//     this.name,
//     this.quantity,
//     this.price,
//     this.totalAmount,
//     this.productId,
//     this.externalProductId,
//     this.description,
//   });
//
//   OrdersProducts.fromJson(Map<String, dynamic> json) {
//     id = json['id'];
//     name = json['name'];
//     quantity = json['quantity'];
//     price = json['price'];
//     totalAmount = json['total_amount'];
//     productId = json['product_id'];
//     externalProductId = json['external_product_id'];
//     description = json['description'];
//     if (json['order_modifiers'] != null) {
//       modifiers = <Modifiers>[];
//       json['order_modifiers'].forEach((v) {
//         modifiers!.add(Modifiers.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = <String, dynamic>{};
//     data['description'] = description;
//     data['price'] = price;
//     data['product_id'] = productId;
//     data['quantity'] = quantity;
//     if (modifiers != null) {
//       data['order_modifiers'] = modifiers!.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }
//
// class ToLocation {
//   dynamic long;
//   dynamic lat;
//
//   ToLocation({this.long, this.lat});
//
//   ToLocation.fromJson(Map<String, dynamic> json) {
//     long = json['long'];
//     lat = json['lat'];
//   }
//
//   // Map<String, dynamic> toJson() {
//   //   final Map<String, dynamic> data = Map<String, dynamic>();
//   //   data['long'] = this.long;
//   //   data['lat'] = this.lat;
//   //   return data;
//   // }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = Map<String, dynamic>();
//     data['lat'] = this.lat;
//     data['long'] = this.long;
//     return data;
//   }
// }

// class Steps {
//   String branchId;
//   String description;
//   List<OrderProducts> products;
//
//   Steps({this.branchId, this.description, this.products});
//
//   Steps.fromJson(Map<String, dynamic> json) {
//     branchId = json['branch_id'];
//     description = json['description'];
//     products = <OrderProducts>[];
//     if (json['products'] != null) {
//       json['products'].forEach((v) {
//         products.add(OrderProducts.fromJson(v));
//       });
//     }
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = Map<String, dynamic>();
//     data['branch_id'] = this.branchId;
//     data['description'] = this.description;
//     if (this.products != null) {
//       data['products'] = this.products.map((v) => v.toJson()).toList();
//     }
//     return data;
//   }
// }

// class OrderProducts {
//   String description;
//   String price;
//   String productId;
//   int quantity;
//
//   OrderProducts({this.description, this.price, this.productId, this.quantity});
//
//   OrderProducts.fromJson(Map<String, dynamic> json) {
//     description = json['description'];
//     price = json['price'];
//     productId = json['product_id'];
//     quantity = json['quantity'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = Map<String, dynamic>();
//     data['description'] = this.description;
//     data['price'] = this.price;
//     data['product_id'] = this.productId;
//     data['quantity'] = this.quantity;
//     return data;
//   }
// }
//
// class ToLocation {
//   double lat;
//   double long;
//
//   ToLocation({this.lat, this.long});
//
//   ToLocation.fromJson(Map<String, dynamic> json) {
//     lat = json['lat'];
//     long = json['long'];
//   }
//
//   Map<String, dynamic> toJson() {
//     final Map<String, dynamic> data = Map<String, dynamic>();
//     data['lat'] = this.lat;
//     data['long'] = this.long;
//     return data;
//   }
// }
