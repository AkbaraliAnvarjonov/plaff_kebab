import 'package:flutter/foundation.dart';

class BannersResponse {
  List<Banners> banners = [];
  String? count;

  BannersResponse({this.banners = const [], this.count});

  BannersResponse.fromJson(Map<String, dynamic> json) {
    banners = <Banners>[];
    if (json['banners'] != null) {
      json['banners'].forEach((v) {
        banners.add(Banners.fromJson(v));
      });
    } else {
      banners = [];
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['banners'] = banners.map((v) => v.toJson()).toList();
    data['count'] = count;
    return data;
  }
}

@immutable
class Banners {
  final String? id;
  final Title? title;
  final String? position;
  final String? image;
  final String? url;
  final bool? active;
  final String? createdAt;
  final String? updatedAt;
  final String? shipperId;

  const Banners({
    this.id,
    this.title,
    this.position,
    this.image,
    this.url,
    this.active,
    this.createdAt,
    this.updatedAt,
    this.shipperId,
  });

  factory Banners.fromJson(Map<String, dynamic> json) {
    return Banners(
      id: json['id'],
      title: json['title'] != null ? Title.fromJson(json['title']) : null,
      position: json['position'],
      image: json['image'],
      url: json['url'],
      active: json['active'],
      createdAt: json['created_at'],
      updatedAt: json['updated_at'],
      shipperId: json['shipper_id'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    if (title != null) {
      data['title'] = title?.toJson();
    }
    data['position'] = position;
    data['image'] = image;
    data['url'] = url;
    data['active'] = active;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['shipper_id'] = shipperId;
    return data;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Banners &&
          runtimeType == other.runtimeType &&
          hashCode == other.hashCode;

  @override
  int get hashCode => Object.hash(
      id, title, position, image, url, active, createdAt, updatedAt, shipperId);
}

@immutable
class Title {
  final String? uz;
  final String? ru;
  final String? en;

  const Title({this.uz, this.ru, this.en});

  factory Title.fromJson(Map<String, dynamic> json) {
    return Title(
      uz: json['uz'],
      ru: json['ru'],
      en: json['en'],
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uz'] = uz;
    data['ru'] = ru;
    data['en'] = en;
    return data;
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Title &&
          runtimeType == other.runtimeType &&
          hashCode == other.hashCode;

  @override
  int get hashCode => Object.hash(uz, ru, en);
}
