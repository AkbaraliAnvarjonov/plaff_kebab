import 'package:moscow_pizza_client_mobile/data/models/discount_with_order_price_response.dart';

class ProductDiscountResponse {
  List<ProductWithDiscount>? productWithDiscount;

  ProductDiscountResponse({
    this.productWithDiscount,
  });

  ProductDiscountResponse.fromJson(json) {
    productWithDiscount = json['products_with_discounts'] is List
        ? List.generate(
            (json['products_with_discounts'] as List).length,
            (index) => ProductWithDiscount.fromJson(
                (json['products_with_discounts'] as List)[index]),
          )
        : [];
  }
}

class ProductWithDiscount {
  String? productId;
  DiscountTitle? productName;
  List<ProductDiscount>? discounts;

  ProductWithDiscount({
    this.productName,
    this.discounts,
  });

  ProductWithDiscount.fromJson(json) {
    productId = json['product_id'];
    productName = DiscountTitle.fromJson(json['product_name']);
    discounts = json['discounts'] is List
        ? List.generate(
            (json['discounts'] as List).length,
            (index) =>
                ProductDiscount.fromJson((json['discounts'] as List)[index]),
          )
        : [];
  }
}

class ProductDiscount {
  String? id;
  int? discountPrice;
  DiscountTitle? name;

  ProductDiscount({
    this.id,
    this.discountPrice,
    this.name,
  });

  ProductDiscount.fromJson(json) {
    id = json['id'];
    discountPrice = json['discount_price'];
    name = DiscountTitle.fromJson(json['name']);
  }
}
