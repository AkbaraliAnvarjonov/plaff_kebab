class ReviewsResponse {
  List<Reviews> reviews = [];
  String? count;

  ReviewsResponse({this.reviews = const [], this.count});

  ReviewsResponse.fromJson(Map<String, dynamic> json) {
    reviews = <Reviews>[];
    if (json['reviews'] != null) {
      json['reviews'].forEach((v) {
        reviews.add(Reviews.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['reviews'] = reviews.map((v) => v.toJson()).toList();
    data['count'] = count;
    return data;
  }
}

class Reviews {
  String? id;
  Message? message;
  String? type;
  String? shipperId;
  String? relatedSubject;
  bool? active;
  String? createdAt;
  String? updatedAt;

  Reviews({
    this.id,
    this.message,
    this.type,
    this.shipperId,
    this.relatedSubject,
    this.active,
    this.createdAt,
    this.updatedAt,
  });

  Reviews.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    message =
        json['message'] != null ? Message.fromJson(json['message']) : null;
    type = json['type'];
    shipperId = json['shipper_id'];
    relatedSubject = json['related_subject'];
    active = json['active'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    if (message != null) {
      data['message'] = message?.toJson();
    }
    data['type'] = type;
    data['shipper_id'] = shipperId;
    data['related_subject'] = relatedSubject;
    data['active'] = active;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    return data;
  }
}

class Message {
  String? uz;
  String? ru;

  Message({this.uz, this.ru});

  Message.fromJson(Map<String, dynamic> json) {
    uz = json['uz'];
    ru = json['ru'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uz'] = uz;
    data['ru'] = ru;
    return data;
  }
}
