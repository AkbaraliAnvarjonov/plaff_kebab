import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import 'package:flutter/foundation.dart';

class CategoryV2Response {
  List<Categories>? categories;
  String? count;

  CategoryV2Response({this.categories, this.count});

  CategoryV2Response.fromJson(Map<String, dynamic> json) {
    if (json['categories'] != null) {
      categories = <Categories>[];
      json['categories'].forEach((v) {
        categories!.add(Categories.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (categories != null) {
      data['categories'] = categories!.map((v) => v.toJson()).toList();
    }
    data['count'] = count;
    return data;
  }
}

@immutable
class Categories {
  final String? id;
  final String? slug;
  final String? parentId;
  final String? image;
  final Description? description;
  final Title? title;
  final String? orderNo;
  final bool? active;
  final List<Products1> products;
  final List<ChildCategories> childCategories;
  final bool? isChecked;

  const Categories({
    this.childCategories = const [],
    this.id,
    this.slug,
    this.parentId,
    this.image,
    this.description,
    this.title,
    this.orderNo,
    this.active,
    this.products = const [],
    this.isChecked,
  });

  factory Categories.fromJson(Map<String, dynamic> json) {
    return Categories(
      id: json['id'],
      slug: json['slug'],
      parentId: json['parent_id'],
      image: json['image'],
      description: json['description'] != null
          ? Description.fromJson(json['description'])
          : null,
      title: json['title'] != null ? Title.fromJson(json['title']) : null,
      orderNo: json['order_no'],
      active: json['active'],
      isChecked: false,
      products: json['products'] != null
          ? (json['products'] as List)
              .map((i) => Products1.fromJson(i))
              .toList()
          : [],
      childCategories: json['child_categories'] != null
          ? (json['child_categories'] as List)
              .map((i) => ChildCategories.fromJson(i))
              .toList()
          : [],
    );
  }

  Categories copyWith({
    String? id,
    String? slug,
    String? parentId,
    String? image,
    Description? description,
    Title? title,
    String? orderNo,
    bool? active,
    List<Products1>? products,
    List<ChildCategories>? childCategories,
    bool? isChecked,
  }) {
    return Categories(
      id: id ?? this.id,
      slug: slug ?? this.slug,
      parentId: parentId ?? this.parentId,
      image: image ?? this.image,
      description: description ?? this.description,
      title: title ?? this.title,
      orderNo: orderNo ?? this.orderNo,
      active: active ?? this.active,
      products: products ?? this.products,
      childCategories: childCategories ?? this.childCategories,
      isChecked: isChecked ?? this.isChecked,
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['slug'] = slug;
    data['parent_id'] = parentId;
    data['image'] = image;
    if (description != null) {
      data['description'] = description!.toJson();
    }
    if (title != null) {
      data['title'] = title!.toJson();
    }
    data['order_no'] = orderNo;
    data['active'] = active;
    data['products'] = products.map((v) => v.toJson()).toList();
    data['child_categories'] = childCategories.map((v) => v.toJson()).toList();
    return data;
  }

  @override
  String toString() {
    return 'Categories{id: $id, slug: $slug, parentId: $parentId, image: $image, description: $description, title: $title, orderNo: $orderNo, active: $active, products: $products, childCategories: $childCategories, isChecked: $isChecked}';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Categories &&
          runtimeType == other.runtimeType &&
          hashCode == other.hashCode;

  @override
  int get hashCode => Object.hash(id, slug, parentId, image, description, title,
      orderNo, active, products, isChecked);
}

class ChildCategories {
  Description? description;
  String? id;
  String? image;
  String? name;
  String? orderNo;
  String? parentId;
  List<Products1>? products;
  String? slug;
  Title? title;

  ChildCategories({
    this.description,
    this.id,
    this.image,
    this.name,
    this.orderNo,
    this.parentId,
    this.products,
    this.slug,
    this.title,
  });

  ChildCategories.fromJson(Map<String, dynamic> json) {
    description = json['description'] != null
        ? Description.fromJson(json['description'])
        : null;
    id = json['id'];
    image = json['image'];
    name = json['name'];
    orderNo = json['order_no'];
    parentId = json['parent_id'];
    if (json['products'] != null) {
      products = <Products1>[];
      json['products'].forEach((v) {
        products!.add(Products1.fromJson(v));
      });
    }
    slug = json['slug'];
    title = json['title'] != null ? Title.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (description != null) {
      data['description'] = description!.toJson();
    }
    data['id'] = id;
    data['image'] = image;
    data['name'] = name;
    data['order_no'] = orderNo;
    data['parent_id'] = parentId;
    if (products != null) {
      data['products'] = products!.map((v) => v.toJson()).toList();
    }
    data['slug'] = slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}

@immutable
class Products1 {
  final String? id;
  final num? outPrice;
  final String? currency;
  final String? string;
  final String? type;
  final bool? activeInMenu;
  final List<dynamic>? categories;
  final String? brandId;
  final String? rateId;
  final String? image;
  final dynamic gallery;
  final Title? title;
  final Description? description;
  final bool? active;
  final bool? hasModifier;
  final String? iikoId;
  final String? jowiId;
  final num? discounts;
  final List<dynamic>? discount;

  const Products1({
    this.activeInMenu,
    this.id,
    this.outPrice,
    this.currency,
    this.string,
    this.type,
    this.categories,
    this.brandId,
    this.rateId,
    this.image,
    this.gallery,
    this.title,
    this.description,
    this.active,
    this.hasModifier,
    this.iikoId,
    this.jowiId,
    this.discounts = 0,
    this.discount,
  });

  factory Products1.fromJson(Map<String, dynamic> json) {
    num discounts = 0;
    if (json['discounts'] != null) {
      json['discounts'].forEach((v) {
        final num? discountPrice = v['discount_price'];
        discounts = discounts + (discountPrice ?? 0);
      });
      if (json['out_price'] != null) {
        final num outPrice = json['out_price'];
        if (outPrice < discounts.abs()) {
          discounts -= outPrice - discounts.abs();
        }
      }
    }
    return Products1(
      discount: json['discounts'],
      id: json['id'],
      outPrice: json['out_price'],
      currency: json['currency'],
      string: json['string'],
      type: json['type'],
      categories: json['categories'] ?? [],
      brandId: json['brand_id'],
      activeInMenu: json['active_in_menu'],
      rateId: json['rate_id'] ?? [],
      image: json['image'],
      gallery: json['gallery'],
      title: json['title'] != null ? Title.fromJson(json['title']) : null,
      description: json['description'] != null
          ? Description.fromJson(json['description'])
          : null,
      active: json['active'],
      hasModifier: json['has_modifier'],
      iikoId: json['iiko_id'],
      jowiId: json['jowi_id'],
      discounts: discounts,
    );
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['out_price'] = outPrice;
    data['currency'] = currency;
    data['string'] = string;
    data['type'] = type;
    data['categories'] = categories;
    data['brand_id'] = brandId;
    data['rate_id'] = rateId;
    data['image'] = image;
    data['gallery'] = gallery;
    data['discounts'] = discount;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    if (description != null) {
      data['description'] = description!.toJson();
    }
    data['active'] = active;
    data['has_modifier'] = hasModifier;
    data['iiko_id'] = iikoId;
    data['jowi_id'] = jowiId;
    return data;
  }

  @override
  String toString() {
    return 'Products1(id: $id, outPrice: $outPrice, currency: $currency, string: $string, type: $type, categories: $categories, brandId: $brandId, rateId: $rateId, image: $image, gallery: $gallery, title: $title, description: $description, active: $active, hasModifier: $hasModifier, iikoId: $iikoId, jowiId: $jowiId)';
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Products1 &&
          runtimeType == other.runtimeType &&
          hashCode == other.hashCode;

  @override
  int get hashCode => Object.hash(
        id,
        outPrice,
        currency,
        string,
        type,
        categories,
        brandId,
        rateId,
        image,
        gallery,
        title,
        description,
        active,
        hasModifier,
        iikoId,
        jowiId,
        discount,
        discounts,
      );
}
