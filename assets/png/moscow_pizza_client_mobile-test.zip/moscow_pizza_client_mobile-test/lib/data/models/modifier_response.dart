import 'package:moscow_pizza_client_mobile/data/hive/products.dart';

class ModifierResponse {
  String? count;
  ProductModifiers? productModifiers;

  ModifierResponse({this.count, this.productModifiers});

  ModifierResponse.fromJson(Map<String, dynamic> json) {
    count = json['count'];
    productModifiers = json['product_modifiers'] != null
        ? ProductModifiers.fromJson(json['product_modifiers'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['count'] = count;
    if (productModifiers != null) {
      data['product_modifiers'] = productModifiers!.toJson();
    }
    return data;
  }
}

class ProductModifiers {
  List<GroupModifiers>? groupModifiers;
  List<SingleModifiers>? singleModifiers;

  ProductModifiers({this.groupModifiers, this.singleModifiers});

  ProductModifiers.fromJson(Map<String, dynamic> json) {
    if (json['group_modifiers'] != null) {
      groupModifiers = <GroupModifiers>[];
      json['group_modifiers'].forEach((v) {
        groupModifiers!.add( GroupModifiers.fromJson(v));
      });
    }
    if (json['single_modifiers'] != null) {
      singleModifiers = <SingleModifiers>[];
      json['single_modifiers'].forEach((v) {
        singleModifiers!.add( SingleModifiers.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (groupModifiers != null) {
      data['group_modifiers'] =
          groupModifiers!.map((v) => v.toJson()).toList();
    }
    if (singleModifiers != null) {
      data['single_modifiers'] =
          singleModifiers!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class GroupModifiers {
  int? selectGroupModifier;
  bool? active;
  bool? addToPrice;
  String? code;
  String? createdAt;
  String? fromProductId;
  String? id;
  bool? isCheckbox;
  bool? isCompulsory;
  int? maxAmount;
  int? minAmount;
  Name? name;
  Name? categoryName;
  String? order;
  String? price;
  String? shipperId;
  String? toProductId;
  String? type;
  List<Variants>? variants;

  GroupModifiers(
      {this.active,
        this.selectGroupModifier,
        this.addToPrice,
        this.code,
        this.createdAt,
        this.fromProductId,
        this.id,
        this.isCheckbox,
        this.isCompulsory,
        this.maxAmount,
        this.minAmount,
        this.name,
        this.categoryName,
        this.order,
        this.price,
        this.shipperId,
        this.toProductId,
        this.type,
        this.variants});

  GroupModifiers.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    addToPrice = json['add_to_price'];
    code = json['code'];
    createdAt = json['created_at'];
    fromProductId = json['from_product_id'];
    id = json['id'];
    isCheckbox = json['is_checkbox'];
    isCompulsory = json['is_compulsory'];
    maxAmount = json['max_amount'];
    minAmount = json['min_amount'];
    name = json['name'] != null ? Name.fromJson(json['name']) : null;
    categoryName = json['category_name'] != null
        ? Name.fromJson(json['category_name'])
        : null;
    order = json['order'];
    price = json['price'];
    shipperId = json['shipper_id'];
    toProductId = json['to_product_id'];
    type = json['type'];
    if (json['variants'] != null) {
      variants = <Variants>[];
      json['variants'].forEach((v) {
        variants!.add(Variants.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['active'] = active;
    data['add_to_price'] = addToPrice;
    data['code'] = code;
    data['created_at'] = createdAt;
    data['from_product_id'] = fromProductId;
    data['id'] = id;
    data['is_checkbox'] = isCheckbox;
    data['is_compulsory'] = isCompulsory;
    data['max_amount'] = maxAmount;
    data['min_amount'] = minAmount;
    if (name != null) {
      data['name'] = name!.toJson();
    }
    if (categoryName != null) {
      data['category_name'] = categoryName!.toJson();
    }
    data['order'] = order;
    data['price'] = price;
    data['shipper_id'] = shipperId;
    data['to_product_id'] = toProductId;
    data['type'] = type;
    if (variants != null) {
      data['variants'] = variants!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class SingleModifiers {
  bool? active;
  bool? addToPrice;
  String? code;
  String? createdAt;
  String? fromProductId;
  String? id;
  bool? isCheckbox;
  bool? isCompulsory;
  int? maxAmount;
  int? minAmount;
  Name? name;
  Name? categoryName;
  String? order;
  String? price;
  String? shipperId;
  String? toProductId;
  String? type;
  List<Variants>? variants;
  int? count;
  bool? isChecked = false;

  SingleModifiers(
      {this.active,
        this.count = 0,
        this.isChecked = false,
        this.addToPrice,
        this.code,
        this.createdAt,
        this.fromProductId,
        this.id,
        this.isCheckbox,
        this.isCompulsory,
        this.maxAmount,
        this.minAmount,
        this.name,
        this.order,
        this.price,
        this.shipperId,
        this.toProductId,
        this.type,
        this.variants});

  SingleModifiers.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    addToPrice = json['add_to_price'];
    code = json['code'];
    createdAt = json['created_at'];
    fromProductId = json['from_product_id'];
    id = json['id'];
    isCheckbox = json['is_checkbox'];
    isCompulsory = json['is_compulsory'];
    maxAmount = json['max_amount'];
    minAmount = json['min_amount'];
    name = json['name'] != null ? Name.fromJson(json['name']) : null;
    categoryName = json['category_name'] != null
        ? Name.fromJson(json['category_name'])
        : null;
    order = json['order'];
    price = json['price'];
    shipperId = json['shipper_id'];
    toProductId = json['to_product_id'];
    type = json['type'];
    if (json['variants'] != null) {
      variants = <Variants>[];
      json['variants'].forEach((v) {
        variants!.add(Variants.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data =  <String, dynamic>{};
    data['active'] = active;
    data['add_to_price'] = addToPrice;
    data['code'] = code;
    data['created_at'] = createdAt;
    data['from_product_id'] = fromProductId;
    data['id'] = id;
    data['is_checkbox'] = isCheckbox;
    data['is_compulsory'] = isCompulsory;
    data['max_amount'] = maxAmount;
    data['min_amount'] = minAmount;
    if (name != null) {
      data['name'] = name!.toJson();
    }
    if (categoryName != null) {
      data['category_name'] = categoryName!.toJson();
    }
    data['order'] = order;
    data['price'] = price;
    data['shipper_id'] = shipperId;
    data['to_product_id'] = toProductId;
    data['type'] = type;
    if (variants != null) {
      data['variants'] = variants!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Name {
  String? uz;
  String? ru;
  String? en;

  Name({this.uz, this.ru, this.en});

  NameTitle? parseName(){
    return NameTitle(
      uz: uz,
      ru: ru,
      en: en,
    );
  }

  Name.fromJson(Map<String, dynamic> json) {
    uz = json['uz'];
    ru = json['ru'];
    en = json['en'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uz'] = uz;
    data['ru'] = ru;
    data['en'] = en;
    return data;
  }
}

class Variants {
  bool? isChecked = false;
  int? quantity = 0;
  int? selectIndex;
  String? brandId;
  List<String>? categoryIds;
  List<String>? comboIds;
  String? count;
  String? currency;
  Description? description;
  List<String>? gallery;
  String? id;
  String? image;
  int? inPrice;
  bool? isDivisible;
  String? measurementId;
  String? orderNo;
  int? outPrice;
  List<String>? priceChangerIds;
  List<PropertyGroups>? propertyGroups;
  String? rateId;
  List<String>? tagIds;
  Description? title;

  Variants(
      {this.quantity,
        this.isChecked,
        this.selectIndex,
        this.brandId,
        this.categoryIds,
        this.comboIds,
        this.count,
        this.currency,
        this.description,
        this.gallery,
        this.id,
        this.image,
        this.inPrice,
        this.isDivisible,
        this.measurementId,
        this.orderNo,
        this.outPrice,
        this.priceChangerIds,
        this.propertyGroups,
        this.rateId,
        this.tagIds,
        this.title});

  Variants.fromJson(Map<String, dynamic> json) {
   brandId = json['brand_id'];
   if (json['category_ids'] != null) {
     categoryIds = [];
     json['category_ids'].forEach((v) {
       categoryIds?.add(v);
     });
   }
   if (json['combo_ids'] != null) {
     comboIds = [];
     json['combo_ids'].forEach((v) {
       comboIds?.add(v);
     });
   }
    count = json['count'];
    currency = json['currency'];
    description = json['description'] != null
        ? Description.fromJson(json['description'])
        : null;
   if (json['gallery'] != null) {
     gallery = [];
     json['gallery'].forEach((v) {
       gallery?.add(v);
     });
   }
    id = json['id'];
    image = json['image'];
    inPrice = json['in_price'];
    isDivisible = json['is_divisible'];
    measurementId = json['measurement_id'];
    orderNo = json['order_no'];
    outPrice = json['out_price'];
   if (json['price_changer_ids'] != null) {
     priceChangerIds = [];
     json['price_changer_ids'].forEach((v) {
       priceChangerIds?.add(v);
     });
   }
    if (json['property_groups'] != null) {
      propertyGroups = <PropertyGroups>[];
      json['property_groups'].forEach((v) {
        propertyGroups!.add( PropertyGroups.fromJson(v));
      });
    }
   rateId = json['rate_id'];
   if (json['tag_ids'] != null) {
     tagIds = [];
     json['tag_ids'].forEach((v) {
       tagIds?.add(v);
     });
   }
    title = json['title'] != null ? Description.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['brand_id'] = brandId;
    data['category_ids'] = categoryIds;
    data['combo_ids'] = comboIds;
    data['count'] = count;
    data['currency'] = currency;
    if (description != null) {
      data['description'] = description!.toJson();
    }
    data['gallery'] = gallery;
    data['id'] = id;
    data['image'] = image;
    data['in_price'] = inPrice;
    data['is_divisible'] = isDivisible;
    data['measurement_id'] = measurementId;
    data['order_no'] = orderNo;
    data['out_price'] = outPrice;
    data['price_changer_ids'] = priceChangerIds;
    if (propertyGroups != null) {
      data['property_groups'] =
          propertyGroups!.map((v) => v.toJson()).toList();
    }
    data['rate_id'] = rateId;
    data['tag_ids'] = tagIds;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}

class Description {
  String? en;
  String? ru;
  String? uz;

  Description({this.en, this.ru, this.uz});

  NameTitle? parseTitle(){
    return NameTitle(
      uz: uz,
      ru: ru,
      en: en,
    );
  }

  Description.fromJson(Map<String, dynamic> json) {
    en = json['en'];
    ru = json['ru'];
    uz = json['uz'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['en'] = en;
    data['ru'] = ru;
    data['uz'] = uz;
    return data;
  }
}

class PropertyGroups {
  Description? description;
  String? id;
  bool? isActive;
  List<ModifierOptions>? options;
  String? order;
  String? slug;
  Description? title;
  String? type;
  String? value;

  PropertyGroups(
      {this.description,
        this.id,
        this.isActive,
        this.options,
        this.order,
        this.slug,
        this.title,
        this.type,
        this.value});

  PropertyGroups.fromJson(Map<String, dynamic> json) {
    description = json['description'] != null
        ? Description.fromJson(json['description'])
        : null;
    id = json['id'];
    isActive = json['is_active'];
    if (json['options'] != null) {
      options = <ModifierOptions>[];
      json['options'].forEach((v) {
        options!.add(ModifierOptions.fromJson(v));
      });
    }
    order = json['order'];
    slug = json['slug'];
    title =
    json['title'] != null ? Description.fromJson(json['title']) : null;
    type = json['type'];
    value = json['value'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (description != null) {
      data['description'] = description!.toJson();
    }
    data['id'] = id;
    data['is_active'] = isActive;
    if (options != null) {
      data['options'] = options!.map((v) => v.toJson()).toList();
    }
    data['order'] = order;
    data['slug'] = slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    data['type'] = type;
    data['value'] = value;
    return data;
  }
}

class ModifierOptions {
  bool? active;
  Description? description;
  String? id;
  List<ModifierOptions>? options;
  String? order;
  String? slug;
  Description? title;

  ModifierOptions(
      {this.active,
        this.description,
        this.id,
        this.options,
        this.order,
        this.slug,
        this.title});

  ModifierOptions.fromJson(Map<String, dynamic> json) {
    active = json['active'];
    description = json['description'] != null
        ? Description.fromJson(json['description'])
        : null;
    id = json['id'];
    if (json['options'] != null) {
      options = <ModifierOptions>[];
      json['options'].forEach((v) {
        options!.add(ModifierOptions.fromJson(v));
      });
    }
    order = json['order'];
    slug = json['slug'];
    title =
    json['title'] != null ? Description.fromJson(json['title']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['active'] = active;
    if (description != null) {
      data['description'] = description!.toJson();
    }
    data['id'] = id;
    if (options != null) {
      data['options'] = options!.map((v) => v.toJson()).toList();
    }
    data['order'] = order;
    data['slug'] = slug;
    if (title != null) {
      data['title'] = title!.toJson();
    }
    return data;
  }
}
