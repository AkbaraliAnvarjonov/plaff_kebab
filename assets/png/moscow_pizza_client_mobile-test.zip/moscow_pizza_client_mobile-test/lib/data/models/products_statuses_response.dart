class ProductsStatusesResponse {
  ProductsStatusesResponse({
      this.products,});

  ProductsStatusesResponse.fromJson(dynamic json) {
    if (json['products'] != null) {
      products = [];
      json['products'].forEach((v) {
        products?.add(Products.fromJson(v));
      });
    }
  }
  List<Products>? products;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (products != null) {
      map['products'] = products?.map((v) => v.toJson()).toList();
    }
    return map;
  }

}

class Products {
  Products({
      this.id, 
      this.menuId, 
      this.productId, 
      this.isActive,});

  Products.fromJson(dynamic json) {
    id = json['id'];
    menuId = json['menuId'];
    productId = json['productId'];
    isActive = json['isActive'];
  }
  String? id;
  String? menuId;
  String? productId;
  bool? isActive;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    map['menuId'] = menuId;
    map['productId'] = productId;
    map['isActive'] = isActive;
    return map;
  }

}
