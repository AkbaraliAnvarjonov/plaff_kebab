class ComputePriceResponse {
  num? distance;
  num? price;

  ComputePriceResponse({this.distance, this.price});

  ComputePriceResponse.fromJson(Map<String, dynamic> json) {
    distance = json['distance'];
    price = json['price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['distance'] = distance;
    data['price'] = price;
    return data;
  }
}
