import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';

class ProductFavouritesResponse {
  List<Favourites>? favourites;

  ProductFavouritesResponse({this.favourites});

  ProductFavouritesResponse.fromJson(Map<String, dynamic> json) {
    if (json['favourites'] != null) {
      favourites = <Favourites>[];
      json['favourites'].forEach((v) {
        favourites!.add(Favourites.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (favourites != null) {
      data['favourites'] = favourites!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
