import '../hive/products.dart';

class OrdersResponse {
  List<Orders> orders = [];
  String? count;

  OrdersResponse({this.orders = const [], this.count});

  OrdersResponse.fromJson(Map<String, dynamic> json) {
    orders = <Orders>[];
    if (json['orders'] != null) {
      json['orders'].forEach((v) {
        orders.add(Orders.fromJson(v));
      });
    }
    count = json['count'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['orders'] = orders.map((v) => v.toJson()).toList();
    data['count'] = count;
    return data;
  }
}

class Orders {
  ToLocation? toLocation;
  String? toAddress;
  String? clientName;
  String? clientPhoneNumber;
  int? coDeliveryPrice;
  int? deliveryPrice;
  String? description;
  String? externalOrderId;
  String? deliveryTime;
  String? deliveryType;
  String? id;
  String? clientId;
  String? courierId;
  Courier? courier;
  String? statusId;
  String? createdAt;
  String? finishedAt;
  String? paymentType;
  String? source;
  String? apartment;
  String? building;
  String? floor;
  String? extraPhoneNumber;
  num? orderAmount;
  bool? paid;
  String? rating;
  String? review;
  ShipperUser? shipperUser;
  List<Steps> steps = [];
  List<StatusNotes> statusNotes = [];
  List<DiscountsModel> discountsModel = [];
  dynamic jowiId;
  dynamic iikoId;
  dynamic distance;

  num? totalDiscountPrice;

  Orders({
    this.toLocation,
    this.toAddress,
    this.clientName,
    this.clientPhoneNumber,
    this.coDeliveryPrice,
    this.deliveryPrice,
    this.description,
    this.externalOrderId,
    this.deliveryTime,
    this.deliveryType,
    this.id,
    this.clientId,
    this.courierId,
    this.courier,
    this.statusId,
    this.createdAt,
    this.finishedAt,
    this.paymentType,
    this.source,
    this.apartment,
    this.building,
    this.floor,
    this.extraPhoneNumber,
    this.orderAmount,
    this.paid,
    this.rating,
    this.review,
    this.shipperUser,
    this.steps = const [],
    this.statusNotes = const [],
    this.jowiId,
    this.iikoId,
    this.distance,
    this.totalDiscountPrice,
    this.discountsModel = const [],
  });

  Orders.fromJson(Map<String, dynamic> json) {
    toLocation = json['to_location'] != null
        ? ToLocation.fromJson(json['to_location'])
        : null;
    toAddress = json['to_address'];
    clientName = json['client_name'];
    clientPhoneNumber = json['client_phone_number'];
    coDeliveryPrice = json['co_delivery_price'];
    deliveryPrice = json['delivery_price'];
    description = json['description'];
    externalOrderId = json['external_order_id'];
    deliveryTime = json['delivery_time'];
    deliveryType = json['delivery_type'];
    id = json['id'];
    clientId = json['client_id'];
    courierId = json['courier_id'];
    courier =
        json['courier'] != null ? Courier.fromJson(json['courier']) : null;
    statusId = json['status_id'];
    createdAt = json['created_at'];
    finishedAt = json['finished_at'];
    paymentType = json['payment_type'];
    source = json['source'];
    apartment = json['apartment'];
    building = json['building'];
    floor = json['floor'];
    extraPhoneNumber = json['extra_phone_number'];
    orderAmount = json['order_amount'];
    paid = json['paid'];
    rating = json['rating'];
    review = json['review'];
    steps = <Steps>[];
    if (json['steps'] != null) {
      json['steps'].forEach((v) {
        steps.add(Steps.fromJson(v));
      });
    }
    statusNotes = <StatusNotes>[];
    if (json['status_notes'] != null) {
      json['status_notes'].forEach((v) {
        statusNotes.add(StatusNotes.fromJson(v));
      });
    }
    discountsModel = <DiscountsModel>[];
    if (json['discounts'] != null) {
      json['discounts'].forEach(
        (v) {
          discountsModel.add(DiscountsModel.fromJson(v));
        },
      );
    }
    shipperUser = json['shipper_user'] != null
        ? ShipperUser.fromJson(json['shipper_user'])
        : null;
    jowiId = json['jowi_id'];
    iikoId = json['iiko_id'];
    distance = json['distance'];
    totalDiscountPrice = json['discount_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (toLocation != null) {
      data['to_location'] = toLocation?.toJson();
    }
    data['to_address'] = toAddress;
    data['client_name'] = clientName;
    data['client_phone_number'] = clientPhoneNumber;
    data['co_delivery_price'] = coDeliveryPrice;
    data['delivery_price'] = deliveryPrice;
    data['description'] = description;
    data['external_order_id'] = externalOrderId;
    data['delivery_time'] = deliveryTime;
    data['delivery_type'] = deliveryType;
    data['id'] = id;
    data['client_id'] = clientId;
    data['courier_id'] = courierId;
    if (courier != null) {
      data['courier'] = courier?.toJson();
    }
    data['status_id'] = statusId;
    data['created_at'] = createdAt;
    data['finished_at'] = finishedAt;
    data['payment_type'] = paymentType;
    data['source'] = source;
    data['apartment'] = apartment;
    data['building'] = building;
    data['floor'] = floor;
    data['extra_phone_number'] = extraPhoneNumber;
    data['order_amount'] = orderAmount;
    data['paid'] = paid;
    data['rating'] = rating;
    data['review'] = review;
    data['steps'] = steps.map((v) => v.toJson()).toList();
    data['status_notes'] = statusNotes.map((v) => v).toList();
    return data;
  }
}

class ToLocation {
  dynamic long;
  dynamic lat;

  ToLocation({this.long, this.lat});

  ToLocation.fromJson(Map<String, dynamic> json) {
    long = json['long'];
    lat = json['lat'];
  }

  // Map<String, dynamic> toJson() {
  //   final Map<String, dynamic> data = Map<String, dynamic>();
  //   data['long'] = this.long;
  //   data['lat'] = this.lat;
  //   return data;
  // }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['lat'] = lat;
    data['long'] = long;
    return data;
  }
}

class StatusNotes {
  String? id;
  String? orderId;
  String? statusId;
  String? description;
  String? createdAt;

  StatusNotes({
    this.id,
    this.orderId,
    this.statusId,
    this.description,
    this.createdAt,
  });

  StatusNotes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    orderId = json['order_id'];
    statusId = json['status_id'];
    description = json['description'];
    createdAt = json['created_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['order_id'] = orderId;
    data['status_id'] = statusId;
    data['description'] = description;
    data['created_at'] = createdAt;
    return data;
  }
}

class ShipperUser {
  String? id;
  String? name;
  String? phone;

  ShipperUser({this.id, this.name, this.phone});

  ShipperUser.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    phone = json['phone'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['phone'] = phone;
    return data;
  }
}

class Courier {
  String? phone;
  String? firstName;
  String? lastName;
  String? vehicleNumber;

  Courier({this.phone, this.firstName, this.lastName, this.vehicleNumber});

  Courier.fromJson(Map<String, dynamic> json) {
    phone = json['phone'];
    firstName = json['first_name'];
    lastName = json['last_name'];
    vehicleNumber = json['vehicle_number'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['phone'] = phone;
    data['first_name'] = firstName;
    data['last_name'] = lastName;
    data['vehicle_number'] = vehicleNumber;
    return data;
  }
}

class Steps {
  String? id;
  String? branchName;
  ToLocation? location;
  String? address;
  String? destinationAddress;
  String? phoneNumber;
  List<OrdersProducts> products = [];
  String? description;
  String? orderNo;
  String? status;
  num? stepAmount;
  dynamic externalStepId;
  String? branchId;

  Steps({
    this.id,
    this.branchName,
    this.location,
    this.address,
    this.destinationAddress,
    this.phoneNumber,
    this.products = const [],
    this.description,
    this.orderNo,
    this.status,
    this.stepAmount,
    this.externalStepId,
    this.branchId,
  });

  Steps.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    branchName = json['branch_name'];
    location =
        json['location'] != null ? ToLocation.fromJson(json['location']) : null;
    address = json['address'];
    destinationAddress = json['destination_address'];
    phoneNumber = json['phone_number'];
    products = <OrdersProducts>[];
    if (json['products'] != null) {
      json['products'].forEach((v) {
        products.add(OrdersProducts.fromJson(v));
      });
    }
    description = json['description'];
    orderNo = json['order_no'];
    status = json['status'];
    stepAmount = json['step_amount'];
    externalStepId = json['external_step_id'];
    branchId = json['branch_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['branch_id'] = branchId;
    data['description'] = description;
    data['products'] = products.map((v) => v.toJson()).toList();
    return data;
  }
}

class Modifiers {
  String? modifierId;
  ModifierName? modifierName;
  String? modifierQuantity;
  String? modifiersPrice;
  String? parentId;

  Modifiers(
      {this.modifierId,
      this.modifierName,
      this.modifierQuantity,
      this.modifiersPrice,
      this.parentId});

  Modifiers.fromJson(Map<String, dynamic> json) {
    modifierId = json['modifier_id'];
    modifierName = json['modifier_name'] != null
        ? ModifierName.fromJson(json['modifier_name'])
        : null;
    modifierQuantity = json['modifier_quantity'];
    modifiersPrice = json['modifier_price'];
    parentId = json['parent_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['modifier_id'] = modifierId;
    if (modifierName != null) {
      data['modifier_name'] = modifierName?.toJson();
    }
    data['modifier_quantity'] = modifierQuantity;
    data['modifier_price'] = modifiersPrice;
    data['parent_id'] = parentId;
    return data;
  }
}

class ModifierName {
  String? uz;
  String? ru;
  String? en;

  ModifierName({this.uz, this.ru, this.en});

  NameTitle parseTitle() {
    return NameTitle(
      uz: uz,
      ru: ru,
      en: en,
    );
  }

  ModifierName.fromJson(Map<String, dynamic> json) {
    uz = json['uz'];
    ru = json['ru'];
    en = json['en'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uz'] = uz;
    data['ru'] = ru;
    data['en'] = en;
    return data;
  }
}

class OrdersVariants {
  String? groupId;
  String? variantId;
  VariantName? variantName;
  int? quantity;

  OrdersVariants(
      {this.groupId, this.variantId, this.variantName, this.quantity});

  OrdersVariants.fromJson(Map<String, dynamic> json) {
    groupId = json['group_id'];
    variantId = json['variant_id'];
    variantName = json['variant_name'] != null
        ? VariantName.fromJson(json['variant_name'])
        : null;
    quantity = json['quantity'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['group_id'] = groupId;
    data['variant_id'] = variantId;
    if (variantName != null) {
      data['variant_name'] = variantName?.toJson();
    }
    data['quantity'] = quantity;
    return data;
  }
}

class VariantName {
  String? uz;
  String? ru;
  String? en;

  VariantName({this.uz, this.ru, this.en});

  VariantName.fromJson(Map<String, dynamic> json) {
    uz = json['uz'];
    ru = json['ru'];
    en = json['en'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['uz'] = uz;
    data['ru'] = ru;
    data['en'] = en;
    return data;
  }
}

class OrdersProducts {
  String? id;
  String? name;
  num? quantity;
  dynamic price;
  int? totalAmount;
  String? productId;
  String? externalProductId;
  String? description;
  String? type;
  List<Modifiers>? modifiers;
  List<OrdersVariants>? variants;
  num? discountPrice;

  OrdersProducts({
    this.variants,
    this.modifiers,
    this.id,
    this.name,
    this.quantity,
    this.price,
    this.totalAmount,
    this.productId,
    this.externalProductId,
    this.description,
    this.type,
    this.discountPrice,
  });

  OrdersProducts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    quantity = json['quantity'];
    price = json['price'];
    totalAmount = json['total_amount'];
    productId = json['product_id'];
    externalProductId = json['external_product_id'];
    description = json['description'];
    type = json['type'];
    if (json['order_modifiers'] != null) {
      modifiers = <Modifiers>[];
      json['order_modifiers'].forEach((v) {
        modifiers!.add(Modifiers.fromJson(v));
      });
    }
    if (json['variants'] != null) {
      variants = <OrdersVariants>[];
      json['variants'].forEach((v) {
        variants!.add(OrdersVariants.fromJson(v));
      });
    }
    discountPrice = json['discount_price'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['description'] = description;
    data['type'] = type;
    data['price'] = price;
    data['product_id'] = productId;
    data['quantity'] = quantity;
    if (modifiers != null) {
      data['order_modifiers'] = modifiers!.map((v) => v.toJson()).toList();
    }
    if (variants != null) {
      data['variants'] = variants!.map((v) => v.toJson()).toList();
    }
    data['discount_price'] = discountPrice;
    return data;
  }
}

class DiscountsModel {
  DiscountsModel({
    this.id,
    this.name,
    this.price,
    this.priority,
  });

  DiscountsModel.fromJson(dynamic json) {
    id = json['id'];
    name = json['name'] != null ? Name.fromJson(json['name']) : null;
    price = json['price'];
    priority = json['priority'];
  }

  String? id;
  Name? name;
  num? price;
  num? priority;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = id;
    if (name != null) {
      map['name'] = name?.toJson();
    }
    map['price'] = price;
    map['priority'] = priority;
    return map;
  }
}

class Name {
  Name({
    this.uz,
    this.ru,
    this.en,
  });

  Name.fromJson(dynamic json) {
    uz = json['uz'];
    ru = json['ru'];
    en = json['en'];
  }

  String? uz;
  String? ru;
  String? en;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['uz'] = uz;
    map['ru'] = ru;
    map['en'] = en;
    return map;
  }
}
