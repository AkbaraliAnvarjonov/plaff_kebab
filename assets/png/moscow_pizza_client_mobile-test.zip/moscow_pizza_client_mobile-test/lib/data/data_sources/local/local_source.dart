import 'package:moscow_pizza_client_mobile/data/hive/delivery_address_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/hive/pick_up_branch_hive_model.dart';
import 'package:hive/hive.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/core/constants/constants.dart';
import 'package:moscow_pizza_client_mobile/core/keys/app_keys.dart';
import 'package:moscow_pizza_client_mobile/data/hive/hive_databese.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';
import '../../hive/products.dart';

class LocalSource {
  static Box? _box;

  final _hiveDb = HiveDatabase.instance;

  LocalSource._();

  static LocalSource? _instance;

  static LocalSource get instance => _instance ?? LocalSource._();

  static Future<LocalSource> getInstance() async {
    if (_instance != null) {
      return _instance!;
    } else {
      _box = await Hive.openBox(AppKeys.localSource);
      _instance ??= LocalSource._();
      return LocalSource._();
    }
  }

  Future<void> updateQuantity({
    bool isMinus = false,
    bool isDelete = false,
    required Products product,
  }) async {
    if (isMinus) {
      if (product.quantity > 1) {
        product.quantity = product.quantity - 1;
        await updateProduct(product);
      } else if (isDelete) {
        await removeProduct(product);
      }
    } else {
      product.quantity = product.quantity + 1;
      await updateProduct(product);
    }
  }

  Future<void> setYandexKey(String value) async {
    await _box?.put(AppKeys.YANDEX_KEY, value);
  }

  String getYandexKey() {
    return _box?.get(AppKeys.YANDEX_KEY) ?? AppConstants.yandexApiKey;
  }

  Future<List<Products>> getAllBasketProductsAsync() {
    return _hiveDb.products();
  }

  Future<void> insertProduct(Products product) async {
    await _hiveDb.insertProduct(product);
  }

  Future<void> removeProduct(Products product) async {
    String uniqueId = BaseFunctions.stringLengthMax255(product.uniqueId);
    await _hiveDb.removeProduct(uniqueId);
  }

  Future<void> updateProduct(Products product) async {
    await _hiveDb.updateProduct(product);
  }

  Future<void> removeAll() async {
    await _hiveDb.removeAll();
  }

  Future<void> removeProfile() async {
    await _box?.delete('has_profile');
    await _box?.delete('customer_id');
    await _box?.delete('name');
    await _box?.delete('phone');
    await _box?.delete('access_token');
    await _box?.delete('refresh_token');
    await clearPickUpBranch();
    await clearDeliveryAddress();
  }

  bool get hasProfile => _box?.get('has_profile') ?? false;

  Future<void> setCustomer(Customer customer) async {
    await _box?.put('has_profile', true);
    await _box?.put('customer_id', customer.id);
    await _box?.put('name', customer.name);
    await _box?.put('phone', customer.phone);
    await _box?.put('date_of_birth', customer.dateOfBirth);
    await _box?.put('access_token', customer.accessToken);
    await _box?.put('refresh_token', customer.refreshToken);
  }

  Future<void> setFcmToken(String value) async {
    await _box?.put(AppKeys.FCM_TOKEN, value);
  }

  String getFcmToken() {
    return _box?.get(AppKeys.FCM_TOKEN) ?? '';
  }

  String getAccessToken() {
    return _box?.get('access_token') ?? '';
  }

  String get locale => _box?.get('locale') ?? BaseFunctions.getDefaultLocale();

  bool get hasLocale => _box?.get('locale') == null;

  bool getNotification() {
    return _box?.get('notification') ?? true;
  }

  Future<void> setLocale(String value) async {
    await _box?.put('locale', value);
  }

  Future<void> setNotification(bool value) async {
    await _box?.put('notification', value);
  }

  String getRefreshToken() {
    return _box?.get('refresh_token') ?? '';
  }

  Customer getCustomer() => Customer(
        id: _box?.get('customer_id') ?? '',
        name: _box?.get('name') ?? '',
        phone: _box?.get('phone') ?? '',
        dateOfBirth: _box?.get('date_of_birth') ?? '',
        accessToken: _box?.get('access_token') ?? '',
        refreshToken: _box?.get('refresh_token') ?? '',
      );

  bool getUpdateDialog() {
    return _box?.get('update_dialog') ?? true;
  }

  Future<void> setUpdateDialog(bool b) async {
    await _box?.put('update_dialog', b);
  }

  Future<void> setRefreshedTokens(
      {required String refreshToken, required String accessToken}) async {
    await _box?.put('refresh_token', refreshToken);
    await _box?.put('access_token', accessToken);
  }

  Future<void> setMenuId(String menuId) async {
    await _box?.put(AppKeys.MENU_ID, menuId);
  }

  Future<void> setPickUpBranch({
    required PickUpBranchHiveModel branch,
  }) async {
    await _hiveDb.setPickUpBranch(
      branch: branch,
    );
  }

  Future<PickUpBranchHiveModel?> getPickUpBranch() async {
    var pickUpBranch = await _hiveDb.getPickUpBranch();
    return pickUpBranch;
  }

  Future<void> clearPickUpBranch() async {
    await _hiveDb.clearPickUpBranch();
  }

  Future<void> setDeliveryAddress({
    required DeliveryAddressHiveModel address,
  }) async {
    await _hiveDb.setDeliveryAddress(address: address);
  }

  Future<DeliveryAddressHiveModel?> getDeliveryAddress() async {
    var address = await _hiveDb.getDeliveryAddress();
    return address;
  }

  Future<void> clearDeliveryAddress() async {
    await _hiveDb.clearDeliveryAddress();
  }

  Future<String> getMenuId() async {
    return await _box?.get(AppKeys.MENU_ID) ?? '';
  }

  bool getRefresh() {
    return _box?.get('is_refresh') ?? false;
  }

  Future<void> setRefresh(bool b) async {
    await _box?.put('is_refresh', b);
  }

  Future<void> setKey(String key, String value) async {
    await _box?.put(key, value);
  }

  String? getKey(String key) {
    return _box?.get(key);
  }
}
