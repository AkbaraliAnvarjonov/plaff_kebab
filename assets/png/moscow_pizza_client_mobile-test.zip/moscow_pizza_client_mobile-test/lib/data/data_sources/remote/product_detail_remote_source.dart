import 'dart:io';

import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:moscow_pizza_client_mobile/data/models/combo_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_favourite_response.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class ProductDetailRemoteSource {
  ApiClient apiClient;

  ProductDetailRemoteSource({required this.apiClient});

  Future<ResponseHandler<ProductByIdResponse>> fetchProductDetailV2({
    required String shipperId,
    required String productId,
    bool isOnlyDelivery = false,
    bool isOnlySelfPickUp = false,
    String branchId = '',
    String clientId = '',
  }) async {
    ProductByIdResponse response;
    try {
      response = await apiClient.getProductDetailV2(
        shipperId,
        productId,
        true,
        isOnlyDelivery,
        isOnlySelfPickUp,
          branchId,
        clientId,
        Platform.operatingSystem,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ModifierResponse>> fetchProductModifierV2(
      {required String auth,
      required String shipperId,
      required String productId}) async {
    ModifierResponse response;
    try {
      response =
          await apiClient.getProductModifierV2(auth, shipperId, productId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ComboResponse>> fetchComboV2(
      {required String auth,
      required String shipperId,
      required String comboId}) async {
    ComboResponse response;
    try {
      response = await apiClient.getComboV2(auth, shipperId, comboId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ProductFavouritesResponse>> fetchProductFavourites({
    required String shipperId,
    required String productIds,
    // required String branchId,
    required String orderSource,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required String clientId,
    required bool isWithDiscounts,
  }) async {
    ProductFavouritesResponse response;
    try {
      response = await apiClient.getProductFavourites(
        shipperId,
        productIds,
        // branchId,
        orderSource,
        isOnlyDelivery,
        isOnlySelfPickUp,
        clientId,
        isWithDiscounts,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
