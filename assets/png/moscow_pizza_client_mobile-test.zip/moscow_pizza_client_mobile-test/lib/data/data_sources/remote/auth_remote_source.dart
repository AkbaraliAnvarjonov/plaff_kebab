import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/check_custome_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/check_customer_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/confirm_login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/confirm_register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class AuthRemoteSource {
  final ApiClient _apiClient;

  AuthRemoteSource(this._apiClient);

  Future<ResponseHandler<CheckCustomerResponse>> fetchCheckCustomerExits({
    required String shipperId,
    required CheckCustomerRequest request,
  }) async {
    CheckCustomerResponse response;
    try {
      response = await _apiClient.checkCustomer(shipperId, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<BaseResponse>> fetchLogin(
      {required String shipperId, required LoginRequest request}) async {
    BaseResponse response;
    try {
      response = await _apiClient.login(shipperId, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<BaseResponse>> fetchRegister(
      {required String shipperId, required RegisterRequest request}) async {
    BaseResponse response;
    try {
      response = await _apiClient.register(shipperId, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<Customer>> fetchConfirmRegister(
      {required String shipperId,
      required String platform,
      required ConfirmRegisterRequest request}) async {
    Customer response;
    try {
      response = await _apiClient.confirmRegister(shipperId, platform, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<Customer>> fetchConfirmLogin(
      {required String shipperId,
      required String platform,
      required ConfirmLoginRequest request}) async {
    Customer response;
    try {
      response = await _apiClient.confirmLogin(shipperId, platform, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
