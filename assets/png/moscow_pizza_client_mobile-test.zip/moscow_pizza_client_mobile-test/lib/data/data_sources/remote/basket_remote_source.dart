import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';

import '../../models/product_favourite_response.dart';
import '../../provider/remote/api_client.dart';
import '../../provider/remote/response_handler.dart';
import '../../provider/remote/server_error.dart';

class BasketRemoteSource {
  ApiClient apiClient;

  BasketRemoteSource({required this.apiClient});

  Future<ResponseHandler<ProductFavouritesResponse>> fetchProductFavourites({
    required String shipperId,
    required String productIds,
    // required String branchId,
    required String orderSource,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required String clientId,
    required bool isWithDiscounts,
  }) async {
    ProductFavouritesResponse response;
    try {
      response = await apiClient.getProductFavourites(
        shipperId,
        productIds,
        // branchId,
        orderSource,
        isOnlyDelivery,
        isOnlySelfPickUp,
        clientId,
        isWithDiscounts,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
