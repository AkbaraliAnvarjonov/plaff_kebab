import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';
import 'package:moscow_pizza_client_mobile/data/models/delete_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/update_version_response.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class ProfileRemoteSource {
  ApiClient apiClient;

  ProfileRemoteSource({required this.apiClient});

  Future<ResponseHandler<BaseResponse>> fetchUpdatedCustomers(
      {required String token,
      required String customerId,
      required Customer customer}) async {
    BaseResponse response;
    try {
      response = await apiClient.updateCustomer(token, customerId, customer);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<DeleteAddressResponse>> fetchDeleteCustomerAccount({
    required String token,
    required String customerId,
  }) async {
    DeleteAddressResponse response;
    try {
      response = await apiClient.deleteCustomerAccount(token, customerId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<Customer>> fetchCustomers({
    required String token,
    required String customerId,
  }) async {
    Customer response;
    try {
      response = await apiClient.getCustomers(token, customerId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<UpdateVersionResponse>> fetchAppVersion({
    required String token,
    required String appName,
  }) async {
    UpdateVersionResponse response;
    try {
      response = await apiClient.getAppVersion(token, appName);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<BranchesResponse>> fetchBranches({
    required String token,
    required String shipperId,
    int page = 1,
    int limit = 100,
  }) async {
    BranchesResponse response;
    try {
      response = await apiClient.getBranches(token, shipperId, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<Branches>> fetchBranchesId({
    required String token,
    required String branchId,
  }) async {
    Branches response;
    try {
      response = await apiClient.getBranchesId(token, branchId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
