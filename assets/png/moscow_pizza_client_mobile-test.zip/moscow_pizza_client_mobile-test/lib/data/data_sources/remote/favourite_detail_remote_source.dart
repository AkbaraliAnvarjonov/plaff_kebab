import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:moscow_pizza_client_mobile/data/models/combo_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/modifier_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_by_id_response.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class FavouriteDetailRemoteSource {
  ApiClient apiClient;

  FavouriteDetailRemoteSource({required this.apiClient});

  Future<ResponseHandler<ProductByIdResponse>> fetchProductDetailV2(
      {required String shipperId, required String productId}) async {
    ProductByIdResponse response;
    try {
      response = await apiClient.getProductDetailV2(
          shipperId, productId, false, false, false, '', '', '');
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ModifierResponse>> fetchProductModifierV2(
      {required String auth,
      required String shipperId,
      required String productId}) async {
    ModifierResponse response;
    try {
      response =
          await apiClient.getProductModifierV2(auth, shipperId, productId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ComboResponse>> fetchComboV2(
      {required String auth,
      required String shipperId,
      required String comboId}) async {
    ComboResponse response;
    try {
      response = await apiClient.getComboV2(auth, shipperId, comboId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
