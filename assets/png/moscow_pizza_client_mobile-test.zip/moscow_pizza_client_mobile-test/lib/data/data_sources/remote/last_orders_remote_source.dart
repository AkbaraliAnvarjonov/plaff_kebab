import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/saved_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class LastOrdersRemoteSource {
  final ApiClient _apiClient;

  LastOrdersRemoteSource(this._apiClient) ;

  Future<ResponseHandler<OrdersResponse>> fetchLastOrders({
    required String token,
    required int page,
    required int limit,
  }) async {
    OrdersResponse response;
    try {
      response = await _apiClient.getLastOrders(token, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<SavedAddressResponse>> fetchSavedAddresses({
    required String token,
    required String customerId,
    required int page,
    required int limit,
  }) async {
    SavedAddressResponse response;
    try {
      response =
          await _apiClient.getSavedAddresses(token, customerId, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
