import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class OrdersRemoteSource {
  final ApiClient _apiClient;

  OrdersRemoteSource(this._apiClient);

  Future<ResponseHandler<OrdersResponse>> fetchOrders({
    required String token,
    required int page,
    required int limit,
    required List<String> statusIds,
    required String startDate,
    required String endDate,
  }) async {
    OrdersResponse response;
    try {
      response = await _apiClient.getOrders(
          token, page, limit, [statusIds.join(',')], startDate, endDate);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<OrdersResponse>> fetchOrdersReview({
    required String token,
    required int page,
    required int limit,
    required String startDate,
    required String endDate,
    required bool reviewSeen,
  }) async {
    OrdersResponse response;
    try {
      response = await _apiClient.getOrdersReview(
          token, page, limit, startDate, endDate, reviewSeen);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<Orders>> fetchOrdersDetail({
    required String token,
    required String ordersId,
  }) async {
    Orders response;
    try {
      response = await _apiClient.getOrdersDetail(token, ordersId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<OndemandOrderResponse>> fetchAddOndemandOrder({
    required String token,
    required OnDemandOrderRequest request,
  }) async {
    OndemandOrderResponse response;
    try {
      response = await _apiClient.addOnDemandOrder(token, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
