import 'dart:io';

import 'package:moscow_pizza_client_mobile/data/models/order_discount_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/product_discount_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/products_statuses_response.dart';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:moscow_pizza_client_mobile/data/models/banners_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_id_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/base_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/branch/branches_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/category_v2_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/compute_price_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/compute_price_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/create_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/delete_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/products_v2_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/reviews_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/shipper_response.dart';
import 'package:moscow_pizza_client_mobile/data/models/user_reviews_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/user_update_reviews_request.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class HomeRemoteSource {
  ApiClient apiClient;

  HomeRemoteSource({required this.apiClient});

  Future<ResponseHandler<BannersResponse>> fetchBanners({
    required String shipperId,
    required int page,
    required int limit,
  }) async {
    BannersResponse response;
    try {
      response = await apiClient.getBanners(shipperId, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<CategoryV2Response>> fetchCategoryWithProductsV2({
    required String shipperId,
    int page = 1,
    int limit = 1000,
    String menuId = '',
    bool isOnlyDelivery = false,
    bool isOnlySelfPickUp = false,
    String branchId = '',
    String clientId = '',
  }) async {
    CategoryV2Response response;
    try {
      response = await apiClient.getCategoryWithProductV2(
        shipperId,
        menuId,
        page,
        limit,
        true,
        true,
        isOnlyDelivery,
        isOnlySelfPickUp,
        branchId,
        clientId,
        Platform.operatingSystem,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ProductsV2Response>> fetchSearchProductsV2({
    required String shipperId,
    required String search,
    int page = 1,
    int limit = 1000,
  }) async {
    ProductsV2Response response;
    try {
      response = await apiClient.getProductsV2(shipperId, search, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<BranchesResponse>> fetchBranches({
    required String token,
    required String shipperId,
    int page = 1,
    int limit = 100,
  }) async {
    BranchesResponse response;
    try {
      response = await apiClient.getBranches(token, shipperId, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<OrderDiscountResponse>> getOrderDiscount({
    required String shipperId,
    required String orderSource,
    required String branchId,
    required String paymentType,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required int forOrderAmount,
    required int deliveryPrice,
    required String clientId,
  }) async {
    OrderDiscountResponse response;
    try {
      response = await apiClient.getOrderDiscount(
        shipperId,
        orderSource,
        branchId,
        paymentType,
        isOnlyDelivery,
        isOnlySelfPickUp,
        forOrderAmount,
        deliveryPrice,
        clientId,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ProductDiscountResponse>> getProductDiscount({
    required String shipperId,
    required String orderSource,
    required String branchId,
    required List<String> productIds,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required String clientId,
  }) async {
    ProductDiscountResponse response;
    try {

      response = await apiClient.getProductDiscount(
        shipperId,
        orderSource,
        branchId,
        productIds.join(','),
        isOnlyDelivery,
        isOnlySelfPickUp,
        clientId,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }


  Future<ResponseHandler<BranchesResponse>> fetchNearBranches({
    required String token,
    required String shipperId,
    required String lat,
    required String long,
  }) async {
    BranchesResponse response;
    try {
      response = await apiClient.getNearBranches(token, shipperId, lat, long);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ComputePriceResponse>> fetchComputePrice({
    required String token,
    required ComputePriceRequest request,
  }) async {
    ComputePriceResponse response;
    try {
      response = await apiClient.patchComputePrice(token, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<OndemandOrderResponse>> fetchAddOnDemandOrder({
    required String token,
    required OnDemandOrderRequest request,
  }) async {
    OndemandOrderResponse response;
    try {
      response = await apiClient.addOnDemandOrder(token, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ReviewsResponse>> fetchReview({
    required String token,
    required int page,
    required int limit,
  }) async {
    ReviewsResponse response;
    try {
      response = await apiClient.review(token, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<BaseIdResponse>> fetchCreateUserReview({
    required String token,
    required UserReviewsRequest request,
  }) async {
    BaseIdResponse response;
    try {
      response = await apiClient.createUserReview(token, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<BaseResponse>> fetchUpdateUserReview({
    required String token,
    required String orderId,
    required UserUpdateReviewsRequest request,
  }) async {
    BaseResponse response;
    try {
      response = await apiClient.updateUserReview(token, orderId, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<MyAddressResponse>> fetchMyAddress({
    required String token,
    required String shipperId,
    required String customerId,
    required int page,
    required int limit,
  }) async {
    MyAddressResponse response;
    try {
      response = await apiClient.getMyAddress(
          token, shipperId, customerId, page, limit);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ShipperResponse>> fetchShipper({
    required String shipperId,
  }) async {
    ShipperResponse response;
    try {
      response = await apiClient.getShipper(shipperId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<CreateAddressResponse>> createMyAddress({
    required String token,
    required String shipperId,
    required MyAddressRequest request,
  }) async {
    CreateAddressResponse response;
    try {
      response = await apiClient.postMyAddress(token, shipperId, request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<DeleteAddressResponse>> deleteAddress({
    required String token,
    required String addressId,
  }) async {
    DeleteAddressResponse response;
    try {
      response = await apiClient.deleteSavedAddress(token, addressId);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<ResponseHandler<ProductsStatusesResponse>> getProductsStatuses({
    required String token,
    required String shipperId,
    required String menuId,
    required String productsIds,
  }) async {
    ProductsStatusesResponse response;
    try {
      response = await apiClient.getProductsStatuses(
        token,
        shipperId,
        menuId,
        productsIds,
      );
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }
}
