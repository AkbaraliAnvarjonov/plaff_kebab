import 'package:hive/hive.dart';
import 'package:moscow_pizza_client_mobile/data/models/orders_response.dart';

part 'products.g.dart';

@HiveType(typeId: 0, adapterName: 'ProductAdapter')
class Products extends HiveObject {
  @HiveField(0)
  String id;
  @HiveField(1)
  NameTitle? name;
  @HiveField(2)
  double price;
  @HiveField(3)
  double quantity;
  @HiveField(4)
  String image;
  @HiveField(5)
  List<Modifiers>? modifiers;
  @HiveField(6)
  String uniqueId;
  @HiveField(7)
  List<Combo>? combos;
  @HiveField(8)
  String? type;
  @HiveField(9)
  double discounts;

  Products({
    required this.id,
    required this.image,
    required this.name,
    required this.price,
    required this.quantity,
    required this.modifiers,
    required this.uniqueId,
    this.discounts = 0,
    this.combos,
    this.type,
  });

  double getAllPrice() {
    double modifiersPrices = 0;
    for (int i = 0; i < (modifiers ?? []).length; i++) {
      modifiersPrices += ((modifiers?[i].addModifierPrice ?? true) ? 0 : (modifiers?[i].modifiersPrice ?? 0)) *
          (modifiers?[i].modifierQuantity ?? 0);
    }
    return modifiersPrices + 
        ((price + discounts) * quantity);
  }
}

@HiveType(typeId: 1, adapterName: 'ModifierAdapter')
class Modifiers extends HiveObject {
  @HiveField(0)
  String modifierId;
  @HiveField(1)
  NameTitle? modifierName;
  @HiveField(2)
  int modifierQuantity;
  @HiveField(3)
  int modifiersPrice;
  @HiveField(4)
  String parentId;
  @HiveField(5)
  bool? addModifierPrice;

  Modifiers({
    required this.modifierName,
    required this.modifierId,
    required this.modifierQuantity,
    required this.modifiersPrice,
    required this.parentId,
    this.addModifierPrice = true,
  });

  @override
  String toString() {
    return 'Modifiers{modifierId: $modifierId, modifierName: $modifierName, modifierQuantity: $modifierQuantity, modifiersPrice: $modifiersPrice, parentId: $parentId, addModifierPrice: $addModifierPrice}';
  }
}

@HiveType(typeId: 2, adapterName: 'ComboAdapter')
class Combo extends HiveObject {
  @HiveField(0)
  String groupId;
  @HiveField(1)
  String variantId;
  @HiveField(2)
  NameTitle? variantName;
  @HiveField(3)
  int quantity;

  Combo({
    required this.groupId,
    required this.variantId,
    required this.variantName,
    required this.quantity,
  });
}

@HiveType(typeId: 3, adapterName: 'NameTitleAdapter')
class NameTitle extends HiveObject {
  @HiveField(0)
  String? uz;
  @HiveField(1)
  String? ru;
  @HiveField(2)
  String? en;

  NameTitle({
    this.uz,
    this.ru,
    this.en,
  });

  ModifierName? parseTitle() {
    return ModifierName(
      uz: uz,
      ru: ru,
      en: en,
    );
  }
}
