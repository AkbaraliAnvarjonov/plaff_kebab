// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'delivery_address_hive_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class DeliveryAddressAdapter extends TypeAdapter<DeliveryAddressHiveModel> {
  @override
  final int typeId = 4;

  @override
  DeliveryAddressHiveModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return DeliveryAddressHiveModel(
      branchId: fields[0] as String?,
      addressName: fields[1] as String?,
      latitude: fields[2] as num?,
      longitude: fields[3] as num?,
    );
  }

  @override
  void write(BinaryWriter writer, DeliveryAddressHiveModel obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.branchId)
      ..writeByte(1)
      ..write(obj.addressName)
      ..writeByte(2)
      ..write(obj.latitude)
      ..writeByte(3)
      ..write(obj.longitude);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DeliveryAddressAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
