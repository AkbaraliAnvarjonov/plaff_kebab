import 'package:hive/hive.dart';

part 'pick_up_branch_hive_model.g.dart';

@HiveType(typeId: 5, adapterName: 'PickUpBranchAdapter')
class PickUpBranchHiveModel extends HiveObject {
  @HiveField(0)
  final String? branchId;
  @HiveField(1)
  final String? branchName;
  @HiveField(2)
  final num? latitude;
  @HiveField(3)
  final num? longitude;

  PickUpBranchHiveModel({
    this.branchId,
    this.branchName,
    this.latitude,
    this.longitude,
  });
}
