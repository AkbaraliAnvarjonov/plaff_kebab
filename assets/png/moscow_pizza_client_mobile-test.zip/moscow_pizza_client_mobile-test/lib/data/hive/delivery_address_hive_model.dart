import 'package:hive_flutter/hive_flutter.dart';

part 'delivery_address_hive_model.g.dart';

@HiveType(typeId: 4, adapterName: 'DeliveryAddressAdapter')
class DeliveryAddressHiveModel extends HiveObject {
  @HiveField(0)
  final String? branchId;
  @HiveField(1)
  final String? addressName;
  @HiveField(2)
  final num? latitude;
  @HiveField(3)
  final num? longitude;

  DeliveryAddressHiveModel({
    this.branchId,
    this.addressName,
    this.latitude,
    this.longitude,
  });
}
