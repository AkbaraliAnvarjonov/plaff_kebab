import 'package:moscow_pizza_client_mobile/core/keys/app_keys.dart';
import 'package:moscow_pizza_client_mobile/data/hive/delivery_address_hive_model.dart';
import 'package:moscow_pizza_client_mobile/data/hive/pick_up_branch_hive_model.dart';
import 'package:hive/hive.dart';
import 'package:moscow_pizza_client_mobile/base/base_functions.dart';
import 'package:moscow_pizza_client_mobile/data/hive/products.dart';


class HiveDatabase {
  static Box<Products>? _boxProduct;
  static Box<DeliveryAddressHiveModel>? _deliveryAddressBox;
  static Box<PickUpBranchHiveModel>? _pickUpBranchBox;
  static HiveDatabase instance = HiveDatabase._();

  HiveDatabase._();

  static Future<HiveDatabase> getInstance() async {
    _boxProduct ??= await Hive.openBox<Products>(AppKeys.productsHiveKey);
    _deliveryAddressBox ??= await Hive.openBox<DeliveryAddressHiveModel>(
        AppKeys.deliveryAddressBoxKey);
    _pickUpBranchBox ??=
        await Hive.openBox<PickUpBranchHiveModel>(AppKeys.pickUpBranchBoxKey);
    return instance;
  }

  Future<void> setPickUpBranch({
    required PickUpBranchHiveModel branch,
  }) async {
    await _pickUpBranchBox?.put(
      AppKeys.PICK_UP_BRANCH,
      branch,
    );
  }

  Future<PickUpBranchHiveModel?> getPickUpBranch() async {
    var pickUpBranch = _pickUpBranchBox?.get(
      AppKeys.PICK_UP_BRANCH,
    );
    return pickUpBranch;
  }

  Future<void> clearPickUpBranch() async {
    await _pickUpBranchBox?.delete(AppKeys.PICK_UP_BRANCH);
  }

  Future<void> setDeliveryAddress({
    required DeliveryAddressHiveModel address,
  }) async {
    await _deliveryAddressBox?.put(
      AppKeys.DELIVERY_ADDRESS,
      address,
    );
  }

  Future<DeliveryAddressHiveModel?> getDeliveryAddress() async {
    var address = _deliveryAddressBox?.get(AppKeys.DELIVERY_ADDRESS);
    return address;
  }

  Future<void> clearDeliveryAddress() async {
    await _deliveryAddressBox?.delete(AppKeys.DELIVERY_ADDRESS);
  }

  Future<List<Products>> products() async {
    return (_boxProduct?.values ?? []).toList();
  }

  Future<void> insertProduct(Products product) async {
    String uniqueId = BaseFunctions.stringLengthMax255(product.uniqueId);
    await _boxProduct?.put(uniqueId, product);
  }

  Future<void> removeProduct(String id) async {
    await _boxProduct?.delete(id);
  }

  Future<void> updateProduct(Products product) async {
    String uniqueId = BaseFunctions.stringLengthMax255(product.uniqueId);
    await _boxProduct?.put(uniqueId, product);
  }

  Future<void> removeAll() async {
    await _boxProduct?.clear();
  }
}
