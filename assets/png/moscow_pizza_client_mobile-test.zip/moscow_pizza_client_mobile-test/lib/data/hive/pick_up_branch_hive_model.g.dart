// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pick_up_branch_hive_model.dart';

// **************************************************************************
// TypeAdapterGenerator
// **************************************************************************

class PickUpBranchAdapter extends TypeAdapter<PickUpBranchHiveModel> {
  @override
  final int typeId = 5;

  @override
  PickUpBranchHiveModel read(BinaryReader reader) {
    final numOfFields = reader.readByte();
    final fields = <int, dynamic>{
      for (int i = 0; i < numOfFields; i++) reader.readByte(): reader.read(),
    };
    return PickUpBranchHiveModel(
      branchId: fields[0] as String?,
      branchName: fields[1] as String?,
      latitude: fields[2] as num?,
      longitude: fields[3] as num?,
    );
  }

  @override
  void write(BinaryWriter writer, PickUpBranchHiveModel obj) {
    writer
      ..writeByte(4)
      ..writeByte(0)
      ..write(obj.branchId)
      ..writeByte(1)
      ..write(obj.branchName)
      ..writeByte(2)
      ..write(obj.latitude)
      ..writeByte(3)
      ..write(obj.longitude);
  }

  @override
  int get hashCode => typeId.hashCode;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PickUpBranchAdapter &&
          runtimeType == other.runtimeType &&
          typeId == other.typeId;
}
