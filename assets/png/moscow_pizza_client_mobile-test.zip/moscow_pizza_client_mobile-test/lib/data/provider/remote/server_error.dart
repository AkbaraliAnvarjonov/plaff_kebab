import 'package:dio/dio.dart' hide Headers;
import 'package:get/get.dart';

class ServerError implements Exception {
  int? _errorCode;
  String _errorMessage = '';

  ServerError.withError({required DioException error}) {
    _handleError(error);
  }

  ServerError.error({required String error}) {
    _errorMessage = error;
  }

  int? get errorCode => _errorCode;

  String get errorMessage => _errorMessage;

  String _handleError(DioException error) {
    _errorCode = error.response?.statusCode ?? 500;
    if (_errorCode == 401 || _errorCode == 403) {
      _errorMessage = 'unauthorized'.tr;
      return _errorMessage;
    }
    if (_errorCode == 500) {
      _errorMessage = 'try_later'.tr;
      return _errorMessage;
    }
    if (_errorCode == 502) {
      _errorMessage = 'server_is_down'.tr;
      return _errorMessage;
    }
    if (_errorCode == 404) {
      _errorMessage = 'not_found'.tr;
      return _errorMessage;
    }
    if (_errorCode == 400) {
      _errorMessage = 'company_not_working_time'.tr;
      return _errorMessage;
    }
    switch (error.type) {
      case DioExceptionType.connectionError:
        _errorMessage = 'Connection error';
        break;
      case DioExceptionType.badCertificate:
        _errorMessage = 'Bad Certificate';
        break;
      case DioExceptionType.connectionTimeout:
        _errorMessage = 'try_later'.tr;
        break;
      case DioExceptionType.sendTimeout:
        _errorMessage = 'try_later'.tr;
        break;
      case DioExceptionType.receiveTimeout:
        _errorMessage = 'try_later'.tr;
        break;
      case DioExceptionType.badResponse:
        {
          if (error.response?.data != null && error.response?.data is String) {
            _errorMessage = error.response?.data;
          } else if (error.response?.data['Error'] is Map<String, dynamic>) {
            _errorMessage = error.response!.data['Error']['message'].toString();
          } else {
            _errorMessage = error.response!.data['message'].toString();
          }
          break;
        }
      case DioExceptionType.cancel:
        _errorMessage = 'try_later'.tr;
        break;
      case DioExceptionType.unknown:
        _errorMessage = 'something_wrong'.tr;
        break;
    }
    return _errorMessage;
  }
}
