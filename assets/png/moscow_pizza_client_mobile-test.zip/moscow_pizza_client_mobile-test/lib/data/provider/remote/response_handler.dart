import 'server_error.dart';

class ResponseHandler<T> {
  ServerError? _error;
  T? data;

  void setException(ServerError error) {
    _error = error;
  }

  void setData(T data) {
    this.data = data;
  }

  ServerError? getException() => _error;
}
