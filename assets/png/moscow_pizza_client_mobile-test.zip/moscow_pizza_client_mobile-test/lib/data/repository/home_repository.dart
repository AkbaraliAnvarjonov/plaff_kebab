import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/home_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/compute_price_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/my_address_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/user_reviews_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/user_update_reviews_request.dart';

class HomeRepository extends BaseRepository {
  final HomeRemoteSource remoteSource;

  HomeRepository({required this.remoteSource}) ;

  Future<dynamic> getBanners({required String shipperId}) async {
    final response = await remoteSource.fetchBanners(
        shipperId: shipperId, limit: 100, page: 1);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getCategoryWithProductsV2({
    required String shipperId,
    String? menuId,
    bool isOnlyDelivery = false,
    bool isOnlySelfPickUp = false,
    String branchId = '',
    String clientId = '',
  }) async {
    final response = await remoteSource.fetchCategoryWithProductsV2(
      shipperId: shipperId,
      menuId: menuId ?? '',
      clientId: clientId,
      isOnlyDelivery: isOnlyDelivery,
      isOnlySelfPickUp: isOnlySelfPickUp,
      branchId: branchId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getSearchProductsV2(
      {required String shipperId,
      required String search,
      int limit = 1000,
      int page = 1}) async {
    final response = await remoteSource.fetchSearchProductsV2(
        shipperId: shipperId, search: search, limit: limit, page: page);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getBranches({
    required String token,
    required String shipperId,
  }) async {
    final response =
        await remoteSource.fetchBranches(token: token, shipperId: shipperId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getOrderDiscount({
    required String shipperId,
    required String orderSource,
    required String branchId,
    required String paymentType,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required int forOrderAmount,
    required int deliveryPrice,
    required String clientId,
  }) async {
    final response = await remoteSource.getOrderDiscount(
      shipperId: shipperId,
      orderSource: orderSource,
      branchId: branchId,
      paymentType: paymentType,
      isOnlyDelivery: isOnlyDelivery,
      isOnlySelfPickUp: isOnlySelfPickUp,
      forOrderAmount: forOrderAmount,
      deliveryPrice: deliveryPrice,
      clientId: clientId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getProductDiscount({
    required String shipperId,
    required String orderSource,
    required String branchId,
    required List<String> productIds,
    required String paymentType,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required int forOrderAmount,
    required int deliveryPrice,
    required String clientId,
  }) async {
    final response = await remoteSource.getProductDiscount(
      shipperId: shipperId,
      orderSource: orderSource,
      branchId: branchId,
      productIds: productIds,
      isOnlyDelivery: isOnlyDelivery,
      isOnlySelfPickUp: isOnlySelfPickUp,
      clientId: clientId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }


  Future<dynamic> getNearBranches({
    required String token,
    required String shipperId,
    required String lat,
    required String long,
  }) async {
    final response = await remoteSource.fetchNearBranches(
      token: token,
      shipperId: shipperId,
      lat: lat,
      long: long,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> patchComputePrice({
    required String token,
    required ComputePriceRequest request,
  }) async {
    final response = await remoteSource.fetchComputePrice(
      token: token,
      request: request,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> addOnDemandOrder({
    required String token,
    required OnDemandOrderRequest request,
  }) async {
    final response = await remoteSource.fetchAddOnDemandOrder(
        token: token, request: request);
    if (response.data != null) {
      return response.data;
    }
    // else if(response.getException()?.getErrorCode()==400){
    //   return 'null';
    // }
    else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> review({
    required String token,
    required int page,
    required int limit,
  }) async {
    final response = await remoteSource.fetchReview(
      token: token,
      page: page,
      limit: limit,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> createUserReview({
    required String token,
    required UserReviewsRequest request,
  }) async {
    final response = await remoteSource.fetchCreateUserReview(
        token: token, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> updateUserReview({
    required String token,
    required String orderId,
    required UserUpdateReviewsRequest request,
  }) async {
    final response = await remoteSource.fetchUpdateUserReview(
        orderId: orderId, token: token, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getShipper({
    required String shipperId,
  }) async {
    final response = await remoteSource.fetchShipper(
      shipperId: shipperId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getMyAddress({
    required String token,
    required String shipperId,
    required String customerId,
    required int page,
    required int limit,
  }) async {
    final response = await remoteSource.fetchMyAddress(
      token: token,
      shipperId: shipperId,
      customerId: customerId,
      page: page,
      limit: limit,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> postMyAddress({
    required String token,
    required String shipperId,
    required MyAddressRequest request,
  }) async {
    final response = await remoteSource.createMyAddress(
        token: token, shipperId: shipperId, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> deleteMyAddress({
    required String token,
    required String customerAddressId,
  }) async {
    final response = await remoteSource.deleteAddress(
        token: token, addressId: customerAddressId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getProductsStatuses({
    required String token,
    required String shipperId,
    required String menuId,
    required String productsIds,
  }) async {
    final response = await remoteSource.getProductsStatuses(
      token: token,
      shipperId: shipperId,
      menuId: menuId,
      productsIds: productsIds,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }
}
