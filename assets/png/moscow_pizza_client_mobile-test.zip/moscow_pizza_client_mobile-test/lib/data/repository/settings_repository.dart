import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';

class SettingsRepository extends BaseRepository {
  final LocalSource _localSource = LocalSource.instance;

  Future<void> removeProfile() async {
    await _localSource.removeProfile();
  }
}
