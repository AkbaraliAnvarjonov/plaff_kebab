import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/orders_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/ondemand_order_request.dart';

class OrdersRepository extends BaseRepository {
  final OrdersRemoteSource remoteSource;

  OrdersRepository({
    required this.remoteSource,
  }) ;

  Future<dynamic> getOrders({
    required String token,
    List<String> statusIds = const [],
    int page = 1,
    int limit = 10,
  }) async {
    final response = await remoteSource.fetchOrders(
      token: token,
      limit: limit,
      page: page,
      startDate: '',
      endDate: '',
      statusIds: statusIds,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getOrdersReview({
    required String token,
    bool? reviewSeen,
    List<String> statusIds = const [],
    int limit = 100,
  }) async {
    final response = await remoteSource.fetchOrdersReview(
      token: token,
      limit: limit,
      page: 1,
      startDate: '',
      endDate: '',
      reviewSeen: reviewSeen ?? false,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getOrdersDetail({
    required String token,
    required String orderId,
  }) async {
    final response = await remoteSource.fetchOrdersDetail(
      token: token,
      ordersId: orderId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> addOnDemandOrder({
    required String token,
    required OnDemandOrderRequest request,
  }) async {
    final response = await remoteSource.fetchAddOndemandOrder(
        token: token, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }
}
