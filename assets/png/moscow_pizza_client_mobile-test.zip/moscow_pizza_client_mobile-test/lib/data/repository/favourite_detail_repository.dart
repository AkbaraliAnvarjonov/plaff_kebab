import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';

import '../data_sources/remote/favourite_detail_remote_source.dart';
import '../hive/products.dart';


class FavouriteDetailRepository extends BaseRepository {
  FavouriteDetailRemoteSource remoteSource;
  final LocalSource _localSource = LocalSource.instance;

  FavouriteDetailRepository({required this.remoteSource})
      ;

  Future<dynamic> getProductDetailV2(
      {required String shipperId, required String productId}) async {
    final response = await remoteSource.fetchProductDetailV2(
        shipperId: shipperId, productId: productId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getProductModifierV2(
      {required String auth, required String shipperId, required String productId}) async {
    final response = await remoteSource.fetchProductModifierV2(auth: auth,
        shipperId: shipperId, productId: productId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getComboV2(
      {required String auth, required String shipperId, required String comboId}) async {
    final response = await remoteSource.fetchComboV2(auth: auth, shipperId: shipperId, comboId: comboId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<void> insertProduct(Products product) async {
    await _localSource.insertProduct(product);
  }

  // Stream<List<Products>> getAllBasketProducts() {
  //   return _localSource.getAllBasketProducts();
  // }

  Future<List<Products>> getAllBasketProductsAsync() {
    return _localSource.getAllBasketProductsAsync();
  }

  Future<void> removeProduct(Products product) async {
    await _localSource.removeProduct(product);
  }

  Future<void> updateProduct(Products product) async {
    await _localSource.updateProduct(product);
  }
}
