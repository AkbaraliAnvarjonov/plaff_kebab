import '../../base/base_repository.dart';
import '../data_sources/local/local_source.dart';
import '../data_sources/remote/basket_remote_source.dart';
import '../hive/products.dart';

class BasketRepository extends BaseRepository {
  final BasketRemoteSource remoteSource;

  BasketRepository({required this.remoteSource});

  final LocalSource _localSource = LocalSource.instance;

  Future<dynamic> getProductFavorites({
    required String shipperId,
    required String productIds,
    // required String branchId,
    required String orderSource,
    required String isOnlyDelivery,
    required String isOnlySelfPickUp,
    required String clientId,
    required bool isWithDiscounts,
  }) async {
    final response = await remoteSource.fetchProductFavourites(
      shipperId: shipperId,
      productIds: productIds,
      // branchId: branchId,
      orderSource: orderSource,
      isOnlyDelivery: isOnlyDelivery,
      isOnlySelfPickUp: isOnlySelfPickUp,
      clientId: clientId,
      isWithDiscounts: isWithDiscounts,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }

  Future<List<Products>> getAllBasketProductsAsync() {
    return _localSource.getAllBasketProductsAsync();
  }

  Future<void> removeProduct(Products product) async {
    await _localSource.removeProduct(product);
  }

  Future<void> insertProduct(Products product) async {
    await _localSource.insertProduct(product);
  }

  Future<void> updateProduct(Products product) async {
    await _localSource.updateProduct(product);
  }

  Future<void> removeAll() async {
    await _localSource.removeAll();
  }
}
