import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/auth_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/check_customer_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/confirm_login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/confirm_register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/login_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/auth/register_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';

class AuthRepository extends BaseRepository {
  final LocalSource _localSource = LocalSource.instance;
  late final AuthRemoteSource _remoteSource;

  AuthRepository(this._remoteSource);

  Future<dynamic> checkCustomerExits({
    required String shipperId,
    required CheckCustomerRequest request,
  }) async {
    final response = await _remoteSource.fetchCheckCustomerExits(
        shipperId: shipperId, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> login({
    required String shipperId,
    required LoginRequest request,
  }) async {
    final response =
        await _remoteSource.fetchLogin(shipperId: shipperId, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> register({
    required String shipperId,
    required RegisterRequest request,
  }) async {
    final response = await _remoteSource.fetchRegister(
        shipperId: shipperId, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
        response.getException()?.errorMessage ?? '',
      );
    }
  }

  Future<dynamic> confirmRegister({
    required String shipperId,
    required String platform,
    required ConfirmRegisterRequest request,
  }) async {
    final response = await _remoteSource.fetchConfirmRegister(
        shipperId: shipperId, platform: platform, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
        response.getException()?.errorMessage ?? '',
      );
    }
  }

  Future<dynamic> confirmLogin({
    required String shipperId,
    required String platform,
    required ConfirmLoginRequest request,
  }) async {
    final response = await _remoteSource.fetchConfirmLogin(
        shipperId: shipperId, platform: platform, request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
        response.getException()?.errorMessage ?? '',
      );
    }
  }

  Future<void> setCustomer(Customer customer) async {
    await _localSource.setCustomer(customer);
  }
}
