import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/models/token/refresh_token_request.dart';
import 'package:moscow_pizza_client_mobile/data/models/token/refresh_token_response.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/api_client.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/response_handler.dart';
import 'package:moscow_pizza_client_mobile/data/provider/remote/server_error.dart';

class RefreshTokenRepository extends BaseRepository {
  final ApiClient _apiClient = ApiClient.getInstance();

  Future<ResponseHandler<RefreshTokenResponse>> _fetchRefreshToken(
      {required RefreshTokenRequest request}) async {
    RefreshTokenResponse response;
    try {
      response = await _apiClient.refreshToken(request);
    } catch (error, stacktrace) {
      debugPrint('Exception occurred: $error stacktrace: $stacktrace');
      return ResponseHandler()
        ..setException(ServerError.withError(error: error as DioException));
    }
    return ResponseHandler()..data = response;
  }

  Future<dynamic> refreshToken({required RefreshTokenRequest request}) async {
    final response = await _fetchRefreshToken(request: request);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return;
    }
  }
}
