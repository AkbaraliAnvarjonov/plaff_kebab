import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/last_orders_remote_source.dart';

class LastOrdersRepository extends BaseRepository {
  final LastOrdersRemoteSource remoteSource;

  LastOrdersRepository({
    required this.remoteSource,
  }) ;

  Future<dynamic> getLastOrders({
    required String token,
    List<String> statusIds = const [],
    int page = 1,
    int limit = 3,
  }) async {
    final response = await remoteSource.fetchLastOrders(
        token: token, limit: limit, page: page);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getSavedAddresses({
    required String token,
    required String customerId,
    List<String> statusIds = const [],
    int page = 1,
    int limit = 3,
  }) async {
    final response = await remoteSource.fetchSavedAddresses(
        token: token, customerId: customerId, limit: limit, page: page);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(
          response.getException()?.errorMessage ?? '');
    }
  }
}
