import 'package:moscow_pizza_client_mobile/base/base_repository.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/local/local_source.dart';
import 'package:moscow_pizza_client_mobile/data/data_sources/remote/profile_remote_source.dart';
import 'package:moscow_pizza_client_mobile/data/models/customer.dart';

class ProfileRepository extends BaseRepository {
  ProfileRemoteSource remoteSource;

  final LocalSource _localSource = LocalSource.instance;

  Future<void> removeProfile() async {
    await _localSource.removeProfile();
  }

  ProfileRepository({
    required this.remoteSource,
  });

  Future<dynamic> getCustomer({
    required String token,
    required String customerId,
  }) async {
    final response = await remoteSource.fetchCustomers(
      token: token,
      customerId: customerId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getAppVersion(
      {required String token, required String appName}) async {
    final response =
        await remoteSource.fetchAppVersion(token: token, appName: appName);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getUpdateCustomer({
    required String token,
    required String customerId,
    required Customer customer,
  }) async {
    final response = await remoteSource.fetchUpdatedCustomers(
      token: token,
      customerId: customerId,
      customer: customer,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> deleteCustomerAccount({
    required String token,
    required String customerId,
  }) async {
    final response = await remoteSource.fetchDeleteCustomerAccount(
      token: token,
      customerId: customerId,
    );
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getBranches({
    required String token,
    required String shipperId,
  }) async {
    final response =
        await remoteSource.fetchBranches(token: token, shipperId: shipperId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }

  Future<dynamic> getBranchesId({
    required String token,
    required String branchId,
  }) async {
    final response =
        await remoteSource.fetchBranchesId(token: token, branchId: branchId);
    if (response.data != null) {
      return response.data;
    } else if (response.getException()?.errorMessage != 'Canceled') {
      return getErrorMessage(response.getException()?.errorMessage ?? '');
    }
  }
}
